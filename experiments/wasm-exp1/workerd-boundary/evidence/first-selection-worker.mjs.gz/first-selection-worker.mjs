// experiments/wasm-exp1/read-path/codec.ts
var encoder = new TextEncoder(), decoder = new TextDecoder("utf-8", { fatal: !0, ignoreBOM: !0 }), LIMIT = 65536;
function rowCodec(meta) {
  if (meta.version !== 1 || !/^[0-9a-f]{64}$/.test(meta.digest)) throw Error("schema");
  let digest = Uint8Array.from(meta.digest.match(/../g).map((x) => parseInt(x, 16))), records = new Map(meta.records.map((r) => [r.id, { ...r, keys: new Set(r.fields) }])), names = new Map(meta.records.map((r) => [r.name, r.id])), freeze2 = (value) => {
    if (value && typeof value == "object") {
      for (let v of Object.values(value)) freeze2(v);
      Object.freeze(value);
    }
    return value;
  }, plans2 = new Map((meta.readPlans ?? []).map((p) => [p.id, freeze2(structuredClone(p))])), buffer = new Uint8Array(LIMIT), view = new DataView(buffer.buffer);
  return {
    pending(bytes) {
      if (bytes.length < 49 || bytes.length > LIMIT || bytes[0] !== 74 || bytes[1] !== 82 || bytes[2] !== 80 || bytes[3] !== 49 || digest.some((v, i) => bytes[4 + i] !== v)) throw Error("pending-header");
      let view2 = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength), requestId = view2.getUint32(36, !0), operationId = view2.getUint32(40, !0), id = view2.getUint32(44, !0), plan = plans2.get(id);
      if (!requestId || requestId > 2147483647 || !operationId || operationId > 64 || !plan || !records.has(plan.schema)) throw Error("pending-identity");
      let value = JSON.parse(decoder.decode(bytes.subarray(48)));
      if (plan.jsonBase - 4 + encoder.encode(JSON.stringify(value)).length + String(requestId).length - 1 + String(operationId).length - 1 > LIMIT) throw Error("pending-size");
      return { kind: "pending", requestId, operationId, capability: "storage.read", args: { ...plan.args, predicate: { ...plan.args.predicate, value } } };
    },
    snapshot(id, row) {
      let schema = records.get(id);
      if (!schema || !row || typeof row != "object" || Array.isArray(row)) throw Error("row-shape");
      let owned = { ...row };
      for (let key of Object.keys(owned)) {
        if (!schema.keys.has(key)) throw Error("row-shape");
        let value = owned[key];
        if (value !== null && typeof value != "string" && typeof value != "boolean" && !(typeof value == "number" && Number.isSafeInteger(value))) throw Error("row-field");
        Object.is(value, -0) && (owned[key] = 0);
      }
      return owned;
    },
    reference(expected, bytes, rows) {
      if (bytes.length !== 48 || bytes[0] !== 74 || bytes[1] !== 82 || bytes[2] !== 82 || bytes[3] !== 49 || digest.some((v, i) => bytes[4 + i] !== v)) throw Error("reference-header");
      let view2 = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength), schema = view2.getUint32(36, !0), request = view2.getUint32(40, !0), operation = view2.getUint32(44, !0), found = rows.get(request + ":" + operation);
      if (!records.has(schema) || schema !== expected || !found || found.schema !== schema || request === 0 || operation === 0) throw Error("reference-identity");
      return { ...found.row };
    },
    schema: (name) => typeof name == "string" ? names.get(name) : void 0,
    resultSchema: (entry) => meta.entries[String(entry)],
    encode(id, row) {
      let schema = records.get(id);
      if (!schema || !row || typeof row != "object" || Array.isArray(row) || Object.keys(row).some((k) => !schema.keys.has(k))) throw Error("row-shape");
      if (encoder.encode(JSON.stringify({ kind: "success", value: row })).length > LIMIT) throw Error("row-json-size");
      buffer.set([74, 82, 87, 49]), buffer.set(digest, 4), view.setUint32(36, id, !0);
      let pos = 40, room = (n) => {
        if (pos + n > LIMIT) throw Error("row-size");
      };
      for (let key of schema.fields) {
        if (room(1), !Object.hasOwn(row, key)) {
          buffer[pos++] = 0;
          continue;
        }
        let value = row[key];
        if (value === null) {
          buffer[pos++] = 1;
          continue;
        }
        if (typeof value == "string") {
          if (!value.isWellFormed()) throw Error("row-utf16");
          room(5), buffer[pos++] = 2;
          let lengthOffset = pos;
          pos += 4;
          let { read: read3, written } = encoder.encodeInto(value, buffer.subarray(pos));
          if (read3 !== value.length) throw Error("row-size");
          view.setUint32(lengthOffset, written, !0), pos += written;
        } else if (typeof value == "boolean") buffer[pos++] = value ? 4 : 3;
        else if (typeof value == "number" && Number.isSafeInteger(value))
          room(9), buffer[pos++] = 5, view.setBigInt64(pos, BigInt(value), !0), pos += 8;
        else throw Error("row-field");
      }
      return buffer.subarray(0, pos);
    },
    decode(expected, bytes) {
      if (bytes.length < 40 || bytes.length > LIMIT || bytes[0] !== 74 || bytes[1] !== 82 || bytes[2] !== 87 || bytes[3] !== 49 || digest.some((v, i) => bytes[4 + i] !== v)) throw Error("row-header");
      let dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength), id = dv.getUint32(36, !0), schema = records.get(id);
      if (id !== expected || !schema) throw Error("row-schema");
      let pos = 40, row = {}, room = (n) => {
        if (pos + n > bytes.length) throw Error("row-truncated");
      };
      for (let key of schema.fields) {
        room(1);
        let tag = bytes[pos++], value;
        if (tag !== 0) {
          if (tag === 1) value = null;
          else if (tag === 3 || tag === 4) value = tag === 4;
          else if (tag === 2) {
            room(4);
            let n = dv.getUint32(pos, !0);
            pos += 4, room(n), value = decoder.decode(bytes.subarray(pos, pos + n)), pos += n;
          } else if (tag === 5) {
            if (room(8), value = Number(dv.getBigInt64(pos, !0)), pos += 8, !Number.isSafeInteger(value)) throw Error("row-integer");
          } else throw Error("row-tag");
          Object.defineProperty(row, key, { value, enumerable: !0, writable: !0, configurable: !0 });
        }
      }
      if (pos !== bytes.length) throw Error("row-trailing");
      return row;
    }
  };
}

// experiments/wasm-exp1/compiler/build/projected/program.json
var program_default = {
  boundary: {
    closedRecords: !0,
    omittedNullPresent: "distinct",
    textLength: "unicodeScalar",
    trustedPrincipalOnly: !0
  },
  callEdges: [
    {
      callee: 26,
      caller: 27
    },
    {
      callee: 27,
      caller: 517
    },
    {
      callee: 28,
      caller: 550
    }
  ],
  checkedRevision: "src_59ae092e2dc659cb",
  declarations: [
    {
      category: "InvalidValue",
      code: "empty_patch",
      httpStatus: 422,
      internal: [],
      kind: "failure",
      message: null,
      name: "EmptyPatch",
      operationId: "failure:EmptyPatch",
      public: [],
      semanticId: 7,
      span: {
        end: 483,
        source: "app.jadpo",
        start: 414
      }
    },
    {
      fields: [
        {
          constraints: [],
          immutable: !1,
          name: "id",
          optional: !1,
          reference: null,
          role: null,
          span: {
            end: 558,
            source: "app.jadpo",
            start: 550
          },
          storage: [
            "Identity"
          ],
          type: {
            authoredNullable: !1,
            name: "Uuid",
            nullable: !1,
            span: {
              end: 558,
              source: "app.jadpo",
              start: 554
            }
          }
        },
        {
          constraints: [],
          immutable: !0,
          name: "owner_id",
          optional: !1,
          reference: null,
          role: "ItemRole.owner",
          span: {
            end: 641,
            source: "app.jadpo",
            start: 563
          },
          storage: [],
          type: {
            authoredNullable: !1,
            name: "User.id",
            nullable: !1,
            span: {
              end: 580,
              source: "app.jadpo",
              start: 573
            }
          }
        },
        {
          constraints: [],
          immutable: !1,
          name: "title",
          optional: !1,
          reference: null,
          role: null,
          span: {
            end: 662,
            source: "app.jadpo",
            start: 646
          },
          storage: [
            "Unique"
          ],
          type: {
            authoredNullable: !1,
            name: "ItemTitle",
            nullable: !1,
            span: {
              end: 662,
              source: "app.jadpo",
              start: 653
            }
          }
        },
        {
          constraints: [],
          immutable: !1,
          name: "note",
          optional: !1,
          reference: null,
          role: null,
          span: {
            end: 678,
            source: "app.jadpo",
            start: 667
          },
          storage: [],
          type: {
            authoredNullable: !0,
            name: "Text",
            nullable: !0,
            span: {
              end: 678,
              source: "app.jadpo",
              start: 673
            }
          }
        }
      ],
      kind: "record",
      name: "Item",
      operationId: "entity:Item",
      persistent: !0,
      recordKind: "Entity",
      semanticId: 20,
      span: {
        end: 1922,
        source: "app.jadpo",
        start: 532
      }
    },
    {
      body: [
        {
          op: "return",
          span: {
            end: 1609,
            source: "app.jadpo",
            start: 1409
          },
          value: {
            op: "attempt",
            span: {
              end: 1609,
              source: "app.jadpo",
              start: 1416
            },
            type: "Item",
            value: {
              conflicts: [
                {
                  constraint: null,
                  failure: {
                    failure: "ItemConflict",
                    fields: [],
                    op: "reject",
                    span: {
                      end: 1599,
                      source: "app.jadpo",
                      start: 1587
                    }
                  }
                }
              ],
              empty: {
                failure: "EmptyPatch",
                fields: [],
                op: "reject",
                span: {
                  end: 1531,
                  source: "app.jadpo",
                  start: 1521
                }
              },
              entity: "Item",
              hostEffect: "storage.update",
              missing: {
                failure: "ItemMissing",
                fields: [],
                op: "reject",
                span: {
                  end: 1564,
                  source: "app.jadpo",
                  start: 1553
                }
              },
              op: "update",
              patch: [
                "changes"
              ],
              policy: "checkedOperationObligations",
              predicate: {
                field: "id",
                operator: "equal",
                value: {
                  op: "load",
                  path: [
                    "id"
                  ],
                  span: {
                    end: 1474,
                    source: "app.jadpo",
                    start: 1472
                  },
                  type: "Item.id"
                }
              },
              set: [],
              span: {
                end: 1609,
                source: "app.jadpo",
                start: 1424
              },
              type: "Item"
            }
          }
        }
      ],
      callableKind: "Action",
      consistency: null,
      failures: [
        "EmptyPatch",
        "ItemConflict",
        "ItemMissing"
      ],
      freshness: null,
      kind: "callable",
      maySuspend: !0,
      name: "Item.change",
      operationId: "action:Item.change",
      owner: "Item",
      parameters: [
        {
          name: "id",
          type: {
            authoredNullable: !1,
            name: "Item.id",
            nullable: !1,
            span: {
              end: 1305,
              source: "app.jadpo",
              start: 1298
            }
          }
        },
        {
          name: "changes",
          type: {
            authoredNullable: !1,
            name: "ItemPatch",
            nullable: !1,
            span: {
              end: 1325,
              source: "app.jadpo",
              start: 1316
            }
          }
        }
      ],
      result: {
        authoredNullable: !1,
        name: "Item",
        nullable: !1,
        span: {
          end: 1394,
          source: "app.jadpo",
          start: 1390
        }
      },
      semanticId: 22,
      span: {
        end: 1615,
        source: "app.jadpo",
        start: 1280
      }
    },
    {
      body: [
        {
          op: "return",
          span: {
            end: 1074,
            source: "app.jadpo",
            start: 967
          },
          value: {
            op: "attempt",
            span: {
              end: 1074,
              source: "app.jadpo",
              start: 974
            },
            type: "Item",
            value: {
              cardinality: "required",
              entity: "Item",
              hostEffect: "storage.read",
              missing: {
                failure: "ItemMissing",
                fields: [],
                op: "reject",
                span: {
                  end: 1064,
                  source: "app.jadpo",
                  start: 1053
                }
              },
              op: "query",
              policy: "checkedOperationObligations",
              predicate: {
                field: "id",
                operator: "equal",
                value: {
                  op: "load",
                  path: [
                    "id"
                  ],
                  span: {
                    end: 1031,
                    source: "app.jadpo",
                    start: 1029
                  },
                  type: "Item.id"
                }
              },
              span: {
                end: 1074,
                source: "app.jadpo",
                start: 982
              },
              type: "Item"
            }
          }
        }
      ],
      callableKind: "Query",
      consistency: null,
      failures: [
        "ItemMissing"
      ],
      freshness: "Authoritative",
      kind: "callable",
      maySuspend: !0,
      name: "Item.read",
      operationId: "query:Item.read",
      owner: "Item",
      parameters: [
        {
          name: "id",
          type: {
            authoredNullable: !1,
            name: "Item.id",
            nullable: !1,
            span: {
              end: 876,
              source: "app.jadpo",
              start: 869
            }
          }
        }
      ],
      result: {
        authoredNullable: !1,
        name: "Item",
        nullable: !1,
        span: {
          end: 952,
          source: "app.jadpo",
          start: 948
        }
      },
      semanticId: 26,
      span: {
        end: 1080,
        source: "app.jadpo",
        start: 854
      }
    },
    {
      body: [
        {
          annotation: null,
          mutable: !1,
          name: "item",
          op: "bind",
          span: {
            end: 1242,
            source: "app.jadpo",
            start: 1210
          },
          value: {
            op: "attempt",
            span: {
              end: 1242,
              source: "app.jadpo",
              start: 1221
            },
            type: "Item",
            value: {
              arguments: [
                {
                  op: "load",
                  path: [
                    "id"
                  ],
                  span: {
                    end: 1241,
                    source: "app.jadpo",
                    start: 1239
                  },
                  type: "Item.id"
                }
              ],
              op: "call",
              span: {
                end: 1242,
                source: "app.jadpo",
                start: 1229
              },
              target: "Item.read",
              targetId: 26,
              type: "Item"
            }
          }
        },
        {
          op: "return",
          span: {
            end: 1268,
            source: "app.jadpo",
            start: 1251
          },
          value: {
            op: "load",
            path: [
              "item",
              "title"
            ],
            span: {
              end: 1268,
              source: "app.jadpo",
              start: 1258
            },
            type: "Item.title"
          }
        }
      ],
      callableKind: "Query",
      consistency: null,
      failures: [
        "ItemMissing"
      ],
      freshness: "Authoritative",
      kind: "callable",
      maySuspend: !0,
      name: "Item.read_title",
      operationId: "query:Item.read_title",
      owner: "Item",
      parameters: [
        {
          name: "id",
          type: {
            authoredNullable: !1,
            name: "Item.id",
            nullable: !1,
            span: {
              end: 1114,
              source: "app.jadpo",
              start: 1107
            }
          }
        }
      ],
      result: {
        authoredNullable: !1,
        name: "ItemTitle",
        nullable: !1,
        span: {
          end: 1195,
          source: "app.jadpo",
          start: 1186
        }
      },
      semanticId: 27,
      span: {
        end: 1274,
        source: "app.jadpo",
        start: 1086
      }
    },
    {
      body: [
        {
          op: "return",
          span: {
            end: 1914,
            source: "app.jadpo",
            start: 1737
          },
          value: {
            op: "attempt",
            span: {
              end: 1914,
              source: "app.jadpo",
              start: 1744
            },
            type: "Item",
            value: {
              conflicts: [
                {
                  constraint: null,
                  failure: {
                    failure: "ItemConflict",
                    fields: [],
                    op: "reject",
                    span: {
                      end: 1904,
                      source: "app.jadpo",
                      start: 1892
                    }
                  }
                }
              ],
              empty: null,
              entity: "Item",
              hostEffect: "storage.update",
              missing: {
                failure: "ItemMissing",
                fields: [],
                op: "reject",
                span: {
                  end: 1869,
                  source: "app.jadpo",
                  start: 1858
                }
              },
              op: "update",
              patch: null,
              policy: "checkedOperationObligations",
              predicate: {
                field: "id",
                operator: "equal",
                value: {
                  op: "load",
                  path: [
                    "id"
                  ],
                  span: {
                    end: 1802,
                    source: "app.jadpo",
                    start: 1800
                  },
                  type: "Item.id"
                }
              },
              set: [
                {
                  name: "title",
                  span: {
                    end: 1834,
                    source: "app.jadpo",
                    start: 1822
                  },
                  value: {
                    op: "load",
                    path: [
                      "title"
                    ],
                    span: {
                      end: 1834,
                      source: "app.jadpo",
                      start: 1829
                    },
                    type: "Item.title"
                  }
                }
              ],
              span: {
                end: 1914,
                source: "app.jadpo",
                start: 1752
              },
              type: "Item"
            }
          }
        }
      ],
      callableKind: "Action",
      consistency: null,
      failures: [
        "ItemConflict",
        "ItemMissing"
      ],
      freshness: null,
      kind: "callable",
      maySuspend: !0,
      name: "Item.rename",
      operationId: "action:Item.rename",
      owner: "Item",
      parameters: [
        {
          name: "id",
          type: {
            authoredNullable: !1,
            name: "Item.id",
            nullable: !1,
            span: {
              end: 1646,
              source: "app.jadpo",
              start: 1639
            }
          }
        },
        {
          name: "title",
          type: {
            authoredNullable: !1,
            name: "Item.title",
            nullable: !1,
            span: {
              end: 1665,
              source: "app.jadpo",
              start: 1655
            }
          }
        }
      ],
      result: {
        authoredNullable: !1,
        name: "Item",
        nullable: !1,
        span: {
          end: 1722,
          source: "app.jadpo",
          start: 1718
        }
      },
      semanticId: 28,
      span: {
        end: 1920,
        source: "app.jadpo",
        start: 1621
      }
    },
    {
      category: "Conflict",
      code: "item_conflict",
      httpStatus: 409,
      internal: [],
      kind: "failure",
      message: null,
      name: "ItemConflict",
      operationId: "failure:ItemConflict",
      public: [],
      semanticId: 30,
      span: {
        end: 412,
        source: "app.jadpo",
        start: 343
      }
    },
    {
      category: "NotFound",
      code: "item_missing",
      httpStatus: 404,
      internal: [],
      kind: "failure",
      message: null,
      name: "ItemMissing",
      operationId: "failure:ItemMissing",
      public: [],
      semanticId: 31,
      span: {
        end: 341,
        source: "app.jadpo",
        start: 274
      }
    },
    {
      fields: [
        {
          constraints: [],
          immutable: !1,
          name: "title",
          optional: !0,
          reference: null,
          role: null,
          span: {
            end: 212,
            source: "app.jadpo",
            start: 186
          },
          storage: [],
          type: {
            authoredNullable: !1,
            name: "Item.title",
            nullable: !1,
            span: {
              end: 203,
              source: "app.jadpo",
              start: 193
            }
          }
        },
        {
          constraints: [],
          immutable: !1,
          name: "note",
          optional: !0,
          reference: null,
          role: null,
          span: {
            end: 241,
            source: "app.jadpo",
            start: 217
          },
          storage: [],
          type: {
            authoredNullable: !1,
            name: "Item.note",
            nullable: !0,
            span: {
              end: 232,
              source: "app.jadpo",
              start: 223
            }
          }
        }
      ],
      kind: "record",
      name: "ItemPatch",
      operationId: "object:ItemPatch",
      persistent: !1,
      recordKind: "Value",
      semanticId: 32,
      span: {
        end: 243,
        source: "app.jadpo",
        start: 156
      }
    },
    {
      kind: "enum",
      name: "ItemRole",
      operationId: "enum:ItemRole",
      semanticId: 35,
      span: {
        end: 272,
        source: "app.jadpo",
        start: 245
      },
      variants: [
        "owner"
      ]
    },
    {
      constraints: [
        {
          kind: "MinLength",
          span: {
            end: 41,
            source: "app.jadpo",
            start: 28
          },
          value: 3
        },
        {
          kind: "MaxLength",
          span: {
            end: 60,
            source: "app.jadpo",
            start: 46
          },
          value: 12
        }
      ],
      kind: "type",
      name: "ItemTitle",
      operationId: "type:ItemTitle",
      parent: {
        authoredNullable: !1,
        name: "Text",
        nullable: !1,
        span: {
          end: 21,
          source: "app.jadpo",
          start: 17
        }
      },
      semanticId: 37,
      span: {
        end: 62,
        source: "app.jadpo",
        start: 0
      }
    },
    {
      fields: [
        {
          constraints: [],
          immutable: !1,
          name: "id",
          optional: !1,
          reference: null,
          role: null,
          span: {
            end: 106,
            source: "app.jadpo",
            start: 95
          },
          storage: [],
          type: {
            authoredNullable: !1,
            name: "Item.id",
            nullable: !1,
            span: {
              end: 106,
              source: "app.jadpo",
              start: 99
            }
          }
        },
        {
          constraints: [],
          immutable: !1,
          name: "title",
          optional: !1,
          reference: null,
          role: null,
          span: {
            end: 127,
            source: "app.jadpo",
            start: 111
          },
          storage: [],
          type: {
            authoredNullable: !1,
            name: "ItemTitle",
            nullable: !1,
            span: {
              end: 127,
              source: "app.jadpo",
              start: 118
            }
          }
        },
        {
          constraints: [],
          immutable: !1,
          name: "note",
          optional: !0,
          reference: null,
          role: null,
          span: {
            end: 152,
            source: "app.jadpo",
            start: 132
          },
          storage: [],
          type: {
            authoredNullable: !0,
            name: "Text",
            nullable: !0,
            span: {
              end: 143,
              source: "app.jadpo",
              start: 138
            }
          }
        }
      ],
      kind: "record",
      name: "ProbeInput",
      operationId: "object:ProbeInput",
      persistent: !1,
      recordKind: "Value",
      semanticId: 57,
      span: {
        end: 154,
        source: "app.jadpo",
        start: 64
      }
    },
    {
      fields: [
        {
          constraints: [],
          immutable: !1,
          name: "id",
          optional: !1,
          reference: null,
          role: null,
          span: {
            end: 511,
            source: "app.jadpo",
            start: 503
          },
          storage: [
            "Identity"
          ],
          type: {
            authoredNullable: !1,
            name: "Uuid",
            nullable: !1,
            span: {
              end: 511,
              source: "app.jadpo",
              start: 507
            }
          }
        }
      ],
      kind: "record",
      name: "User",
      operationId: "entity:User",
      persistent: !1,
      recordKind: "Entity",
      semanticId: 84,
      span: {
        end: 530,
        source: "app.jadpo",
        start: 485
      }
    },
    {
      body: [
        {
          op: "return",
          span: {
            end: 2096,
            source: "app.jadpo",
            start: 1975
          },
          value: {
            arms: [
              {
                body: {
                  op: "load",
                  path: [
                    "title"
                  ],
                  span: {
                    end: 2047,
                    source: "app.jadpo",
                    start: 2042
                  },
                  type: "ItemTitle"
                },
                pattern: {
                  binding: "title",
                  kind: "success"
                },
                span: {
                  end: 2047,
                  source: "app.jadpo",
                  start: 2024
                }
              },
              {
                body: {
                  op: "load",
                  path: [
                    "input",
                    "title"
                  ],
                  span: {
                    end: 2090,
                    source: "app.jadpo",
                    start: 2079
                  },
                  type: "ProbeInput.title"
                },
                pattern: {
                  failure: "ItemMissing",
                  kind: "failure"
                },
                span: {
                  end: 2090,
                  source: "app.jadpo",
                  start: 2056
                }
              }
            ],
            op: "outcomeMatch",
            span: {
              end: 2096,
              source: "app.jadpo",
              start: 1982
            },
            subject: {
              arguments: [
                {
                  op: "load",
                  path: [
                    "input",
                    "id"
                  ],
                  span: {
                    end: 2012,
                    source: "app.jadpo",
                    start: 2004
                  },
                  type: "ProbeInput.id"
                }
              ],
              op: "call",
              span: {
                end: 2013,
                source: "app.jadpo",
                start: 1988
              },
              target: "Item.read_title",
              targetId: 27,
              type: "ItemTitle"
            },
            type: "ItemTitle"
          }
        }
      ],
      callableKind: "Action",
      consistency: null,
      failures: [],
      freshness: null,
      kind: "callable",
      maySuspend: !0,
      name: "probe",
      operationId: "action:probe",
      owner: null,
      parameters: [
        {
          name: "input",
          type: {
            authoredNullable: !1,
            name: "ProbeInput",
            nullable: !1,
            span: {
              end: 1954,
              source: "app.jadpo",
              start: 1944
            }
          }
        }
      ],
      result: {
        authoredNullable: !1,
        name: "ItemTitle",
        nullable: !1,
        span: {
          end: 1968,
          source: "app.jadpo",
          start: 1959
        }
      },
      semanticId: 517,
      span: {
        end: 2098,
        source: "app.jadpo",
        start: 1924
      }
    },
    {
      body: [
        {
          annotation: null,
          mutable: !1,
          name: "first",
          op: "bind",
          span: {
            end: 2359,
            source: "app.jadpo",
            start: 2305
          },
          value: {
            op: "attempt",
            span: {
              end: 2359,
              source: "app.jadpo",
              start: 2317
            },
            type: "Item",
            value: {
              arguments: [
                {
                  op: "load",
                  path: [
                    "first_id"
                  ],
                  span: {
                    end: 2345,
                    source: "app.jadpo",
                    start: 2337
                  },
                  type: "Item.id"
                },
                {
                  op: "load",
                  path: [
                    "first_title"
                  ],
                  span: {
                    end: 2358,
                    source: "app.jadpo",
                    start: 2347
                  },
                  type: "Item.title"
                }
              ],
              op: "call",
              span: {
                end: 2359,
                source: "app.jadpo",
                start: 2325
              },
              target: "Item.rename",
              targetId: 28,
              type: "Item"
            }
          }
        },
        {
          op: "return",
          span: {
            end: 2415,
            source: "app.jadpo",
            start: 2364
          },
          value: {
            op: "attempt",
            span: {
              end: 2415,
              source: "app.jadpo",
              start: 2371
            },
            type: "Item",
            value: {
              arguments: [
                {
                  op: "load",
                  path: [
                    "second_id"
                  ],
                  span: {
                    end: 2400,
                    source: "app.jadpo",
                    start: 2391
                  },
                  type: "Item.id"
                },
                {
                  op: "load",
                  path: [
                    "second_title"
                  ],
                  span: {
                    end: 2414,
                    source: "app.jadpo",
                    start: 2402
                  },
                  type: "Item.title"
                }
              ],
              op: "call",
              span: {
                end: 2415,
                source: "app.jadpo",
                start: 2379
              },
              target: "Item.rename",
              targetId: 28,
              type: "Item"
            }
          }
        }
      ],
      callableKind: "Action",
      consistency: "Atomic",
      failures: [
        "ItemConflict",
        "ItemMissing"
      ],
      freshness: null,
      kind: "callable",
      maySuspend: !0,
      name: "update_pair",
      operationId: "action:update_pair",
      owner: null,
      parameters: [
        {
          name: "first_id",
          type: {
            authoredNullable: !1,
            name: "Item.id",
            nullable: !1,
            span: {
              end: 2141,
              source: "app.jadpo",
              start: 2134
            }
          }
        },
        {
          name: "first_title",
          type: {
            authoredNullable: !1,
            name: "Item.title",
            nullable: !1,
            span: {
              end: 2170,
              source: "app.jadpo",
              start: 2160
            }
          }
        },
        {
          name: "second_id",
          type: {
            authoredNullable: !1,
            name: "Item.id",
            nullable: !1,
            span: {
              end: 2194,
              source: "app.jadpo",
              start: 2187
            }
          }
        },
        {
          name: "second_title",
          type: {
            authoredNullable: !1,
            name: "Item.title",
            nullable: !1,
            span: {
              end: 2224,
              source: "app.jadpo",
              start: 2214
            }
          }
        }
      ],
      result: {
        authoredNullable: !1,
        name: "Item",
        nullable: !1,
        span: {
          end: 2298,
          source: "app.jadpo",
          start: 2294
        }
      },
      semanticId: 550,
      span: {
        end: 2417,
        source: "app.jadpo",
        start: 2100
      }
    }
  ],
  effectiveTypes: {
    "Item.id": {
      base: "Uuid",
      constraints: [],
      nominal: "Item.id",
      nullable: !1,
      textLengthUnit: "unicodeScalar"
    },
    "Item.note": {
      base: "Text",
      constraints: [],
      nominal: "Item.note",
      nullable: !0,
      textLengthUnit: "unicodeScalar"
    },
    "Item.owner_id": {
      base: "Uuid",
      constraints: [],
      nominal: "Item.owner_id",
      nullable: !1,
      textLengthUnit: "unicodeScalar"
    },
    "Item.title": {
      base: "Text",
      constraints: [
        {
          kind: "MinLength",
          span: {
            end: 41,
            source: "app.jadpo",
            start: 28
          },
          value: 3
        },
        {
          kind: "MaxLength",
          span: {
            end: 60,
            source: "app.jadpo",
            start: 46
          },
          value: 12
        }
      ],
      nominal: "Item.title",
      nullable: !1,
      textLengthUnit: "unicodeScalar"
    },
    "ItemPatch.note": {
      base: "Text",
      constraints: [],
      nominal: "ItemPatch.note",
      nullable: !0,
      textLengthUnit: "unicodeScalar"
    },
    "ItemPatch.title": {
      base: "Text",
      constraints: [
        {
          kind: "MinLength",
          span: {
            end: 41,
            source: "app.jadpo",
            start: 28
          },
          value: 3
        },
        {
          kind: "MaxLength",
          span: {
            end: 60,
            source: "app.jadpo",
            start: 46
          },
          value: 12
        }
      ],
      nominal: "ItemPatch.title",
      nullable: !1,
      textLengthUnit: "unicodeScalar"
    },
    ItemTitle: {
      base: "Text",
      constraints: [
        {
          kind: "MinLength",
          span: {
            end: 41,
            source: "app.jadpo",
            start: 28
          },
          value: 3
        },
        {
          kind: "MaxLength",
          span: {
            end: 60,
            source: "app.jadpo",
            start: 46
          },
          value: 12
        }
      ],
      nominal: "ItemTitle",
      nullable: !1,
      textLengthUnit: "unicodeScalar"
    },
    "ProbeInput.id": {
      base: "Uuid",
      constraints: [],
      nominal: "ProbeInput.id",
      nullable: !1,
      textLengthUnit: "unicodeScalar"
    },
    "ProbeInput.note": {
      base: "Text",
      constraints: [],
      nominal: "ProbeInput.note",
      nullable: !0,
      textLengthUnit: "unicodeScalar"
    },
    "ProbeInput.title": {
      base: "Text",
      constraints: [
        {
          kind: "MinLength",
          span: {
            end: 41,
            source: "app.jadpo",
            start: 28
          },
          value: 3
        },
        {
          kind: "MaxLength",
          span: {
            end: 60,
            source: "app.jadpo",
            start: 46
          },
          value: 12
        }
      ],
      nominal: "ProbeInput.title",
      nullable: !1,
      textLengthUnit: "unicodeScalar"
    },
    "User.id": {
      base: "Uuid",
      constraints: [],
      nominal: "User.id",
      nullable: !1,
      textLengthUnit: "unicodeScalar"
    }
  },
  entities: [
    {
      authorityStore: "primary",
      identity: "id",
      name: "Item",
      operations: [
        "Item.change",
        "Item.read",
        "Item.read_title",
        "Item.rename"
      ],
      persistent: !0
    },
    {
      authorityStore: null,
      identity: "id",
      name: "User",
      operations: [],
      persistent: !1
    }
  ],
  kind: "jadpo_checked_executable_projection",
  policy: {
    active: !0,
    bindings: [
      {
        entity: "Item",
        field: "owner_id",
        principalEntity: "User",
        role: "ItemRole.owner",
        scope: "Item"
      }
    ],
    entities: [
      {
        entity: "Item",
        fields: [],
        rules: [
          {
            effects: [
              "read",
              "update"
            ],
            subject: "ItemRole.owner"
          }
        ],
        scope: "Item",
        scopeField: null
      }
    ],
    operations: [
      {
        fieldReads: [],
        obligations: [
          {
            effect: "update",
            entity: "Item",
            origin: "entity",
            subjects: [
              "ItemRole.owner"
            ]
          }
        ],
        operation: "Item.change"
      },
      {
        fieldReads: [],
        obligations: [
          {
            effect: "read",
            entity: "Item",
            origin: "entity",
            subjects: [
              "ItemRole.owner"
            ]
          }
        ],
        operation: "Item.read"
      },
      {
        fieldReads: [],
        obligations: [
          {
            effect: "read",
            entity: "Item",
            origin: "entity",
            subjects: [
              "ItemRole.owner"
            ]
          }
        ],
        operation: "Item.read_title"
      },
      {
        fieldReads: [],
        obligations: [
          {
            effect: "update",
            entity: "Item",
            origin: "entity",
            subjects: [
              "ItemRole.owner"
            ]
          }
        ],
        operation: "Item.rename"
      },
      {
        fieldReads: [],
        obligations: [
          {
            effect: "read",
            entity: "Item",
            origin: "entity",
            subjects: [
              "ItemRole.owner"
            ]
          }
        ],
        operation: "probe"
      },
      {
        fieldReads: [],
        obligations: [
          {
            effect: "update",
            entity: "Item",
            origin: "entity",
            subjects: [
              "ItemRole.owner"
            ]
          }
        ],
        operation: "update_pair"
      }
    ]
  },
  queries: [
    {
      freshness: "authoritative",
      name: "Item.read",
      owner: "Item",
      plan: "authoritative",
      predicateFields: [
        "Item.id"
      ],
      reads: [
        "Item"
      ]
    },
    {
      freshness: "authoritative",
      name: "Item.read_title",
      owner: "Item",
      plan: "authoritative",
      predicateFields: [
        "Item.id"
      ],
      reads: [
        "Item"
      ]
    }
  ],
  schemaVersion: 1,
  transactions: [
    {
      action: "Item.change",
      disposition: "entity_action",
      domain: "primary",
      handledFailure: "savepoint_rollback",
      nested: "join_declared_boundary",
      owners: [
        "Item"
      ],
      postgresConcurrency: "row_lock_or_checked_revision",
      postgresIsolation: "read_committed",
      retry: "explicit_idempotent_only",
      sqliteIsolation: "immediate_serialized"
    },
    {
      action: "Item.rename",
      disposition: "entity_action",
      domain: "primary",
      handledFailure: "savepoint_rollback",
      nested: "join_declared_boundary",
      owners: [
        "Item"
      ],
      postgresConcurrency: "row_lock_or_checked_revision",
      postgresIsolation: "read_committed",
      retry: "explicit_idempotent_only",
      sqliteIsolation: "immediate_serialized"
    },
    {
      action: "update_pair",
      disposition: "atomic",
      domain: "primary",
      handledFailure: "savepoint_rollback",
      nested: "join_declared_boundary",
      owners: [
        "Item"
      ],
      postgresConcurrency: "row_lock_or_checked_revision",
      postgresIsolation: "read_committed",
      retry: "explicit_idempotent_only",
      sqliteIsolation: "immediate_serialized"
    }
  ]
};

// experiments/wasm-exp1/acceptance.json
var acceptance_default = {
  schema_version: 1,
  experiment: "WASM-EXP1",
  status: "frozen_cases_not_runtime_results",
  source_checkpoint: "4dc5604",
  source: {
    path: "fixture/app.jadpo",
    sha256: "447ce2f023b53cecd705999ec280ae9b9d61f7ae0e85184b77c62c9f7aa143f1",
    compiler_source_revision: "src_59ae092e2dc659cb"
  },
  normal_compiler_validation: {
    check_command: "jadpo/target/debug/jadpo check experiments/wasm-exp1/fixture",
    check_result: "passed: 1 source file, 15 declarations, 551 semantic nodes",
    build_command: "jadpo/target/debug/jadpo build experiments/wasm-exp1/fixture",
    build_result: "passed: 18 derived and target files"
  },
  scope: {
    probe_entrypoint: "probe",
    full_slice_entrypoints: [
      "probe",
      "Item.read",
      "Item.change",
      "Item.rename",
      "update_pair"
    ],
    routes: [],
    principal_boundary: "Trusted test harness only; no public header/body chooses a principal. This does not test authentication adapters.",
    baseline_access: "Generated Bun callable functions are not exported; baseline harness must expose/evaluate existing generated callables through a recorded trusted test adapter without changing authored behavior.",
    optional_note: "Probe validates omitted/null/text. Item.change proves observable preservation/clearing in full slice.",
    case_reset: "Reset persistent Item rows and recreate trusted User principal fixtures before each case unless explicitly sequenced. User is a nonpersistent principal type; no User SQL table exists.",
    host_results: "read_row/read_missing describe the required-storage capability response semantically; runner maps to the frozen ABI without selecting application recovery arms."
  },
  seeds: {
    principals: {
      owner: {
        entity: "User",
        id: "11111111-1111-4111-8111-111111111111"
      },
      other: {
        entity: "User",
        id: "22222222-2222-4222-8222-222222222222"
      }
    },
    Item: [
      {
        id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
        owner_id: "11111111-1111-4111-8111-111111111111",
        title: "alpha",
        note: "keep me"
      },
      {
        id: "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb",
        owner_id: "11111111-1111-4111-8111-111111111111",
        title: "bravo",
        note: null
      },
      {
        id: "cccccccc-cccc-4ccc-8ccc-cccccccccccc",
        owner_id: "22222222-2222-4222-8222-222222222222",
        title: "charlie",
        note: "other note"
      }
    ],
    missing_item_id: "dddddddd-dddd-4ddd-8ddd-dddddddddddd",
    trusted_principal_values: [
      {
        id: "11111111-1111-4111-8111-111111111111"
      },
      {
        id: "22222222-2222-4222-8222-222222222222"
      }
    ]
  },
  probe_cases: [
    {
      id: "P01",
      operation: "probe",
      principal: "owner",
      input: {
        id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
        title: "fallback"
      },
      expect: {
        kind: "success",
        value: "alpha"
      },
      host: {
        delay_ms: 7,
        read_row: {
          id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
          owner_id: "11111111-1111-4111-8111-111111111111",
          title: "alpha",
          note: "keep me"
        }
      },
      note: "Omitted optional note accepted."
    },
    {
      id: "P02",
      operation: "probe",
      principal: "owner",
      input: {
        id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
        title: "fallback",
        note: null
      },
      expect: {
        kind: "success",
        value: "alpha"
      },
      host: {
        delay_ms: 7,
        read_row: {
          id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
          owner_id: "11111111-1111-4111-8111-111111111111",
          title: "alpha",
          note: "keep me"
        }
      },
      note: "Explicit null accepted."
    },
    {
      id: "P03",
      operation: "probe",
      principal: "owner",
      input: {
        id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
        title: "fallback",
        note: "carried text"
      },
      expect: {
        kind: "success",
        value: "alpha"
      },
      host: {
        delay_ms: 7,
        read_row: {
          id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
          owner_id: "11111111-1111-4111-8111-111111111111",
          title: "alpha",
          note: "keep me"
        }
      },
      note: "Present text accepted; the authored read ignores note."
    },
    {
      id: "P04",
      operation: "probe",
      principal: "owner",
      input: {
        id: "dddddddd-dddd-4ddd-8ddd-dddddddddddd",
        title: "fallback"
      },
      expect: {
        kind: "success",
        value: "fallback"
      },
      host: {
        delay_ms: 11,
        read_missing: !0
      },
      assertions: [
        "Exactly the ItemMissing recovery arm executes once."
      ]
    },
    {
      id: "P05",
      operation: "probe",
      principal: "owner",
      input: {
        id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
        title: "fallback"
      },
      expect: {
        kind: "internal"
      },
      host: {
        delay_ms: 11,
        fault: "WASM_EXP1_SECRET_SENTINEL"
      },
      assertions: [
        "No recovery success; sentinel absent from safe output/logs."
      ]
    },
    {
      id: "P06",
      operation: "probe",
      principal: "owner",
      input: {
        id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
        title: "fallback"
      },
      expect: {
        kind: "internal"
      },
      host: {
        delay_ms: 7,
        read_row: {
          id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
          owner_id: "11111111-1111-4111-8111-111111111111",
          title: 42,
          note: "keep me"
        }
      },
      assertions: [
        "Malformed stored/host value is not invalid client input."
      ]
    },
    {
      id: "P07",
      operation: "probe",
      principal: "owner",
      input: {
        id: "not-a-uuid",
        title: "fallback"
      },
      expect: {
        kind: "invalid",
        host_calls: 0
      }
    },
    {
      id: "P08",
      operation: "probe",
      principal: "owner",
      input: {
        id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
        title: "ab"
      },
      expect: {
        kind: "invalid",
        host_calls: 0
      }
    },
    {
      id: "P09",
      operation: "probe",
      principal: "owner",
      input: {
        id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
        title: "abcdefghijklm"
      },
      expect: {
        kind: "invalid",
        host_calls: 0
      }
    },
    {
      id: "P10",
      operation: "probe",
      principal: "owner",
      input: {
        id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
        title: "fallback",
        note: 42
      },
      expect: {
        kind: "invalid",
        host_calls: 0
      }
    },
    {
      id: "P11",
      operation: "probe",
      principal: "owner",
      input: {
        id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
        title: "fallback",
        principal: "22222222-2222-4222-8222-222222222222"
      },
      expect: {
        kind: "invalid",
        host_calls: 0
      }
    },
    {
      id: "P12",
      operation: "probe",
      principal: "owner",
      raw_input: '{"id":',
      expect: {
        kind: "invalid",
        host_calls: 0
      }
    },
    {
      id: "P13",
      operation: "probe",
      interleaved: [
        {
          principal: "owner",
          input: {
            id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
            title: "fallback"
          },
          host_delay_ms: 19,
          expect: {
            kind: "success",
            value: "alpha"
          }
        },
        {
          principal: "other",
          input: {
            id: "cccccccc-cccc-4ccc-8ccc-cccccccccccc",
            title: "reserve",
            note: null
          },
          host_delay_ms: 1,
          expect: {
            kind: "success",
            value: "charlie"
          }
        }
      ],
      assertions: [
        "Each suspension keeps its own copied input, trusted principal, result, request ID, operation ID and memory.",
        "Each request completes once despite reversed completion order."
      ]
    },
    {
      id: "P14",
      operation: "probe",
      input: {
        id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
        title: "fallback"
      },
      principal: "owner",
      resume_mutations: [
        "wrong request ID",
        "wrong operation ID",
        "duplicate resume after completion",
        "resume after internal failure"
      ],
      expect: {
        fail_closed: !0,
        additional_host_calls: 0
      }
    },
    {
      id: "P15",
      operation: "probe",
      input: {
        id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
        title: "abcd"
      },
      source_mutation: {
        find: "min_length: 3",
        replace: "min_length: 5"
      },
      expect_before: {
        kind: "success",
        value: "alpha"
      },
      expect_after: {
        kind: "invalid",
        host_calls: 0
      },
      assertions: [
        "Rebuild from checked mutated source; restore frozen source afterwards."
      ]
    }
  ],
  full_slice_cases: [
    {
      id: "A01",
      operation: "Item.read",
      args: [
        "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa"
      ],
      principal: "owner",
      expect: {
        kind: "success",
        value: {
          id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
          owner_id: "11111111-1111-4111-8111-111111111111",
          title: "alpha",
          note: "keep me"
        }
      },
      assertions: [
        "Exact closed output; ABI status/envelope agrees with baseline adapter."
      ]
    },
    {
      id: "A02",
      probe_cases: [
        "P07",
        "P08",
        "P09",
        "P10",
        "P11",
        "P12"
      ],
      assertions: [
        "Rejected input reaches no host capability and mutates no state.",
        "Exercise Item.change argument parsing too: invalid id, short/long title and undeclared owner_id patch."
      ]
    },
    {
      id: "A03",
      operation: "Item.change",
      principal: "owner",
      sequence: [
        {
          args: [
            "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
            {
              title: "renamed"
            }
          ],
          expect_row: {
            id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
            owner_id: "11111111-1111-4111-8111-111111111111",
            title: "renamed",
            note: "keep me"
          }
        },
        {
          args: [
            "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
            {
              note: null
            }
          ],
          expect_row: {
            id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
            owner_id: "11111111-1111-4111-8111-111111111111",
            title: "renamed",
            note: null
          }
        }
      ],
      assertions: [
        "Omission preserves note; explicit null clears note; present empty text is distinct from null."
      ]
    },
    {
      id: "A04",
      operation: "Item.change",
      principal: "owner",
      cases: [
        {
          args: [
            "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
            {}
          ],
          expect_failure: "EmptyPatch"
        },
        {
          args: [
            "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
            {
              title: "x"
            }
          ],
          expect_kind: "invalid"
        },
        {
          args: [
            "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
            {
              note: 9
            }
          ],
          expect_kind: "invalid"
        }
      ],
      assertions: [
        "Complete authority snapshot unchanged after each attempt."
      ]
    },
    {
      id: "A05",
      operation: "Item.change",
      principal: "owner",
      cases: [
        {
          args: [
            "dddddddd-dddd-4ddd-8ddd-dddddddddddd",
            {
              title: "unused"
            }
          ],
          expect_failure: "ItemMissing"
        },
        {
          args: [
            "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
            {
              title: "bravo"
            }
          ],
          expect_failure: "ItemConflict"
        }
      ],
      assertions: [
        "Title uniqueness conflict and missing update preserve complete authority snapshot.",
        "Missing Item.read reports ItemMissing; probe alone recovers it."
      ]
    },
    {
      id: "A06",
      cases: [
        {
          operation: "Item.read",
          args: [
            "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa"
          ],
          principal: "owner",
          expect_kind: "success"
        },
        {
          operation: "Item.change",
          args: [
            "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
            {
              title: "renamed"
            }
          ],
          principal: "owner",
          expect_kind: "success"
        },
        {
          operation: "Item.read",
          args: [
            "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa"
          ],
          principal: "other",
          expect_failure: "ItemMissing"
        },
        {
          operation: "Item.change",
          args: [
            "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
            {
              title: "stolen"
            }
          ],
          principal: "other",
          expect_failure: "ItemMissing"
        }
      ],
      assertions: [
        "Reset fixture per case; outsider receives no owner row and cannot mutate it."
      ]
    },
    {
      id: "A07",
      operations: [
        "Item.read",
        "Item.change",
        "Item.rename"
      ],
      assertions: [
        "Capture executed SQL plus separately bound parameters for owner and outsider.",
        "Predicate includes both requested Item.id and checked owner_id/principal restriction.",
        "No interpolation of raw input; guessed owner item ID cannot bypass predicate."
      ]
    },
    {
      id: "A08",
      probe_cases: [
        "P06"
      ],
      corrupt_rows: [
        {
          field: "id",
          value: "not-a-uuid"
        },
        {
          field: "title",
          value: "x"
        },
        {
          field: "note",
          value: 42
        }
      ],
      assertions: [
        "Trusted fixture-only corruption bypasses DB constraints if needed; subsequent read becomes internal fault, never client400/invalid.",
        "Wrong host envelope and missing required host fields are internal faults."
      ]
    },
    {
      id: "A09",
      probe_cases: [
        "P04",
        "P05"
      ],
      assertions: [
        "Declared ItemMissing reaches exactly its authored arm.",
        "Unexpected storage error/trap is not reclassified as ItemMissing."
      ]
    },
    {
      id: "A10",
      operation: "update_pair",
      principal: "owner",
      cases: [
        {
          args: [
            "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
            "first-new",
            "dddddddd-dddd-4ddd-8ddd-dddddddddddd",
            "second-new"
          ],
          expect_failure: "ItemMissing"
        },
        {
          args: [
            "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
            "first-new",
            "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb",
            "charlie"
          ],
          expect_failure: "ItemConflict"
        },
        {
          args: [
            "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
            "first-new",
            "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb",
            "second-new"
          ],
          expect_kind: "success"
        }
      ],
      assertions: [
        "Failure cases compare complete before/after snapshots: no first write remains.",
        "Success commits both writes once.",
        "Handled nested mutation/savepoint scope is outside this slice and must fail closed if presented."
      ]
    },
    {
      id: "A11",
      operation: "update_pair",
      args: [
        "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
        "first-new",
        "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb",
        "second-new"
      ],
      principal: "owner",
      assertions: [
        "Instrument context IDs: authorization reads and guarded writes stay in the declared transaction.",
        "Subsequent authoritative Item.read observes committed first-new and second-new.",
        "No cached principal substitution or stale role result authorizes another request."
      ]
    },
    {
      id: "A12",
      probe_cases: [
        "P01",
        "P04",
        "P14"
      ],
      assertions: [
        "Force delayed success/failure and verify sequential continuation, one completion and exact pending IDs.",
        "In update_pair the second write cannot start before first write completes."
      ]
    },
    {
      id: "A13",
      probe_cases: [
        "P13"
      ],
      pair_count: 100,
      delays_ms: [
        [
          19,
          1
        ],
        [
          1,
          19
        ],
        [
          7,
          7
        ],
        [
          0,
          11
        ]
      ],
      assertions: [
        "Repeat the listed delay patterns deterministically.",
        "Insert a trapped request before a valid request; valid request sees no prior context or buffers."
      ]
    },
    {
      id: "A14",
      sentinel: "WASM_EXP1_SECRET_SENTINEL",
      assertions: [
        "Inject sentinel in host error detail and trusted private test context.",
        "Search public bodies, response headers and safe operational log events; sentinel and internal failure detail absent.",
        "Declared failures expose allowed names/codes only."
      ]
    },
    {
      id: "A15",
      fault_operations: [
        "Item.read",
        "Item.rename",
        "update_pair"
      ],
      assertions: [
        "Fault telemetry resolves the semantic operation ID to app.jadpo source range and frozen checked source digest/revision.",
        "No claim of full browser/Rust debug-symbol parity."
      ]
    },
    {
      id: "A16",
      sequence: [
        "Commit A10 successful update_pair.",
        "Run A10 missing-second failure against a fresh independent reset and capture snapshot.",
        "Reopen local authority/new cloud request for each independent run."
      ],
      assertions: [
        "Successful titles persist across reopen.",
        "Rejected first write remains absent; complete snapshot matches pre-failure state."
      ]
    },
    {
      id: "A17",
      negative_inputs: [
        "reachable unsupported accepted construct",
        "unapproved host import",
        "atomic cross-store plan",
        "unavailable authoritative freshness",
        "handled nested mutation/savepoint scope"
      ],
      assertions: [
        "Use isolated source/manifest mutations; normal Jadpo checks still gate valid source before backend lowering.",
        "Backend/host rejects unsupported capabilities before publishing or executing artifact; no downgrade to sequential non-atomic writes or stale read."
      ]
    },
    {
      id: "A18",
      probe_cases: [
        "P15"
      ],
      assertions: [
        "Clean checked rebuild uses source digest, projection digest, compiler/runtime/toolchain hashes and pinned flags.",
        "Equivalent rebuild reproduces behavior and manifest; record any binary nondeterminism separately."
      ]
    }
  ],
  result_requirements: {
    targets: [
      "Bun baseline",
      "local Wasm",
      "Cloudflare Wasm"
    ],
    per_case: [
      "pass/fail/not_run",
      "command",
      "artifact_hash",
      "source_hash",
      "actual_output",
      "storage_before_after_where_relevant"
    ],
    not_run_is_pass: !1
  },
  checked_semantic_facts: {
    canonical_entities: !0,
    entity_model: {
      Item: {
        identity: "id",
        store: "primary",
        role: "authority",
        unique: [
          "title"
        ]
      },
      User: {
        identity: "id",
        persistent: !1
      }
    },
    nominal_input: "ItemTitle refines Text with min_length 3 and max_length 12; Item.title/ProbeInput.title preserve their checked refinement relationships.",
    presence: "ProbeInput.note and ItemPatch.note independently carry optional presence and nullable value; absence is not null.",
    queries: {
      "Item.read": "authoritative, read_only, required Item.id predicate, ItemMissing on absence",
      "Item.read_title": "authoritative named read calling Item.read then projecting title"
    },
    policy: "Direct authoritative Item.owner_id binds ItemRole.owner to User; read/update entity policy obligations propagate to callers.",
    outcomes: "probe exhaustively handles ItemMissing and has no escaping declared failures; internal faults are not domain failures.",
    transactions: "update_pair checked atomic primary domain; Item.change/rename entity_action boundaries join declared boundary; propagated second failure rolls back outer transaction.",
    suspension: "All six callables are checked may_suspend with completion before caller continues.",
    lowering_input: "Use complete successfully checked AnalyzedProject, including parsed syntax, graph, typing, failures, entity_model and policy.",
    operation_name_spans: [
      {
        id: 22,
        kind: "action",
        name: "Item.change",
        source: "app.jadpo",
        start: 1287,
        end: 1293
      },
      {
        id: 26,
        kind: "query",
        name: "Item.read",
        source: "app.jadpo",
        start: 860,
        end: 864
      },
      {
        id: 27,
        kind: "query",
        name: "Item.read_title",
        source: "app.jadpo",
        start: 1092,
        end: 1102
      },
      {
        id: 28,
        kind: "action",
        name: "Item.rename",
        source: "app.jadpo",
        start: 1628,
        end: 1634
      },
      {
        id: 517,
        kind: "action",
        name: "probe",
        source: "app.jadpo",
        start: 1931,
        end: 1936
      },
      {
        id: 550,
        kind: "action",
        name: "update_pair",
        source: "app.jadpo",
        start: 2107,
        end: 2118
      }
    ]
  }
};

// experiments/wasm-exp1/read-path/compiler/build/row-codec.json
var row_codec_default = {
  version: 1,
  digest: "a6972568540ac2cb72326c0114bf824ef4699b139fb646bb1c34c32fc0febe02",
  readPlans: [
    {
      id: 26,
      schema: 20,
      jsonBase: 657,
      args: {
        entity: "Item",
        operation: "Item.read",
        semanticOperationId: 26,
        freshness: "authoritative",
        policy: {
          operation: {
            fieldReads: [],
            obligations: [
              {
                effect: "read",
                entity: "Item",
                origin: "entity",
                subjects: [
                  "ItemRole.owner"
                ]
              }
            ],
            operation: "Item.read"
          },
          bindings: [
            {
              entity: "Item",
              field: "owner_id",
              principalEntity: "User",
              role: "ItemRole.owner",
              scope: "Item"
            }
          ],
          entities: [
            {
              entity: "Item",
              fields: [],
              rules: [
                {
                  effects: [
                    "read",
                    "update"
                  ],
                  subject: "ItemRole.owner"
                }
              ],
              scope: "Item",
              scopeField: null
            }
          ]
        },
        predicate: {
          field: "id",
          operator: "equal"
        }
      }
    }
  ],
  records: [
    {
      id: 20,
      name: "Item",
      fields: [
        "id",
        "owner_id",
        "title",
        "note"
      ]
    },
    {
      id: 32,
      name: "ItemPatch",
      fields: [
        "title",
        "note"
      ]
    },
    {
      id: 57,
      name: "ProbeInput",
      fields: [
        "id",
        "title",
        "note"
      ]
    },
    {
      id: 84,
      name: "User",
      fields: [
        "id"
      ]
    }
  ],
  entries: {
    "22": 20,
    "26": 20,
    "28": 20,
    "550": 20
  }
};

// experiments/wasm-exp1/workerd-boundary/profile.ts
var assert = { equal(a, b) {
  if (a !== b) throw Error("profile assertion " + String(a).slice(0, 120) + " != " + String(b).slice(0, 120));
} };
function same(a, b) {
  if (a === b) return !0;
  if (!a || !b || typeof a != "object" || typeof b != "object") return !1;
  let keys = Object.keys(a);
  return keys.length === Object.keys(b).length && keys.every((k) => Object.hasOwn(b, k) && same(a[k], b[k]));
}
var enc = new TextEncoder(), dec = new TextDecoder("utf-8", { fatal: !0 });
function profileStages(storage, module, options) {
  if (![14, 15].includes(options.flags) || ![256, 16384, 49152].includes(options.size) || !["ascii", "escaped"].includes(options.kind) || !["Item.read", "Item.read_title"].includes(options.operation)) throw Error("profile bounds");
  let principal = { entity: "User", values: { id: acceptance_default.seeds.principals.owner.id } }, codec = rowCodec(row_codec_default), results = [], { flags, size, kind, operation } = options, escaped = kind === "escaped";
  {
    let rows = structuredClone(acceptance_default.seeds.Item);
    rows[0].note = escaped ? `\xE9\u4E2D\u{1F600}"\\
`.repeat(Math.floor(size / 32)) : "x".repeat(size), storage.resetFixture({ Item: rows });
    for (let name of [operation]) {
      let core = new WebAssembly.Instance(module).exports, op = program_default.declarations.find((d) => d.name === name).semanticId, ownedRows = /* @__PURE__ */ new Map(), totals = {}, counts = {}, record = !1, timed = (key, fn) => {
        let t = performance.now(), v = fn();
        return record && (totals[key] = (totals[key] ?? 0) + performance.now() - t), v;
      }, write3 = (key, value) => {
        let json = timed(key + "_stringify", () => JSON.stringify(value)), bytes = timed(key + "_utf8", () => enc.encode(json));
        return counts[key + "_bytes"] = bytes.length, [timed(key + "_alloc_copy", () => {
          let p2 = core.alloc(bytes.length);
          if (!p2) throw Error("allocation");
          return new Uint8Array(core.memory.buffer, p2, bytes.length).set(bytes), p2;
        }), bytes.length];
      }, read3 = (key) => {
        let bytes = timed(key + "_copy", () => new Uint8Array(core.memory.buffer, core.result_ptr(), core.result_len()).slice());
        if (counts[key + "_bytes"] = bytes.length, core.result_format() === 3) return timed("compact_host_decode", () => codec.pending(bytes));
        if (core.result_format() === 2) return timed("reference_host_decode", () => ({ kind: "success", value: codec.reference(codec.schema("Item"), bytes, ownedRows) }));
        if (core.result_format() === 1) return timed("binary_host_decode", () => ({ kind: "success", value: codec.decode(codec.schema("Item"), bytes) }));
        let json = timed(key + "_utf8", () => dec.decode(bytes));
        return timed(key + "_parse", () => JSON.parse(json));
      }, run = () => {
        assert.equal(timed("reset", () => core.reset()), 1), core.set_row_transport(flags), ownedRows.clear();
        let [p, n] = write3("input", rows[0].id);
        assert.equal(timed("guest_start", () => core.start(op, p, n)), 2);
        let pending = read3("pending"), result = timed("host_sql_and_validation", () => storage.read(pending.args, principal));
        if (flags & 4) {
          let owned = timed("snapshot", () => codec.snapshot(codec.schema("Item"), result.value));
          ownedRows.set(pending.requestId + ":" + pending.operationId, { schema: codec.schema("Item"), row: owned }), result = { kind: "success", value: owned };
        }
        let rp, rn;
        if (flags & 1) {
          let b = timed("host_binary_encode", () => codec.encode(codec.schema("Item"), result.value));
          counts.row_bytes = b.length, rp = timed("row_alloc_copy", () => {
            let p2 = core.alloc(b.length);
            return new Uint8Array(core.memory.buffer, p2, b.length).set(b), p2;
          }), rn = b.length;
        } else [rp, rn] = write3("row", result);
        let resume3 = flags & 1 ? flags & 4 ? core.resume_row_ref : core.resume_row : flags & 4 ? core.resume_ref : core.resume;
        assert.equal(timed("guest_resume_decode_validate_execute_encode", () => resume3(pending.requestId, pending.operationId, rp, rn)), 0);
        let output = read3("terminal");
        assert.equal(same(output, { kind: "success", value: name === "Item.read" ? rows[0] : rows[0].title }), !0), timed("http_stringify", () => JSON.stringify(output));
      };
      for (let i = 0; i < 200; i++) run();
      record = !0;
      for (let i = 0; i < 2e3; i++) run();
      results.push({ flags, name, size, escaped, counts, meanUs: Object.fromEntries(Object.entries(totals).map(([k, v]) => [k, v * 1e3 / 2e3])) });
    }
  }
  return { scope: "Local workerd instrumented component means; observer overhead, not additive request p95. Every response checked.", results };
}

// experiments/wasm-exp1/workerd-boundary/worker.ts
import { DurableObject } from "cloudflare:workers";
import candidate from "./candidate.wasm";
import previous from "./previous.wasm";
import typed from "./typed.wasm";
import views from "./views.wasm";
import fused from "./fused.wasm";

// experiments/wasm-exp1/workerd-boundary/codec.ts
var encoder2 = new TextEncoder(), decoder2 = new TextDecoder("utf-8", { fatal: !0, ignoreBOM: !0 }), LIMIT2 = 65536;
function rowCodec2(meta) {
  if (meta.version !== 1 || !/^[0-9a-f]{64}$/.test(meta.digest)) throw Error("schema");
  let digest = Uint8Array.from(meta.digest.match(/../g).map((x) => parseInt(x, 16))), records = new Map(meta.records.map((r) => [r.id, { ...r, keys: new Set(r.fields), keyBytes: new Map(r.fields.map((k) => [k, encoder2.encode(JSON.stringify(k)).length])) }])), names = new Map(meta.records.map((r) => [r.name, r.id])), freeze2 = (value) => {
    if (value && typeof value == "object") {
      for (let v of Object.values(value)) freeze2(v);
      Object.freeze(value);
    }
    return value;
  }, plans2 = new Map((meta.readPlans ?? []).map((p) => [p.id, freeze2(structuredClone(p))])), buffer = new Uint8Array(LIMIT2), view = new DataView(buffer.buffer);
  return {
    pending(bytes) {
      if (bytes.length < 49 || bytes.length > LIMIT2 || bytes[0] !== 74 || bytes[1] !== 82 || bytes[2] !== 80 || bytes[3] !== 49 || digest.some((v, i) => bytes[4 + i] !== v)) throw Error("pending-header");
      let view2 = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength), requestId = view2.getUint32(36, !0), operationId = view2.getUint32(40, !0), id = view2.getUint32(44, !0), plan = plans2.get(id);
      if (!requestId || requestId > 2147483647 || !operationId || operationId > 64 || !plan || !records.has(plan.schema)) throw Error("pending-identity");
      let value = JSON.parse(decoder2.decode(bytes.subarray(48)));
      if (plan.jsonBase - 4 + encoder2.encode(JSON.stringify(value)).length + String(requestId).length - 1 + String(operationId).length - 1 > LIMIT2) throw Error("pending-size");
      return { kind: "pending", requestId, operationId, capability: "storage.read", args: { ...plan.args, predicate: { ...plan.args.predicate, value } } };
    },
    snapshot(id, row) {
      let schema = records.get(id);
      if (!schema || !row || typeof row != "object" || Array.isArray(row)) throw Error("row-shape");
      let owned = { ...row };
      for (let key of Object.keys(owned)) {
        if (!schema.keys.has(key)) throw Error("row-shape");
        let value = owned[key];
        if (value !== null && typeof value != "string" && typeof value != "boolean" && !(typeof value == "number" && Number.isSafeInteger(value))) throw Error("row-field");
        Object.is(value, -0) && (owned[key] = 0);
      }
      return owned;
    },
    reference(expected, bytes, rows) {
      if (bytes.length !== 48 || bytes[0] !== 74 || bytes[1] !== 82 || bytes[2] !== 82 || bytes[3] !== 49 || digest.some((v, i) => bytes[4 + i] !== v)) throw Error("reference-header");
      let view2 = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength), schema = view2.getUint32(36, !0), request = view2.getUint32(40, !0), operation = view2.getUint32(44, !0), found = rows.get(request + ":" + operation);
      if (!records.has(schema) || schema !== expected || !found || found.schema !== schema || request === 0 || operation === 0) throw Error("reference-identity");
      return { ...found.row };
    },
    schema: (name) => typeof name == "string" ? names.get(name) : void 0,
    resultSchema: (entry) => meta.entries[String(entry)],
    encode(id, row) {
      let schema = records.get(id);
      if (!schema || !row || typeof row != "object" || Array.isArray(row) || Object.keys(row).some((k) => !schema.keys.has(k))) throw Error("row-shape");
      let jsonBound = 29, present = 0;
      buffer.set([74, 82, 87, 49]), buffer.set(digest, 4), view.setUint32(36, id, !0);
      let pos = 40, room = (n) => {
        if (pos + n > LIMIT2) throw Error("row-size");
      };
      for (let key of schema.fields) {
        if (room(1), !Object.hasOwn(row, key)) {
          buffer[pos++] = 0;
          continue;
        }
        let value = row[key];
        if (jsonBound += schema.keyBytes.get(key) + 1 + +(present++ > 0), value === null) {
          jsonBound += 4, buffer[pos++] = 1;
          continue;
        }
        if (typeof value == "string") {
          if (!value.isWellFormed()) throw Error("row-utf16");
          room(5), buffer[pos++] = 2;
          let lengthOffset = pos;
          pos += 4;
          let { read: read3, written } = encoder2.encodeInto(value, buffer.subarray(pos));
          if (read3 !== value.length) throw Error("row-size");
          view.setUint32(lengthOffset, written, !0), pos += written, jsonBound += written + 2 + (/[\"\\\x00-\x1f]/.test(value) ? JSON.stringify(value).length - value.length - 2 : 0);
        } else if (typeof value == "boolean")
          buffer[pos++] = value ? 4 : 3, jsonBound += value ? 4 : 5;
        else if (typeof value == "number" && Number.isSafeInteger(value))
          room(9), buffer[pos++] = 5, view.setBigInt64(pos, BigInt(value), !0), pos += 8, jsonBound += String(value).length;
        else throw Error("row-field");
      }
      if (jsonBound > LIMIT2) throw Error("row-json-size");
      return buffer.subarray(0, pos);
    },
    decode(expected, bytes) {
      if (bytes.length < 40 || bytes.length > LIMIT2 || bytes[0] !== 74 || bytes[1] !== 82 || bytes[2] !== 87 || bytes[3] !== 49 || digest.some((v, i) => bytes[4 + i] !== v)) throw Error("row-header");
      let dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength), id = dv.getUint32(36, !0), schema = records.get(id);
      if (id !== expected || !schema) throw Error("row-schema");
      let pos = 40, row = {}, room = (n) => {
        if (pos + n > bytes.length) throw Error("row-truncated");
      };
      for (let key of schema.fields) {
        room(1);
        let tag = bytes[pos++], value;
        if (tag !== 0) {
          if (tag === 1) value = null;
          else if (tag === 3 || tag === 4) value = tag === 4;
          else if (tag === 2) {
            room(4);
            let n = dv.getUint32(pos, !0);
            pos += 4, room(n), value = decoder2.decode(bytes.subarray(pos, pos + n)), pos += n;
          } else if (tag === 5) {
            if (room(8), value = Number(dv.getBigInt64(pos, !0)), pos += 8, !Number.isSafeInteger(value)) throw Error("row-integer");
          } else throw Error("row-tag");
          Object.defineProperty(row, key, { value, enumerable: !0, writable: !0, configurable: !0 });
        }
      }
      if (pos !== bytes.length) throw Error("row-trailing");
      return row;
    }
  };
}

// experiments/wasm-exp1/workerd-boundary/driver.ts
var transports = /* @__PURE__ */ new WeakMap();
function configureRows(module, meta, flags = 3) {
  if (!Number.isInteger(flags) || flags < 0 || flags > 15) throw Error("row-flags");
  transports.set(module, { flags, codec: rowCodec2(meta) });
}
var BUFFER_LIMIT = 65536, MEMORY_LIMIT = 128 * 65536, encoder3 = new TextEncoder(), decoder3 = new TextDecoder("utf-8", { fatal: !0 }), internal = () => ({ kind: "internal", message: "Unexpected internal failure." });
function bounds(core, pointer, length) {
  if (!Number.isInteger(pointer) || !Number.isInteger(length) || pointer < 0 || length < 0 || length > BUFFER_LIMIT || core.memory.buffer.byteLength > MEMORY_LIMIT || pointer > core.memory.buffer.byteLength - length) throw new Error("boundary-pointer");
}
function write(core, value) {
  let json = JSON.stringify(value);
  if (typeof json != "string" || json.length > BUFFER_LIMIT) throw Error("boundary-size");
  let capacity = Math.min(BUFFER_LIMIT, json.length * 3), pointer = core.alloc(capacity);
  if (!pointer) throw Error("boundary-allocation");
  bounds(core, pointer, capacity);
  let { read: read3, written } = encoder3.encodeInto(json, new Uint8Array(core.memory.buffer, pointer, capacity));
  if (read3 !== json.length) throw Error("boundary-size");
  return [pointer, written];
}
function read(core, transport, operation, status, rows) {
  let pointer = core.result_ptr(), length = core.result_len();
  bounds(core, pointer, length);
  let bytes = new Uint8Array(core.memory.buffer, pointer, length), format = core.result_format?.() ?? 0;
  if (format === 3) {
    if (status !== 2 || !transport || (transport.flags & 8) === 0) throw Error("pending-format");
    return transport.codec.pending(bytes);
  }
  if (format === 2) {
    if (status !== 0 || !transport || (transport.flags & 4) === 0) throw Error("reference-format");
    return { kind: "success", value: transport.codec.reference(transport.codec.resultSchema(operation), bytes, rows) };
  }
  if (format !== 0) {
    if (format !== 1 || status !== 0 || !transport || (transport.flags & 2) === 0) throw Error("row-format");
    return { kind: "success", value: transport.codec.decode(transport.codec.resultSchema(operation), bytes) };
  }
  let result = JSON.parse(decoder3.decode(bytes));
  if (!result || typeof result != "object" || Array.isArray(result) || typeof result.kind != "string")
    throw new Error("boundary-envelope");
  return result;
}
function resume(core, transport, pending, result, request, operation, rows) {
  let args = pending.args, schema = transport?.codec.schema(args?.entity), owned;
  if (transport && transport.flags & 4 && schema !== void 0 && pending.capability === "storage.read" && result.kind === "success" && result.value !== null && Object.keys(result).length === 2 && Object.hasOwn(result, "value") && Object.values(result.value).some((v) => typeof v == "string" && v.length >= 1024))
    try {
      let snapshot = transport.codec.snapshot(schema, result.value);
      Object.values(snapshot).some((v) => typeof v == "string" && v.length >= 1024) && (owned = snapshot, rows.set(request + ":" + operation, { schema, row: owned }), result = { kind: "success", value: owned });
    } catch {
    }
  if (transport && transport.flags & 1 && core.resume_row && pending.capability === "storage.read" && result.kind === "success" && result.value !== null && schema !== void 0 && Object.values(result.value).some((v) => typeof v == "string" && v.length >= 1024)) {
    if (Object.keys(result).length !== 2 || !Object.hasOwn(result, "value")) throw Error("row-envelope");
    let bytes;
    try {
      bytes = transport.codec.encode(schema, result.value);
    } catch {
    }
    if (bytes) {
      let p2 = core.alloc(bytes.length);
      if (!p2) throw Error("row-allocation");
      return bounds(core, p2, bytes.length), new Uint8Array(core.memory.buffer, p2, bytes.length).set(bytes), owned && core.resume_row_ref ? core.resume_row_ref(request, operation, p2, bytes.length) : core.resume_row(request, operation, p2, bytes.length);
    }
  }
  let [p, n] = write(core, result);
  return owned && core.resume_ref ? core.resume_ref(request, operation, p, n) : core.resume(request, operation, p, n);
}
var idle = /* @__PURE__ */ new WeakMap(), poolStats = { created: 0, reused: 0, returned: 0, discarded: 0, active: 0, peakActive: 0, maxRetainedPages: 0, maxIdle: 0 }, MAX_IDLE = 8, MAX_RETAINED_PAGES = 32;
function acquire(module, imports) {
  let pool = idle.get(module) ?? [];
  idle.set(module, pool);
  let core;
  if (Object.keys(imports).length === 0 && WebAssembly.Module.imports(module).length === 0)
    for (; pool.length; ) {
      let candidate2 = pool.pop();
      try {
        if (candidate2.reset?.() === 1) {
          core = candidate2, poolStats.reused++;
          break;
        }
      } catch {
      }
      poolStats.discarded++;
    }
  return core || (core = new WebAssembly.Instance(module, imports).exports, poolStats.created++), poolStats.active++, poolStats.peakActive = Math.max(poolStats.peakActive, poolStats.active), core;
}
function release(module, core, reusable, imports) {
  if (!core) return;
  poolStats.active--;
  let pool = idle.get(module);
  reusable && typeof core.reset == "function" && core.memory instanceof WebAssembly.Memory && core.memory.buffer.byteLength <= MAX_RETAINED_PAGES * 65536 && pool.length < MAX_IDLE && Object.keys(imports).length === 0 && WebAssembly.Module.imports(module).length === 0 ? (pool.push(core), poolStats.returned++, poolStats.maxRetainedPages = Math.max(poolStats.maxRetainedPages, core.memory.buffer.byteLength / 65536), poolStats.maxIdle = Math.max(poolStats.maxIdle, pool.length)) : poolStats.discarded++;
}
function invokeSync(module, operation, input, dispatch, imports = {}) {
  let leased, reusable = !1, rows = /* @__PURE__ */ new Map();
  try {
    let core = leased = acquire(module, imports), transport = transports.get(module);
    if (transport && core.set_row_transport?.(transport.flags) !== 1) throw Error("row-negotiation");
    if (!(core.memory instanceof WebAssembly.Memory)) return internal();
    let [pointer, length] = write(core, input), status = core.start(operation, pointer, length), previousOperation = 0, requestId;
    for (let steps = 0; steps < 64; steps++) {
      let output = read(core, transport, operation, status, rows);
      if (status !== 2)
        return { 0: "success", 1: "domain", 3: "internal", 4: "invalid" }[status] !== output.kind ? internal() : (reusable = status !== 3, output);
      if (output.kind !== "pending" || !Number.isSafeInteger(output.requestId) || !Number.isSafeInteger(output.operationId) || typeof output.capability != "string" || output.operationId <= previousOperation || requestId !== void 0 && output.requestId !== requestId) return internal();
      requestId = output.requestId, previousOperation = output.operationId;
      let result;
      try {
        result = dispatch(output.capability, output.args);
      } catch {
        result = internal();
      }
      (!result || typeof result.then == "function" || !["success", "domain", "internal"].includes(result.kind)) && (result = internal()), status = resume(core, transport, output, result, requestId, previousOperation, rows);
    }
    return internal();
  } catch {
    return internal();
  } finally {
    release(module, leased, reusable, imports);
  }
}

// experiments/wasm-exp1/read-path/driver.ts
var transports2 = /* @__PURE__ */ new WeakMap();
function configureRows2(module, meta, flags = 3) {
  if (!Number.isInteger(flags) || flags < 0 || flags > 15) throw Error("row-flags");
  transports2.set(module, { flags, codec: rowCodec(meta) });
}
var BUFFER_LIMIT2 = 65536, MEMORY_LIMIT2 = 128 * 65536, encoder4 = new TextEncoder(), decoder4 = new TextDecoder("utf-8", { fatal: !0 }), internal2 = () => ({ kind: "internal", message: "Unexpected internal failure." });
function boundedEncode(value) {
  let bytes = encoder4.encode(JSON.stringify(value));
  if (bytes.length > BUFFER_LIMIT2) throw new Error("boundary-size");
  return bytes;
}
function bounds2(core, pointer, length) {
  if (!Number.isInteger(pointer) || !Number.isInteger(length) || pointer < 0 || length < 0 || length > BUFFER_LIMIT2 || core.memory.buffer.byteLength > MEMORY_LIMIT2 || pointer > core.memory.buffer.byteLength - length) throw new Error("boundary-pointer");
}
function write2(core, value) {
  let bytes = boundedEncode(value), pointer = core.alloc(bytes.length);
  if (!pointer) throw new Error("boundary-allocation");
  return bounds2(core, pointer, bytes.length), new Uint8Array(core.memory.buffer, pointer, bytes.length).set(bytes), [pointer, bytes.length];
}
function read2(core, transport, operation, status, rows) {
  let pointer = core.result_ptr(), length = core.result_len();
  bounds2(core, pointer, length);
  let bytes = new Uint8Array(core.memory.buffer, pointer, length).slice(), format = core.result_format?.() ?? 0;
  if (format === 3) {
    if (status !== 2 || !transport || (transport.flags & 8) === 0) throw Error("pending-format");
    return transport.codec.pending(bytes);
  }
  if (format === 2) {
    if (status !== 0 || !transport || (transport.flags & 4) === 0) throw Error("reference-format");
    return { kind: "success", value: transport.codec.reference(transport.codec.resultSchema(operation), bytes, rows) };
  }
  if (format !== 0) {
    if (format !== 1 || status !== 0 || !transport || (transport.flags & 2) === 0) throw Error("row-format");
    return { kind: "success", value: transport.codec.decode(transport.codec.resultSchema(operation), bytes) };
  }
  let result = JSON.parse(decoder4.decode(bytes));
  if (!result || typeof result != "object" || Array.isArray(result) || typeof result.kind != "string")
    throw new Error("boundary-envelope");
  return result;
}
function resume2(core, transport, pending, result, request, operation, rows) {
  let args = pending.args, schema = transport?.codec.schema(args?.entity), owned;
  if (transport && transport.flags & 4 && schema !== void 0 && pending.capability === "storage.read" && result.kind === "success" && result.value !== null && Object.keys(result).length === 2 && Object.hasOwn(result, "value") && Object.values(result.value).some((v) => typeof v == "string" && v.length >= 1024))
    try {
      let snapshot = transport.codec.snapshot(schema, result.value);
      Object.values(snapshot).some((v) => typeof v == "string" && v.length >= 1024) && (owned = snapshot, rows.set(request + ":" + operation, { schema, row: owned }), result = { kind: "success", value: owned });
    } catch {
    }
  if (transport && transport.flags & 1 && core.resume_row && pending.capability === "storage.read" && result.kind === "success" && result.value !== null && schema !== void 0 && Object.values(result.value).some((v) => typeof v == "string" && v.length >= 1024)) {
    if (Object.keys(result).length !== 2 || !Object.hasOwn(result, "value")) throw Error("row-envelope");
    let bytes;
    try {
      bytes = transport.codec.encode(schema, result.value);
    } catch {
    }
    if (bytes) {
      let p2 = core.alloc(bytes.length);
      if (!p2) throw Error("row-allocation");
      return bounds2(core, p2, bytes.length), new Uint8Array(core.memory.buffer, p2, bytes.length).set(bytes), owned && core.resume_row_ref ? core.resume_row_ref(request, operation, p2, bytes.length) : core.resume_row(request, operation, p2, bytes.length);
    }
  }
  let [p, n] = write2(core, result);
  return owned && core.resume_ref ? core.resume_ref(request, operation, p, n) : core.resume(request, operation, p, n);
}
var idle2 = /* @__PURE__ */ new WeakMap(), poolStats2 = { created: 0, reused: 0, returned: 0, discarded: 0, active: 0, peakActive: 0, maxRetainedPages: 0, maxIdle: 0 }, MAX_IDLE2 = 8, MAX_RETAINED_PAGES2 = 32;
function acquire2(module, imports) {
  let pool = idle2.get(module) ?? [];
  idle2.set(module, pool);
  let core;
  if (Object.keys(imports).length === 0 && WebAssembly.Module.imports(module).length === 0)
    for (; pool.length; ) {
      let candidate2 = pool.pop();
      try {
        if (candidate2.reset?.() === 1) {
          core = candidate2, poolStats2.reused++;
          break;
        }
      } catch {
      }
      poolStats2.discarded++;
    }
  return core || (core = new WebAssembly.Instance(module, imports).exports, poolStats2.created++), poolStats2.active++, poolStats2.peakActive = Math.max(poolStats2.peakActive, poolStats2.active), core;
}
function release2(module, core, reusable, imports) {
  if (!core) return;
  poolStats2.active--;
  let pool = idle2.get(module);
  reusable && typeof core.reset == "function" && core.memory instanceof WebAssembly.Memory && core.memory.buffer.byteLength <= MAX_RETAINED_PAGES2 * 65536 && pool.length < MAX_IDLE2 && Object.keys(imports).length === 0 && WebAssembly.Module.imports(module).length === 0 ? (pool.push(core), poolStats2.returned++, poolStats2.maxRetainedPages = Math.max(poolStats2.maxRetainedPages, core.memory.buffer.byteLength / 65536), poolStats2.maxIdle = Math.max(poolStats2.maxIdle, pool.length)) : poolStats2.discarded++;
}
function invokeSync2(module, operation, input, dispatch, imports = {}) {
  let leased, reusable = !1, rows = /* @__PURE__ */ new Map();
  try {
    let core = leased = acquire2(module, imports), transport = transports2.get(module);
    if (transport && core.set_row_transport?.(transport.flags) !== 1) throw Error("row-negotiation");
    if (!(core.memory instanceof WebAssembly.Memory)) return internal2();
    let [pointer, length] = write2(core, input), status = core.start(operation, pointer, length), previousOperation = 0, requestId;
    for (let steps = 0; steps < 64; steps++) {
      let output = read2(core, transport, operation, status, rows);
      if (status !== 2)
        return { 0: "success", 1: "domain", 3: "internal", 4: "invalid" }[status] !== output.kind ? internal2() : (reusable = status !== 3, output);
      if (output.kind !== "pending" || !Number.isSafeInteger(output.requestId) || !Number.isSafeInteger(output.operationId) || typeof output.capability != "string" || output.operationId <= previousOperation || requestId !== void 0 && output.requestId !== requestId) return internal2();
      requestId = output.requestId, previousOperation = output.operationId;
      let result;
      try {
        result = dispatch(output.capability, output.args);
      } catch {
        result = internal2();
      }
      (!result || typeof result.then == "function" || !["success", "domain", "internal"].includes(result.kind)) && (result = internal2()), status = resume2(core, transport, output, result, requestId, previousOperation, rows);
    }
    return internal2();
  } catch {
    return internal2();
  } finally {
    release2(module, leased, reusable, imports);
  }
}

// experiments/wasm-exp1/typed-values/codec.ts
var encoder5 = new TextEncoder(), decoder5 = new TextDecoder("utf-8", { fatal: !0, ignoreBOM: !0 }), LIMIT3 = 65536;
function rowCodec3(meta) {
  if (meta.version !== 1 || !/^[0-9a-f]{64}$/.test(meta.digest)) throw Error("schema");
  let digest = Uint8Array.from(meta.digest.match(/../g).map((x) => parseInt(x, 16))), records = new Map(meta.records.map((r) => [r.id, { ...r, keys: new Set(r.fields) }])), names = new Map(meta.records.map((r) => [r.name, r.id])), buffer = new Uint8Array(LIMIT3), view = new DataView(buffer.buffer);
  return {
    schema: (name) => typeof name == "string" ? names.get(name) : void 0,
    resultSchema: (entry) => meta.entries[String(entry)],
    encode(id, row) {
      let schema = records.get(id);
      if (!schema || !row || typeof row != "object" || Array.isArray(row) || Object.keys(row).some((k) => !schema.keys.has(k))) throw Error("row-shape");
      if (encoder5.encode(JSON.stringify({ kind: "success", value: row })).length > LIMIT3) throw Error("row-json-size");
      buffer.set([74, 82, 87, 49]), buffer.set(digest, 4), view.setUint32(36, id, !0);
      let pos = 40, room = (n) => {
        if (pos + n > LIMIT3) throw Error("row-size");
      };
      for (let key of schema.fields) {
        if (room(1), !Object.hasOwn(row, key)) {
          buffer[pos++] = 0;
          continue;
        }
        let value = row[key];
        if (value === null) {
          buffer[pos++] = 1;
          continue;
        }
        if (typeof value == "string") {
          if (!value.isWellFormed()) throw Error("row-utf16");
          room(5), buffer[pos++] = 2;
          let lengthOffset = pos;
          pos += 4;
          let { read: read3, written } = encoder5.encodeInto(value, buffer.subarray(pos));
          if (read3 !== value.length) throw Error("row-size");
          view.setUint32(lengthOffset, written, !0), pos += written;
        } else if (typeof value == "boolean") buffer[pos++] = value ? 4 : 3;
        else if (typeof value == "number" && Number.isSafeInteger(value))
          room(9), buffer[pos++] = 5, view.setBigInt64(pos, BigInt(value), !0), pos += 8;
        else throw Error("row-field");
      }
      return buffer.subarray(0, pos);
    },
    decode(expected, bytes) {
      if (bytes.length < 40 || bytes.length > LIMIT3 || bytes[0] !== 74 || bytes[1] !== 82 || bytes[2] !== 87 || bytes[3] !== 49 || digest.some((v, i) => bytes[4 + i] !== v)) throw Error("row-header");
      let dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength), id = dv.getUint32(36, !0), schema = records.get(id);
      if (id !== expected || !schema) throw Error("row-schema");
      let pos = 40, row = {}, room = (n) => {
        if (pos + n > bytes.length) throw Error("row-truncated");
      };
      for (let key of schema.fields) {
        room(1);
        let tag = bytes[pos++], value;
        if (tag !== 0) {
          if (tag === 1) value = null;
          else if (tag === 3 || tag === 4) value = tag === 4;
          else if (tag === 2) {
            room(4);
            let n = dv.getUint32(pos, !0);
            pos += 4, room(n), value = decoder5.decode(bytes.subarray(pos, pos + n)), pos += n;
          } else if (tag === 5) {
            if (room(8), value = Number(dv.getBigInt64(pos, !0)), pos += 8, !Number.isSafeInteger(value)) throw Error("row-integer");
          } else throw Error("row-tag");
          Object.defineProperty(row, key, { value, enumerable: !0, writable: !0, configurable: !0 });
        }
      }
      if (pos !== bytes.length) throw Error("row-trailing");
      return row;
    }
  };
}

// experiments/wasm-exp1/typed-values/driver.ts
var transports3 = /* @__PURE__ */ new WeakMap();
function configureRows3(module, meta, flags = 3) {
  if (!Number.isInteger(flags) || flags < 0 || flags > 3) throw Error("row-flags");
  transports3.set(module, { flags, codec: rowCodec3(meta) });
}
var MEMORY_LIMIT3 = 128 * 65536, encoder6 = new TextEncoder(), decoder6 = new TextDecoder("utf-8", { fatal: !0 });

// experiments/wasm-exp1/typed-values/compiler/build/row-codec.json
var row_codec_default2 = {
  version: 1,
  digest: "a6972568540ac2cb72326c0114bf824ef4699b139fb646bb1c34c32fc0febe02",
  records: [
    {
      id: 20,
      name: "Item",
      fields: [
        "id",
        "owner_id",
        "title",
        "note"
      ]
    },
    {
      id: 32,
      name: "ItemPatch",
      fields: [
        "title",
        "note"
      ]
    },
    {
      id: 57,
      name: "ProbeInput",
      fields: [
        "id",
        "title",
        "note"
      ]
    },
    {
      id: 84,
      name: "User",
      fields: [
        "id"
      ]
    }
  ],
  entries: {
    "22": 20,
    "26": 20,
    "28": 20,
    "550": 20
  }
};

// experiments/wasm-exp1/boundary-http/adapter.ts
var UnsupportedStorage = class extends Error {
  constructor(reason) {
    super(`WASM_STORAGE_UNSUPPORTED:${reason}`);
  }
}, reject = (reason) => {
  throw new UnsupportedStorage(reason);
}, ident = (value) => (/^[A-Za-z_][A-Za-z0-9_]*$/.test(value) || reject("identifier"), `"${value}"`), isObject = (value) => value !== null && typeof value == "object" && !Array.isArray(value), closed = (value, keys) => {
  (!isObject(value) || Object.keys(value).some((k) => !keys.includes(k))) && reject("closed_request");
}, syncResult = (value) => (value !== null && (typeof value == "object" || typeof value == "function") && typeof value.then == "function" && reject("async_transaction"), value);
function compileDescriptor(expected) {
  if (Array.isArray(expected)) {
    let checks = expected.map(compileDescriptor);
    return (candidate2) => Array.isArray(candidate2) && candidate2.length === checks.length && checks.every((check, i) => check(candidate2[i]));
  }
  if (isObject(expected)) {
    let entries = Object.entries(expected).map(([key, value]) => [key, compileDescriptor(value)]);
    return (candidate2) => isObject(candidate2) && Object.keys(candidate2).length === entries.length && entries.every(([key, check]) => Object.hasOwn(candidate2, key) && check(candidate2[key]));
  }
  return (candidate2) => candidate2 === expected;
}
function createStorage(programInput, sql, options = { authoritative: !0 }) {
  let program = structuredClone(programInput);
  (program?.kind !== "jadpo_checked_executable_projection" || program.schemaVersion !== 1) && reject("projection");
  let declarations2 = new Map(program.declarations.map((d) => [d.name, d])), entities = new Map(program.entities.map((e) => [e.name, e])), persistent = program.entities.filter((e) => e.persistent), stores = new Set(persistent.map((e) => e.authorityStore));
  (stores.size !== 1 || [...stores][0] === null) && reject("cross_store");
  let store = [...stores][0];
  options.authoritative || reject("authoritative_unavailable");
  for (let query of program.queries) (query.plan !== "authoritative" || query.freshness !== "authoritative") && reject("query_freshness");
  let tables = /* @__PURE__ */ new Map(), names = /* @__PURE__ */ new Set();
  for (let entity of persistent) {
    let record = declarations2.get(entity.name);
    (record?.kind !== "record" || !record.persistent) && reject("entity_record");
    let table = `entity_${entity.name}`;
    ident(table), names.has(table.toLowerCase()) && reject("table_collision"), names.add(table.toLowerCase());
    let fields = /* @__PURE__ */ new Map(), fieldNames = /* @__PURE__ */ new Set();
    for (let field of record.fields) {
      ident(field.name), fieldNames.has(field.name.toLowerCase()) && reject("field_collision"), fieldNames.add(field.name.toLowerCase());
      let type = program.effectiveTypes[`${entity.name}.${field.name}`];
      (!type || !["Text", "Uuid"].includes(type.base) || field.optional || field.reference !== null) && reject("field_type"), type.constraints.some((c) => !["MinLength", "MaxLength"].includes(c.kind)) && reject("constraint"), field.storage.some((s) => !["Identity", "Unique"].includes(s)) && reject("storage_annotation"), fields.set(field.name, { ...field, effective: type });
    }
    fields.has(entity.identity) || reject("identity"), tables.set(entity.name, { ...entity, table, fields });
  }
  for (let t of program.transactions)
    (t.domain !== store || t.owners.some((o) => entities.get(o)?.authorityStore !== store) || t.nested !== "join_declared_boundary") && reject("transaction_domain");
  let writes = new Set(program.transactions.map((t) => t.action)), changed = !0;
  for (; changed; ) {
    changed = !1;
    for (let edge of program.callEdges) {
      let caller = program.declarations.find((d) => d.semanticId === edge.caller)?.name, callee = program.declarations.find((d) => d.semanticId === edge.callee)?.name;
      writes.has(callee) && !writes.has(caller) && (writes.add(caller), changed = !0);
    }
  }
  function inspect(value) {
    if (!(!value || typeof value != "object")) {
      value.op === "outcomeMatch" && value.subject?.op === "call" && writes.has(value.subject.target) && reject("handled_nested_mutation");
      for (let child of Object.values(value)) Array.isArray(child) ? child.forEach(inspect) : inspect(child);
    }
  }
  program.declarations.forEach((d) => inspect(d.body));
  for (let entity of program.policy.entities) (entity.scope !== entity.entity || entity.scopeField !== null || entity.fields.length) && reject("indirect_or_field_policy");
  for (let binding of program.policy.bindings) (binding.scope !== binding.entity || !tables.get(binding.entity)?.fields.has(binding.field) || !entities.get(binding.principalEntity)?.identity) && reject("indirect_binding");
  function validate(table, field, value) {
    let f = table.fields.get(field);
    f || reject("unknown_field");
    let t = f.effective;
    if (value === null)
      return t.nullable || reject("null_value"), null;
    typeof value != "string" && reject("field_value"), t.base === "Uuid" && !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/iu.test(value) && reject("uuid_value");
    let length = t.constraints.length ? [...value].length : 0;
    for (let c of t.constraints) (c.kind === "MinLength" && length < c.value || c.kind === "MaxLength" && length > c.value) && reject("constraint_value");
    return value;
  }
  function validateRow(table, row) {
    return Object.keys(row).length !== table.fields.size && reject("stored_shape"), Object.fromEntries([...table.fields.keys()].map((field) => [field, validate(table, field, row[field])]));
  }
  function setup() {
    for (let table of tables.values()) {
      let columns = [...table.fields.values()].map((f) => `${ident(f.name)} TEXT${f.effective.nullable ? "" : " NOT NULL"}${f.name === table.identity ? " PRIMARY KEY" : ""}${f.storage.includes("Unique") ? " UNIQUE" : ""}`);
      sql.rows(`CREATE TABLE IF NOT EXISTS ${ident(table.table)} (${columns.join(", ")})`, []);
    }
  }
  function descriptor(operation) {
    let op = program.policy.operations.find((p) => p.operation === operation);
    return op || reject("operation_policy"), { operation: structuredClone(op), bindings: structuredClone(program.policy.bindings), entities: structuredClone(program.policy.entities) };
  }
  let expectedPolicy = new Map(program.policy.operations.map((op) => [op.operation, compileDescriptor(descriptor(op.operation))])), checkedNodes = /* @__PURE__ */ new Map();
  for (let decl of declarations2.values()) {
    let visit = (v) => {
      if (!(!v || typeof v != "object")) {
        if (v.hostEffect === "storage.read" || v.hostEffect === "storage.update") {
          let key = JSON.stringify([decl.name, v.hostEffect, v.entity]), nodes = checkedNodes.get(key) ?? [];
          nodes.push(v), checkedNodes.set(key, nodes);
        }
        for (let child of Object.values(v)) Array.isArray(child) ? child.forEach(visit) : visit(child);
      }
    };
    visit(decl.body);
  }
  function scoped(args, principal, effect) {
    closed(args, ["entity", "operation", "semanticOperationId", "freshness", "policy", "predicate", ...effect === "update" ? ["changes"] : []]);
    let table = tables.get(args.entity), decl = declarations2.get(args.operation);
    (!table || decl?.kind !== "callable" || decl.semanticId !== args.semanticOperationId) && reject("operation_identity"), args.freshness !== "authoritative" && reject("freshness"), expectedPolicy.get(args.operation)?.(args.policy) || reject("policy_descriptor"), closed(args.predicate, ["field", "operator", "value"]), (args.predicate.operator !== "equal" || args.predicate.field !== table.identity) && reject("predicate");
    let storageNodes = checkedNodes.get(JSON.stringify([decl.name, `storage.${effect}`, args.entity])) ?? [];
    (storageNodes.length !== 1 || storageNodes[0].predicate.field !== args.predicate.field) && reject("undeclared_storage_operation");
    let node = storageNodes[0];
    if (effect === "update") {
      let allowed;
      if (node.patch !== null) {
        node.patch.length !== 1 && reject("patch_path");
        let parameter = decl.parameters.find((p) => p.name === node.patch[0]), patch = declarations2.get(parameter?.type?.name);
        patch?.kind !== "record" && reject("patch_record"), allowed = patch.fields.map((f) => f.name);
      } else allowed = node.set.map((f) => f.name);
      (!isObject(args.changes) || Object.keys(args.changes).some((k) => !allowed.includes(k))) && reject("undeclared_update_field");
    }
    let parameters = [validate(table, args.predicate.field, args.predicate.value)], clauses = [`${ident(args.predicate.field)} = ?`], obligations = args.policy.operation.obligations.filter((o) => o.entity === args.entity && o.effect === effect);
    obligations.length === 0 && reject("missing_obligation");
    for (let obligation of obligations) {
      obligation.origin !== "entity" && reject("field_obligation");
      let alternatives = [];
      for (let role of obligation.subjects) {
        program.policy.entities.find((e) => e.entity === args.entity)?.rules.some((r) => r.subject === role && r.effects.includes(effect)) || reject("undeclared_role");
        let bindings = program.policy.bindings.filter((b) => b.entity === args.entity && b.role === role);
        bindings.length !== 1 && reject("binding_cardinality");
        let binding = bindings[0];
        if (principal?.entity === binding.principalEntity) {
          let identity = entities.get(binding.principalEntity).identity;
          parameters.push(validate(table, binding.field, principal.values[identity])), alternatives.push(`${ident(binding.field)} = ?`);
        }
      }
      clauses.push(alternatives.length ? `(${alternatives.join(" OR ")})` : "0 = 1");
    }
    return { table, parameters, where: clauses.join(" AND ") };
  }
  function read3(args, principal) {
    let { table, parameters, where } = scoped(args, principal, "read"), rows = sql.rows(`SELECT ${[...table.fields.keys()].map(ident).join(", ")} FROM ${ident(table.table)} WHERE ${where} LIMIT 2`, parameters);
    return rows.length > 1 && reject("cardinality"), { kind: "success", value: rows.length ? validateRow(table, rows[0]) : null };
  }
  let transactionActive = !1;
  function update(args, principal) {
    transactionActive || reject("update_requires_transaction");
    let { table, parameters, where } = scoped(args, principal, "update");
    isObject(args.changes) || reject("changes");
    let fields = Object.keys(args.changes);
    for (let field of fields) (!table.fields.has(field) || table.fields.get(field).immutable || field === table.identity) && reject("immutable_or_unknown_field");
    if (fields.length === 0) return { kind: "success", value: { status: "empty" } };
    let values = fields.map((field) => validate(table, field, args.changes[field]));
    try {
      let rows = sql.rows(`UPDATE ${ident(table.table)} SET ${fields.map((f) => `${ident(f)} = ?`).join(", ")} WHERE ${where} RETURNING ${[...table.fields.keys()].map(ident).join(", ")}`, [...values, ...parameters]);
      return rows.length > 1 && reject("cardinality"), { kind: "success", value: rows.length ? { status: "found", row: validateRow(table, rows[0]) } : { status: "missing" } };
    } catch (error) {
      if (sql.isUniqueConflict(error)) return { kind: "success", value: { status: "conflict" } };
      throw error;
    }
  }
  class Rollback {
    constructor(result) {
      this.result = result;
    }
    result;
  }
  function runAtomic(work) {
    transactionActive && reject("nested_transaction");
    try {
      return sql.transactionSync(() => {
        transactionActive = !0;
        try {
          let result = syncResult(work());
          if ((!isObject(result) || !["success", "domain", "internal", "invalid"].includes(result.kind)) && reject("terminal_envelope"), result.kind !== "success") throw new Rollback(result);
          return result;
        } finally {
          transactionActive = !1;
        }
      });
    } catch (error) {
      if (error instanceof Rollback) return error.result;
      throw error;
    }
  }
  return {
    setup,
    descriptor,
    read: read3,
    update,
    runAtomic,
    schema: [...tables.values()].map((t) => ({ entity: t.name, table: t.table, identity: t.identity, fields: [...t.fields.keys()] })),
    // Trusted test setup only, never exposed as a Wasm capability or public endpoint.
    resetFixture(rows) {
      sql.transactionSync(() => {
        for (let t of tables.values()) {
          sql.rows(`DELETE FROM ${ident(t.table)}`, []);
          for (let row of rows[t.name] ?? []) {
            let valid = validateRow(t, row), fields = [...t.fields.keys()];
            sql.rows(`INSERT INTO ${ident(t.table)} (${fields.map(ident).join(", ")}) VALUES (${fields.map(() => "?").join(", ")})`, fields.map((f) => valid[f]));
          }
        }
      });
    },
    snapshot() {
      return Object.fromEntries([...tables.values()].map((t) => [t.name, sql.rows(`SELECT ${[...t.fields.keys()].map(ident).join(", ")} FROM ${ident(t.table)} ORDER BY ${ident(t.identity)}`, [])]));
    }
  };
}

// experiments/wasm-exp1/storage/cloudflare-sqlite.ts
function cloudflareSqlite(storage) {
  return {
    rows: (sql, parameters) => storage.sql.exec(sql, ...parameters).toArray(),
    transactionSync: (work) => storage.transactionSync(work),
    // workerd reports SQLite failures as Error messages; constrain classification to
    // the SQLite unique violation signature. Raw detail never becomes a wire value.
    isUniqueConflict: (error) => error instanceof Error && /^UNIQUE constraint failed: [A-Za-z_][A-Za-z0-9_. ,]*(?:: SQLITE_CONSTRAINT(?: \(extended: SQLITE_CONSTRAINT_(?:UNIQUE|PRIMARYKEY)\))?)?$/.test(error.message)
  };
}

// experiments/wasm-exp1/workerd-boundary/persistence-port.ts
var PersistenceFault = class extends Error {
  constructor(kind) {
    super(kind);
    this.kind = kind;
  }
  kind;
};
var persistence = void 0;

// build/wasm-exp1/baseline/generated/bun/target/app.ts
var ValidationError = class extends Error {
};
var DomainFailure = class extends Error {
  constructor(failureName, publicContext, internalContext) {
    super(failureName);
    this.failureName = failureName;
    this.publicContext = publicContext;
    this.internalContext = internalContext;
  }
  failureName;
  publicContext;
  internalContext;
};
function invalid(path, expectation) {
  throw new ValidationError(`${path} must satisfy ${expectation}`);
}
function expectObject(value, path) {
  return (typeof value != "object" || value === null || Array.isArray(value)) && invalid(path, "a closed object"), value;
}
function rejectUnknownFields(value, allowed, path) {
  let allowedSet = new Set(allowed);
  for (let key of Object.keys(value))
    allowedSet.has(key) || invalid(`${path}.${key}`, "a declared field");
}
function hasOwn(value, key) {
  return Object.prototype.hasOwnProperty.call(value, key);
}
function validateText(value, path) {
  return typeof value != "string" && invalid(path, "Text"), value;
}
function validateInt(value, path) {
  return (typeof value != "number" || !Number.isInteger(value)) && invalid(path, "Int"), value;
}
function validateUuid(value, path) {
  return (typeof value != "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/iu.test(value)) && invalid(path, "Uuid"), value;
}
function validateInstant(value, path) {
  typeof value != "string" && invalid(path, "Instant with an explicit RFC 3339 offset");
  let match = /^([0-9]{4})-([0-9]{2})-([0-9]{2})T(?:[01][0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9](?:\.[0-9]{1,3})?(?:Z|[+-](?:[01][0-9]|2[0-3]):[0-5][0-9])$/u.exec(value);
  (match === null || value.endsWith("-00:00")) && invalid(path, "Instant with an explicit RFC 3339 offset");
  let year = Number(match[1]), month = Number(match[2]), day = Number(match[3]), calendarCheck = /* @__PURE__ */ new Date(0);
  calendarCheck.setUTCFullYear(year, month - 1, day), calendarCheck.setUTCHours(0, 0, 0, 0), (year < 1 || calendarCheck.getUTCFullYear() !== year || calendarCheck.getUTCMonth() !== month - 1 || calendarCheck.getUTCDate() !== day) && invalid(path, "real RFC 3339 calendar date");
  let milliseconds = Date.parse(value);
  Number.isFinite(milliseconds) || invalid(path, "representable Instant");
  let canonical = new Date(milliseconds).toISOString();
  return (!/^[0-9]{4}-/u.test(canonical) || canonical.startsWith("0000-")) && invalid(path, "portable Instant range"), canonical;
}
function validateCalendarDate(value, path) {
  (typeof value != "string" || !/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/u.test(value)) && invalid(path, "CalendarDate");
  let [year, month, day] = value.split("-").map(Number), check = /* @__PURE__ */ new Date(0);
  return check.setUTCFullYear(year, month - 1, day), check.setUTCHours(0, 0, 0, 0), (year < 1 || check.getUTCFullYear() !== year || check.getUTCMonth() !== month - 1 || check.getUTCDate() !== day) && invalid(path, "real calendar date"), value;
}
function validateZone(value, path) {
  return (typeof value != "string" || !jadpoZones.has(value)) && invalid(path, "declared canonical IANA Zone"), value;
}
function validateLocale(value, path) {
  return (typeof value != "string" || !jadpoLocales.has(value)) && invalid(path, "application-declared Locale"), value;
}
function validateTime(value, path) {
  let object = expectObject(value, path);
  return rejectUnknownFields(object, ["instant", "zone"], path), Object.freeze({ instant: validateInstant(object.instant, `${path}.instant`), zone: validateZone(object.zone, `${path}.zone`) });
}
function durationMilliseconds(value, path) {
  typeof value != "string" && invalid(path, "Duration");
  let match = /^(-)?PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)(?:\.(\d{1,3}))?S)?$/u.exec(value);
  (match === null || match[2] === void 0 && match[3] === void 0 && match[4] === void 0) && invalid(path, "ISO 8601 time-only Duration");
  let milliseconds = ((Number(match[2] ?? 0) * 60 + Number(match[3] ?? 0)) * 60 + Number(match[4] ?? 0)) * 1e3 + Number((match[5] ?? "").padEnd(3, "0")), signed = match[1] === void 0 ? milliseconds : -milliseconds;
  return Number.isSafeInteger(signed) || invalid(path, "portable Duration range"), signed;
}
function durationFromMilliseconds(milliseconds) {
  Number.isSafeInteger(milliseconds) || invalid("duration", "portable Duration range");
  let sign = milliseconds < 0 ? "-" : "", remaining = Math.abs(milliseconds), hours = Math.floor(remaining / 36e5);
  remaining %= 36e5;
  let minutes = Math.floor(remaining / 6e4);
  remaining %= 6e4;
  let seconds = Math.floor(remaining / 1e3), fraction = remaining % 1e3, values = `${hours === 0 ? "" : `${hours}H`}${minutes === 0 ? "" : `${minutes}M`}${seconds === 0 && fraction === 0 ? "" : `${seconds}${fraction === 0 ? "" : `.${String(fraction).padStart(3, "0").replace(/0+$/u, "")}`}S`}`;
  return `${sign}PT${values === "" ? "0S" : values}`;
}
var jadpoZones = /* @__PURE__ */ new Set([
  "UTC",
  "Africa/Abidjan",
  "Africa/Accra",
  "Africa/Addis_Ababa",
  "Africa/Algiers",
  "Africa/Asmara",
  "Africa/Bamako",
  "Africa/Bangui",
  "Africa/Banjul",
  "Africa/Bissau",
  "Africa/Blantyre",
  "Africa/Brazzaville",
  "Africa/Bujumbura",
  "Africa/Cairo",
  "Africa/Casablanca",
  "Africa/Ceuta",
  "Africa/Conakry",
  "Africa/Dakar",
  "Africa/Dar_es_Salaam",
  "Africa/Djibouti",
  "Africa/Douala",
  "Africa/El_Aaiun",
  "Africa/Freetown",
  "Africa/Gaborone",
  "Africa/Harare",
  "Africa/Johannesburg",
  "Africa/Juba",
  "Africa/Kampala",
  "Africa/Khartoum",
  "Africa/Kigali",
  "Africa/Kinshasa",
  "Africa/Lagos",
  "Africa/Libreville",
  "Africa/Lome",
  "Africa/Luanda",
  "Africa/Lubumbashi",
  "Africa/Lusaka",
  "Africa/Malabo",
  "Africa/Maputo",
  "Africa/Maseru",
  "Africa/Mbabane",
  "Africa/Mogadishu",
  "Africa/Monrovia",
  "Africa/Nairobi",
  "Africa/Ndjamena",
  "Africa/Niamey",
  "Africa/Nouakchott",
  "Africa/Ouagadougou",
  "Africa/Porto-Novo",
  "Africa/Sao_Tome",
  "Africa/Tripoli",
  "Africa/Tunis",
  "Africa/Windhoek",
  "America/Adak",
  "America/Anchorage",
  "America/Anguilla",
  "America/Antigua",
  "America/Araguaina",
  "America/Argentina/Buenos_Aires",
  "America/Argentina/Catamarca",
  "America/Argentina/Cordoba",
  "America/Argentina/Jujuy",
  "America/Argentina/La_Rioja",
  "America/Argentina/Mendoza",
  "America/Argentina/Rio_Gallegos",
  "America/Argentina/Salta",
  "America/Argentina/San_Juan",
  "America/Argentina/San_Luis",
  "America/Argentina/Tucuman",
  "America/Argentina/Ushuaia",
  "America/Aruba",
  "America/Asuncion",
  "America/Atikokan",
  "America/Bahia",
  "America/Bahia_Banderas",
  "America/Barbados",
  "America/Belem",
  "America/Belize",
  "America/Blanc-Sablon",
  "America/Boa_Vista",
  "America/Bogota",
  "America/Boise",
  "America/Cambridge_Bay",
  "America/Campo_Grande",
  "America/Cancun",
  "America/Caracas",
  "America/Cayenne",
  "America/Cayman",
  "America/Chicago",
  "America/Chihuahua",
  "America/Ciudad_Juarez",
  "America/Costa_Rica",
  "America/Coyhaique",
  "America/Creston",
  "America/Cuiaba",
  "America/Curacao",
  "America/Danmarkshavn",
  "America/Dawson",
  "America/Dawson_Creek",
  "America/Denver",
  "America/Detroit",
  "America/Dominica",
  "America/Edmonton",
  "America/Eirunepe",
  "America/El_Salvador",
  "America/Fort_Nelson",
  "America/Fortaleza",
  "America/Glace_Bay",
  "America/Goose_Bay",
  "America/Grand_Turk",
  "America/Grenada",
  "America/Guadeloupe",
  "America/Guatemala",
  "America/Guayaquil",
  "America/Guyana",
  "America/Halifax",
  "America/Havana",
  "America/Hermosillo",
  "America/Indiana/Indianapolis",
  "America/Indiana/Knox",
  "America/Indiana/Marengo",
  "America/Indiana/Petersburg",
  "America/Indiana/Tell_City",
  "America/Indiana/Vevay",
  "America/Indiana/Vincennes",
  "America/Indiana/Winamac",
  "America/Inuvik",
  "America/Iqaluit",
  "America/Jamaica",
  "America/Juneau",
  "America/Kentucky/Louisville",
  "America/Kentucky/Monticello",
  "America/Kralendijk",
  "America/La_Paz",
  "America/Lima",
  "America/Los_Angeles",
  "America/Lower_Princes",
  "America/Maceio",
  "America/Managua",
  "America/Manaus",
  "America/Marigot",
  "America/Martinique",
  "America/Matamoros",
  "America/Mazatlan",
  "America/Menominee",
  "America/Merida",
  "America/Metlakatla",
  "America/Mexico_City",
  "America/Miquelon",
  "America/Moncton",
  "America/Monterrey",
  "America/Montevideo",
  "America/Montserrat",
  "America/Nassau",
  "America/New_York",
  "America/Nome",
  "America/Noronha",
  "America/North_Dakota/Beulah",
  "America/North_Dakota/Center",
  "America/North_Dakota/New_Salem",
  "America/Nuuk",
  "America/Ojinaga",
  "America/Panama",
  "America/Paramaribo",
  "America/Phoenix",
  "America/Port-au-Prince",
  "America/Port_of_Spain",
  "America/Porto_Velho",
  "America/Puerto_Rico",
  "America/Punta_Arenas",
  "America/Rankin_Inlet",
  "America/Recife",
  "America/Regina",
  "America/Resolute",
  "America/Rio_Branco",
  "America/Santarem",
  "America/Santiago",
  "America/Santo_Domingo",
  "America/Sao_Paulo",
  "America/Scoresbysund",
  "America/Sitka",
  "America/St_Barthelemy",
  "America/St_Johns",
  "America/St_Kitts",
  "America/St_Lucia",
  "America/St_Thomas",
  "America/St_Vincent",
  "America/Swift_Current",
  "America/Tegucigalpa",
  "America/Thule",
  "America/Tijuana",
  "America/Toronto",
  "America/Tortola",
  "America/Vancouver",
  "America/Whitehorse",
  "America/Winnipeg",
  "America/Yakutat",
  "Antarctica/Casey",
  "Antarctica/Davis",
  "Antarctica/DumontDUrville",
  "Antarctica/Macquarie",
  "Antarctica/Mawson",
  "Antarctica/McMurdo",
  "Antarctica/Palmer",
  "Antarctica/Rothera",
  "Antarctica/Syowa",
  "Antarctica/Troll",
  "Antarctica/Vostok",
  "Arctic/Longyearbyen",
  "Asia/Aden",
  "Asia/Almaty",
  "Asia/Amman",
  "Asia/Anadyr",
  "Asia/Aqtau",
  "Asia/Aqtobe",
  "Asia/Ashgabat",
  "Asia/Atyrau",
  "Asia/Baghdad",
  "Asia/Bahrain",
  "Asia/Baku",
  "Asia/Bangkok",
  "Asia/Barnaul",
  "Asia/Beirut",
  "Asia/Bishkek",
  "Asia/Brunei",
  "Asia/Chita",
  "Asia/Colombo",
  "Asia/Damascus",
  "Asia/Dhaka",
  "Asia/Dili",
  "Asia/Dubai",
  "Asia/Dushanbe",
  "Asia/Famagusta",
  "Asia/Gaza",
  "Asia/Hebron",
  "Asia/Ho_Chi_Minh",
  "Asia/Hong_Kong",
  "Asia/Hovd",
  "Asia/Irkutsk",
  "Asia/Jakarta",
  "Asia/Jayapura",
  "Asia/Jerusalem",
  "Asia/Kabul",
  "Asia/Kamchatka",
  "Asia/Karachi",
  "Asia/Kathmandu",
  "Asia/Khandyga",
  "Asia/Kolkata",
  "Asia/Krasnoyarsk",
  "Asia/Kuala_Lumpur",
  "Asia/Kuching",
  "Asia/Kuwait",
  "Asia/Macau",
  "Asia/Magadan",
  "Asia/Makassar",
  "Asia/Manila",
  "Asia/Muscat",
  "Asia/Nicosia",
  "Asia/Novokuznetsk",
  "Asia/Novosibirsk",
  "Asia/Omsk",
  "Asia/Oral",
  "Asia/Phnom_Penh",
  "Asia/Pontianak",
  "Asia/Pyongyang",
  "Asia/Qatar",
  "Asia/Qostanay",
  "Asia/Qyzylorda",
  "Asia/Riyadh",
  "Asia/Sakhalin",
  "Asia/Samarkand",
  "Asia/Seoul",
  "Asia/Shanghai",
  "Asia/Singapore",
  "Asia/Srednekolymsk",
  "Asia/Taipei",
  "Asia/Tashkent",
  "Asia/Tbilisi",
  "Asia/Tehran",
  "Asia/Thimphu",
  "Asia/Tokyo",
  "Asia/Tomsk",
  "Asia/Ulaanbaatar",
  "Asia/Urumqi",
  "Asia/Ust-Nera",
  "Asia/Vientiane",
  "Asia/Vladivostok",
  "Asia/Yakutsk",
  "Asia/Yangon",
  "Asia/Yekaterinburg",
  "Asia/Yerevan",
  "Atlantic/Azores",
  "Atlantic/Bermuda",
  "Atlantic/Canary",
  "Atlantic/Cape_Verde",
  "Atlantic/Faroe",
  "Atlantic/Madeira",
  "Atlantic/Reykjavik",
  "Atlantic/South_Georgia",
  "Atlantic/St_Helena",
  "Atlantic/Stanley",
  "Australia/Adelaide",
  "Australia/Brisbane",
  "Australia/Broken_Hill",
  "Australia/Darwin",
  "Australia/Eucla",
  "Australia/Hobart",
  "Australia/Lindeman",
  "Australia/Lord_Howe",
  "Australia/Melbourne",
  "Australia/Perth",
  "Australia/Sydney",
  "Europe/Amsterdam",
  "Europe/Andorra",
  "Europe/Astrakhan",
  "Europe/Athens",
  "Europe/Belgrade",
  "Europe/Berlin",
  "Europe/Bratislava",
  "Europe/Brussels",
  "Europe/Bucharest",
  "Europe/Budapest",
  "Europe/Busingen",
  "Europe/Chisinau",
  "Europe/Copenhagen",
  "Europe/Dublin",
  "Europe/Gibraltar",
  "Europe/Guernsey",
  "Europe/Helsinki",
  "Europe/Isle_of_Man",
  "Europe/Istanbul",
  "Europe/Jersey",
  "Europe/Kaliningrad",
  "Europe/Kirov",
  "Europe/Kyiv",
  "Europe/Lisbon",
  "Europe/Ljubljana",
  "Europe/London",
  "Europe/Luxembourg",
  "Europe/Madrid",
  "Europe/Malta",
  "Europe/Mariehamn",
  "Europe/Minsk",
  "Europe/Monaco",
  "Europe/Moscow",
  "Europe/Oslo",
  "Europe/Paris",
  "Europe/Podgorica",
  "Europe/Prague",
  "Europe/Riga",
  "Europe/Rome",
  "Europe/Samara",
  "Europe/San_Marino",
  "Europe/Sarajevo",
  "Europe/Saratov",
  "Europe/Simferopol",
  "Europe/Skopje",
  "Europe/Sofia",
  "Europe/Stockholm",
  "Europe/Tallinn",
  "Europe/Tirane",
  "Europe/Ulyanovsk",
  "Europe/Vaduz",
  "Europe/Vatican",
  "Europe/Vienna",
  "Europe/Vilnius",
  "Europe/Volgograd",
  "Europe/Warsaw",
  "Europe/Zagreb",
  "Europe/Zurich",
  "Indian/Antananarivo",
  "Indian/Chagos",
  "Indian/Christmas",
  "Indian/Cocos",
  "Indian/Comoro",
  "Indian/Kerguelen",
  "Indian/Mahe",
  "Indian/Maldives",
  "Indian/Mauritius",
  "Indian/Mayotte",
  "Indian/Reunion",
  "Pacific/Apia",
  "Pacific/Auckland",
  "Pacific/Bougainville",
  "Pacific/Chatham",
  "Pacific/Chuuk",
  "Pacific/Easter",
  "Pacific/Efate",
  "Pacific/Fakaofo",
  "Pacific/Fiji",
  "Pacific/Funafuti",
  "Pacific/Galapagos",
  "Pacific/Gambier",
  "Pacific/Guadalcanal",
  "Pacific/Guam",
  "Pacific/Honolulu",
  "Pacific/Kanton",
  "Pacific/Kiritimati",
  "Pacific/Kosrae",
  "Pacific/Kwajalein",
  "Pacific/Majuro",
  "Pacific/Marquesas",
  "Pacific/Midway",
  "Pacific/Nauru",
  "Pacific/Niue",
  "Pacific/Norfolk",
  "Pacific/Noumea",
  "Pacific/Pago_Pago",
  "Pacific/Palau",
  "Pacific/Pitcairn",
  "Pacific/Pohnpei",
  "Pacific/Port_Moresby",
  "Pacific/Rarotonga",
  "Pacific/Saipan",
  "Pacific/Tahiti",
  "Pacific/Tarawa",
  "Pacific/Tongatapu",
  "Pacific/Wake",
  "Pacific/Wallis"
]), jadpoLocales = /* @__PURE__ */ new Set([]);
for (let locale of jadpoLocales) {
  let canonical = Intl.getCanonicalLocales(locale);
  if (canonical.length !== 1 || canonical[0] !== locale || Intl.DateTimeFormat.supportedLocalesOf([locale], { localeMatcher: "lookup" }).length !== 1) throw new Error(`Unsupported generated Locale ${locale}`);
}
for (let zone of jadpoZones)
  try {
    new Intl.DateTimeFormat("en", { timeZone: zone });
  } catch {
    throw new Error(`Unsupported generated Zone ${zone}`);
  }
var temporalProvenance = Object.freeze({
  tzdb: "IANA 2026c",
  zoneEnumCount: jadpoZones.size,
  defaultLocale: null,
  unsupportedLocale: null,
  localeData: "compiler-owned Intl boundary; declared locales and zones verified at startup",
  runtimeIcu: "workerd",
  runtimeEngine: "Bun unused-on-workerd",
  timezoneRules: "runtime ICU; version recorded for release pinning"
});
function captureOperation(fixedNow = null, principal = null) {
  let now = fixedNow ?? validateInstant((/* @__PURE__ */ new Date()).toISOString(), "clock.now");
  return Object.freeze({ now, monotonicStartedAt: performance.now(), principal });
}
var localFormatterCache = /* @__PURE__ */ new Map();
function localFormatter(zone) {
  let existing = localFormatterCache.get(zone);
  if (existing !== void 0) return existing;
  let formatter = new Intl.DateTimeFormat("en-CA-u-ca-iso8601-nu-latn", {
    timeZone: zone,
    calendar: "iso8601",
    numberingSystem: "latn",
    hourCycle: "h23",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    fractionalSecondDigits: 3
  });
  return localFormatterCache.set(zone, formatter), formatter;
}
function localParts(instant, zone) {
  instant = validateInstant(instant, "temporal local instant"), zone = validateZone(zone, "temporal local zone");
  let values = {};
  for (let part of localFormatter(zone).formatToParts(new Date(instant))) part.type !== "literal" && (values[part.type] = part.value);
  return Object.freeze({ year: Number(values.year), month: Number(values.month), day: Number(values.day), hour: Number(values.hour), minute: Number(values.minute), second: Number(values.second), millisecond: Number(values.fractionalSecond) });
}
function utcMilliseconds(parts) {
  let value = /* @__PURE__ */ new Date(0);
  return value.setUTCFullYear(parts.year, parts.month - 1, parts.day), value.setUTCHours(parts.hour, parts.minute, parts.second, parts.millisecond), value.getTime();
}
function sameParts(left, right) {
  return left.year === right.year && left.month === right.month && left.day === right.day && left.hour === right.hour && left.minute === right.minute && left.second === right.second && left.millisecond === right.millisecond;
}
function parseClock(value) {
  typeof value != "string" && invalid("temporal.resolve.at", "strict clock text");
  let match = /^(?:([01][0-9]|2[0-3])):([0-5][0-9])(?::([0-5][0-9])(?:\.([0-9]{1,3}))?)?$/u.exec(value);
  return match === null && invalid("temporal.resolve.at", "HH:MM with optional seconds and milliseconds"), { hour: Number(match[1]), minute: Number(match[2]), second: Number(match[3] ?? 0), millisecond: Number((match[4] ?? "").padEnd(3, "0")) };
}
function calendarFromUtc(milliseconds) {
  let date = new Date(milliseconds);
  return validateCalendarDate(`${String(date.getUTCFullYear()).padStart(4, "0")}-${String(date.getUTCMonth() + 1).padStart(2, "0")}-${String(date.getUTCDate()).padStart(2, "0")}`, "calendar date");
}
function resolveLocal(parts, zone, overlap, gap) {
  let naive = utcMilliseconds(parts), offsets = /* @__PURE__ */ new Set();
  for (let sample = naive - 36 * 36e5; sample <= naive + 36 * 36e5; sample += 6 * 36e5) {
    let candidate2 = validateInstant(new Date(sample).toISOString(), "temporal.resolve.sample");
    offsets.add(utcMilliseconds(localParts(candidate2, zone)) - sample);
  }
  let candidates = [...offsets].map((offset) => naive - offset).filter((milliseconds) => Number.isFinite(milliseconds)).map((milliseconds) => validateInstant(new Date(milliseconds).toISOString(), "temporal.resolve")).filter((instant) => sameParts(localParts(instant, zone), parts)).sort((left, right) => Date.parse(left) - Date.parse(right)), unique = [...new Set(candidates)];
  if (unique.length === 1) return Object.freeze({ instant: unique[0], zone });
  if (unique.length > 1)
    return overlap === "reject" && invalid("temporal.resolve", "unambiguous local time or explicit overlap policy"), Object.freeze({ instant: overlap === "earlier" ? unique[0] : unique[unique.length - 1], zone });
  gap === "reject" && invalid("temporal.resolve", "existing local time or explicit gap policy");
  let orderedOffsets = [...offsets].sort((left, right) => left - right), transition = Math.abs(orderedOffsets[orderedOffsets.length - 1] - orderedOffsets[0]);
  transition === 0 && invalid("temporal.resolve", "representable local time");
  let shifted = new Date(naive + (gap === "shift_forward" ? transition : -transition));
  return resolveLocal({ year: shifted.getUTCFullYear(), month: shifted.getUTCMonth() + 1, day: shifted.getUTCDate(), hour: shifted.getUTCHours(), minute: shifted.getUTCMinutes(), second: shifted.getUTCSeconds(), millisecond: shifted.getUTCMilliseconds() }, zone, overlap, "reject");
}
function resolveOptions(options) {
  let date = validateCalendarDate(options.date, "temporal.resolve.date"), zone = validateZone(options.zone, "temporal.resolve.zone"), overlap = temporalChoice(options.overlap, ["reject", "earlier", "later"], "temporal.resolve.overlap"), gap = temporalChoice(options.gap, ["reject", "shift_forward", "shift_backward"], "temporal.resolve.gap"), [year, month, day] = date.split("-").map(Number);
  return resolveLocal({ year, month, day, ...parseClock(options.at) }, zone, overlap, gap);
}
function timelineInstant(value) {
  return typeof value == "string" ? validateInstant(value, "temporal value") : validateTime(value, "temporal value").instant;
}
function temporalChoice(value, allowed, path) {
  return (typeof value != "string" || !allowed.includes(value)) && invalid(path, allowed.join(" | ")), value;
}
function dateAdd(date, years, months, days, invalidDay) {
  let value = validateCalendarDate(date, "temporal date");
  invalidDay = temporalChoice(invalidDay, ["reject", "last_valid_day"], "temporal date arithmetic.invalid_day");
  let [year, month, day] = value.split("-").map(Number), targetMonth = month - 1 + months, first = /* @__PURE__ */ new Date(0);
  first.setUTCFullYear(year + years, targetMonth, 1), first.setUTCHours(0, 0, 0, 0);
  let lastDay = /* @__PURE__ */ new Date(0);
  return lastDay.setUTCFullYear(first.getUTCFullYear(), first.getUTCMonth() + 1, 0), lastDay.setUTCHours(0, 0, 0, 0), day > lastDay.getUTCDate() && invalidDay === "reject" && invalid("temporal date arithmetic", "valid target calendar day"), first.setUTCDate(Math.min(day, lastDay.getUTCDate()) + days), calendarFromUtc(first.getTime());
}
function addLocal(time, years, months, days, invalidDay, overlap, gap) {
  let value = validateTime(time, "temporal local arithmetic");
  overlap = temporalChoice(overlap, ["reject", "earlier", "later"], "temporal local arithmetic.overlap"), gap = temporalChoice(gap, ["reject", "shift_forward", "shift_backward"], "temporal local arithmetic.gap");
  let parts = localParts(value.instant, value.zone), date = dateAdd(calendarFromUtc(utcMilliseconds({ ...parts, hour: 0, minute: 0, second: 0, millisecond: 0 })), years, months, days, invalidDay), [year, month, day] = date.split("-").map(Number);
  return resolveLocal({ ...parts, year, month, day }, value.zone, overlap, gap);
}
function periodBounds(date, zone, next) {
  let start = resolveOptions({ date, at: "00:00", zone, overlap: "reject", gap: "reject" }).instant, end = resolveOptions({ date: next(date), at: "00:00", zone, overlap: "reject", gap: "reject" }).instant;
  return Object.freeze({ start, end });
}
var weekdayNames = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
function formatOptions(style) {
  style = temporalChoice(style, ["date_full", "date_long", "date_medium", "date_short", "time_full", "time_long", "time_medium", "time_short", "date_time_full", "date_time_long", "date_time_medium", "date_time_short"], "temporal.format.style");
  let [kind, width] = style.startsWith("date_time_") ? ["date_time", style.slice(10)] : style.startsWith("date_") ? ["date", style.slice(5)] : ["time", style.slice(5)];
  return { ...kind === "date" || kind === "date_time" ? { dateStyle: width } : {}, ...kind === "time" || kind === "date_time" ? { timeStyle: width } : {} };
}
function componentOptions(components) {
  (typeof components != "object" || components === null || Array.isArray(components)) && invalid("temporal.format.components", "closed component object");
  let allowed = {
    weekday: ["long", "short", "narrow"],
    day: ["numeric", "two_digit"],
    year: ["numeric", "two_digit"],
    hour: ["numeric", "two_digit"],
    minute: ["numeric", "two_digit"],
    second: ["numeric", "two_digit"],
    month: ["numeric", "two_digit", "long", "short", "narrow"],
    zone_name: ["long", "short", "long_offset", "short_offset", "long_generic", "short_generic"],
    hour_cycle: ["h11", "h12", "h23", "h24"]
  }, output = {}, mapping = { zone_name: "timeZoneName", hour_cycle: "hourCycle" }, entries = Object.entries(components);
  entries.length === 0 && invalid("temporal.format.components", "at least one component");
  for (let [key, value] of entries)
    (allowed[key] === void 0 || typeof value != "string" || !allowed[key].includes(value)) && invalid(`temporal.format.components.${key}`, allowed[key]?.join(" | ") ?? "known component"), output[mapping[key] ?? key] = value === "two_digit" ? "2-digit" : value.replaceAll("_", "-");
  return output;
}
function formatAbsolute(value, options) {
  let locale = validateLocale(options.locale, "temporal.format.locale");
  if (options.style === void 0 == (options.components === void 0) && invalid("temporal.format", "exactly one of style or components"), typeof value == "string") {
    let date = validateCalendarDate(value, "temporal.format.value");
    return new Intl.DateTimeFormat(locale, { timeZone: "UTC", ...options.style === void 0 ? componentOptions(options.components) : formatOptions(options.style) }).format(/* @__PURE__ */ new Date(`${date}T00:00:00.000Z`));
  }
  let time = validateTime(value, "temporal.format.value");
  return new Intl.DateTimeFormat(locale, { timeZone: time.zone, ...options.style === void 0 ? componentOptions(options.components) : formatOptions(options.style) }).format(new Date(time.instant));
}
function friendly(value, options) {
  options.profile !== "conversational" && invalid("temporal.format_friendly.profile", "FriendlyTimeFormat.conversational");
  let time = validateTime(value, "temporal.format_friendly.value"), relative = validateInstant(options.relative_to, "temporal.format_friendly.relative_to"), locale = validateLocale(options.locale, "temporal.format_friendly.locale"), difference = Date.parse(time.instant) - Date.parse(relative), relativeFormatter = new Intl.RelativeTimeFormat(locale, { numeric: "always" }), naturalRelativeFormatter = new Intl.RelativeTimeFormat(locale, { numeric: "auto" });
  if (Math.abs(difference) < 6e4)
    return locale.toLowerCase().split("-")[0] === "en" ? difference <= 0 ? "just now" : "in under a minute" : difference <= 0 ? naturalRelativeFormatter.format(0, "second") : relativeFormatter.format(1, "minute");
  if (Math.abs(difference) < 36e5) return relativeFormatter.format(Math.ceil(difference / 6e4), "minute");
  let target = localParts(time.instant, time.zone), reference = localParts(relative, time.zone), targetDay = Date.UTC(target.year, target.month - 1, target.day), referenceDay = Date.UTC(reference.year, reference.month - 1, reference.day), dayDifference = Math.round((targetDay - referenceDay) / 864e5), weekdayTimeFormatter = new Intl.DateTimeFormat(locale, { timeZone: time.zone, weekday: "long", hour: "numeric", minute: "2-digit" }), targetDate = new Date(time.instant);
  if (Math.abs(dayDifference) <= 1) {
    let relativeDay = naturalRelativeFormatter.format(dayDifference, "day");
    return weekdayTimeFormatter.formatToParts(targetDate).map((part) => part.type === "weekday" ? relativeDay : part.value).join("");
  }
  return Math.abs(dayDifference) <= 6 ? weekdayTimeFormatter.format(targetDate) : formatAbsolute(time, { locale, style: "date_time_long" });
}
var temporal = Object.freeze({
  in_zone(instant, zone) {
    return Object.freeze({ instant: validateInstant(instant, "temporal.in_zone.instant"), zone: validateZone(zone, "temporal.in_zone.zone") });
  },
  resolve: resolveOptions,
  add_elapsed(value, duration) {
    let instant = validateInstant(new Date(Date.parse(timelineInstant(value)) + durationMilliseconds(duration, "temporal.add_elapsed.duration")).toISOString(), "temporal.add_elapsed");
    return typeof value == "string" ? instant : Object.freeze({ instant, zone: value.zone });
  },
  between(start, end) {
    return durationFromMilliseconds(Date.parse(timelineInstant(end)) - Date.parse(timelineInstant(start)));
  },
  add_days(date, options) {
    return dateAdd(date, 0, 0, validateInt(options.days, "temporal.add_days.days"), "reject");
  },
  add_weeks(date, options) {
    return dateAdd(date, 0, 0, validateInt(options.weeks, "temporal.add_weeks.weeks") * 7, "reject");
  },
  add_months(date, options) {
    return dateAdd(date, 0, validateInt(options.months, "temporal.add_months.months"), 0, options.invalid_day);
  },
  add_years(date, options) {
    return dateAdd(date, validateInt(options.years, "temporal.add_years.years"), 0, 0, options.invalid_day);
  },
  add_local_days(time, options) {
    return addLocal(time, 0, 0, validateInt(options.days, "temporal.add_local_days.days"), "reject", options.overlap, options.gap);
  },
  add_local_weeks(time, options) {
    return addLocal(time, 0, 0, validateInt(options.weeks, "temporal.add_local_weeks.weeks") * 7, "reject", options.overlap, options.gap);
  },
  add_local_months(time, options) {
    return addLocal(time, 0, validateInt(options.months, "temporal.add_local_months.months"), 0, options.invalid_day, options.overlap, options.gap);
  },
  add_local_years(time, options) {
    return addLocal(time, validateInt(options.years, "temporal.add_local_years.years"), 0, 0, options.invalid_day, options.overlap, options.gap);
  },
  day_bounds(date, zone) {
    return periodBounds(date, zone, (value) => dateAdd(value, 0, 0, 1, "reject"));
  },
  week_bounds(date, zone, options) {
    date = validateCalendarDate(date, "temporal.week_bounds.date"), zone = validateZone(zone, "temporal.week_bounds.zone");
    let startsOn = temporalChoice(options?.starts_on, weekdayNames, "temporal.week_bounds.starts_on"), day = (/* @__PURE__ */ new Date(`${date}T00:00:00Z`)).getUTCDay(), startIndex = weekdayNames.indexOf(startsOn), start = dateAdd(date, 0, 0, -((day - startIndex + 7) % 7), "reject");
    return periodBounds(start, zone, (value) => dateAdd(value, 0, 0, 7, "reject"));
  },
  month_bounds(date, zone) {
    date = validateCalendarDate(date, "temporal.month_bounds.date"), zone = validateZone(zone, "temporal.month_bounds.zone");
    let [year, month] = date.split("-").map(Number), start = validateCalendarDate(`${String(year).padStart(4, "0")}-${String(month).padStart(2, "0")}-01`, "temporal.month_bounds");
    return periodBounds(start, zone, (value) => dateAdd(value, 0, 1, 0, "reject"));
  },
  year_bounds(date, zone) {
    date = validateCalendarDate(date, "temporal.year_bounds.date"), zone = validateZone(zone, "temporal.year_bounds.zone");
    let year = date.slice(0, 4), start = validateCalendarDate(`${year}-01-01`, "temporal.year_bounds");
    return periodBounds(start, zone, (value) => dateAdd(value, 1, 0, 0, "reject"));
  },
  calendar_date(time) {
    let parts = localParts(time.instant, time.zone);
    return validateCalendarDate(`${String(parts.year).padStart(4, "0")}-${String(parts.month).padStart(2, "0")}-${String(parts.day).padStart(2, "0")}`, "temporal.calendar_date");
  },
  year(time) {
    return localParts(time.instant, time.zone).year;
  },
  month(time) {
    return localParts(time.instant, time.zone).month;
  },
  day(time) {
    return localParts(time.instant, time.zone).day;
  },
  weekday(time) {
    let value = validateTime(time, "temporal.weekday"), parts = localParts(value.instant, value.zone), date = validateCalendarDate(`${String(parts.year).padStart(4, "0")}-${String(parts.month).padStart(2, "0")}-${String(parts.day).padStart(2, "0")}`, "temporal.weekday");
    return weekdayNames[(/* @__PURE__ */ new Date(`${date}T00:00:00Z`)).getUTCDay()];
  },
  hour(time) {
    return localParts(time.instant, time.zone).hour;
  },
  minute(time) {
    return localParts(time.instant, time.zone).minute;
  },
  second(time) {
    return localParts(time.instant, time.zone).second;
  },
  millisecond(time) {
    return localParts(time.instant, time.zone).millisecond;
  },
  offset(time) {
    let value = validateTime(time, "temporal.offset");
    return durationFromMilliseconds(utcMilliseconds(localParts(value.instant, value.zone)) - Date.parse(value.instant));
  },
  zone(time) {
    return validateTime(time, "temporal.zone").zone;
  },
  same_zone(left, right) {
    return validateTime(left, "temporal.same_zone.left").zone === validateTime(right, "temporal.same_zone.right").zone;
  },
  same_local(left, right) {
    let a = validateTime(left, "temporal.same_local.left"), b = validateTime(right, "temporal.same_local.right");
    return sameParts(localParts(a.instant, a.zone), localParts(b.instant, b.zone));
  },
  format: formatAbsolute,
  format_friendly: friendly
});
function validate_ItemRole(value, path) {
  return value !== "owner" && invalid(path, "ItemRole"), value;
}
function validate_ItemTitle(value, path) {
  let candidate2 = validateText(value, path);
  return (typeof candidate2 == "string" ? [...candidate2].length : candidate2.length) < 3 && invalid(path, "minimum length"), (typeof candidate2 == "string" ? [...candidate2].length : candidate2.length) > 12 && invalid(path, "maximum length"), candidate2;
}
function validateField_4_Item_id(value, path) {
  return ((raw, fieldPath) => validateUuid(raw, fieldPath))(value, path);
}
function validateField_4_Item_title(value, path) {
  return ((raw, fieldPath) => validate_ItemTitle(raw, fieldPath))(value, path);
}
function validateField_4_Item_note(value, path) {
  return ((raw, fieldPath) => {
    let candidate2 = raw === null ? null : validateText(raw, fieldPath);
    return candidate2 === null ? null : candidate2;
  })(value, path);
}
function validateField_4_User_id(value, path) {
  return ((raw, fieldPath) => validateUuid(raw, fieldPath))(value, path);
}
function decodeDatabase_Item(value, path) {
  try {
    let object = expectObject(value, path);
    return {
      id: object.id,
      owner_id: object.owner_id,
      title: object.title,
      note: object.note === null ? null : object.note
    };
  } catch (error) {
    throw error instanceof PersistenceFault ? error : new PersistenceFault("decode.Item", "data", error);
  }
}
function validate_Item(value, path) {
  let object = expectObject(path.startsWith("database.") ? decodeDatabase_Item(value, path) : value, path);
  return rejectUnknownFields(object, ["id", "owner_id", "title", "note"], path), hasOwn(object, "id") || invalid(`${path}.id`, "a required field"), hasOwn(object, "owner_id") || invalid(`${path}.owner_id`, "a required field"), hasOwn(object, "title") || invalid(`${path}.title`, "a required field"), hasOwn(object, "note") || invalid(`${path}.note`, "a required field"), {
    id: ((raw, fieldPath) => validateUuid(raw, fieldPath))(object.id, `${path}.id`),
    owner_id: ((raw, fieldPath) => validateField_4_User_id(raw, fieldPath))(object.owner_id, `${path}.owner_id`),
    title: ((raw, fieldPath) => validate_ItemTitle(raw, fieldPath))(object.title, `${path}.title`),
    note: ((raw, fieldPath) => {
      let candidate2 = raw === null ? null : validateText(raw, fieldPath);
      return candidate2 === null ? null : candidate2;
    })(object.note, `${path}.note`)
  };
}
function validate_ItemPatch(value, path) {
  let object = expectObject(value, path);
  return rejectUnknownFields(object, ["title", "note"], path), {
    ...hasOwn(object, "title") ? { title: ((raw, fieldPath) => validateField_4_Item_title(raw, fieldPath))(object.title, `${path}.title`) } : {},
    ...hasOwn(object, "note") ? { note: ((raw, fieldPath) => {
      let candidate2 = validateField_4_Item_note(raw, fieldPath);
      return candidate2 === null ? null : candidate2;
    })(object.note, `${path}.note`) } : {}
  };
}
function validate_ProbeInput(value, path) {
  let object = expectObject(value, path);
  return rejectUnknownFields(object, ["id", "title", "note"], path), hasOwn(object, "id") || invalid(`${path}.id`, "a required field"), hasOwn(object, "title") || invalid(`${path}.title`, "a required field"), {
    id: ((raw, fieldPath) => validateField_4_Item_id(raw, fieldPath))(object.id, `${path}.id`),
    title: ((raw, fieldPath) => validate_ItemTitle(raw, fieldPath))(object.title, `${path}.title`),
    ...hasOwn(object, "note") ? { note: ((raw, fieldPath) => {
      let candidate2 = raw === null ? null : validateText(raw, fieldPath);
      return candidate2 === null ? null : candidate2;
    })(object.note, `${path}.note`) } : {}
  };
}
function validate_User(value, path) {
  let object = expectObject(value, path);
  return rejectUnknownFields(object, ["id"], path), hasOwn(object, "id") || invalid(`${path}.id`, "a required field"), {
    id: ((raw, fieldPath) => validateUuid(raw, fieldPath))(object.id, `${path}.id`)
  };
}
async function Item__change(id, changes, __operation = captureOperation(), __persistence = persistence) {
  return __persistence.withOperationTime(__operation.now).withPolicy(__operation.principal, "Item.change").transaction(async (persistence2) => await (async () => {
    let patchValue = changes, predicateValue = id;
    if (!(hasOwn(patchValue, "title") || hasOwn(patchValue, "note"))) throw new DomainFailure("EmptyPatch", {}, {});
    return await (async () => {
      try {
        let value = await persistence2.update_required_Item_by_id_patch_title_and_note(predicateValue, patchValue);
        if (value === null) throw new DomainFailure("ItemMissing", {}, {});
        return validate_Item(value, "database.Item");
      } catch (error) {
        throw error instanceof PersistenceFault && error.kind === "constraint" ? new DomainFailure("ItemConflict", {}, {}) : error;
      }
    })();
  })());
}
async function Item__read(id, __operation = captureOperation(), __persistence = persistence) {
  let persistence2 = __persistence.withPolicy(__operation.principal, "Item.read");
  return ((value) => {
    if (value === null) throw new DomainFailure("ItemMissing", {}, {});
    return validate_Item(value, "database.Item");
  })(await persistence2.query_required_Item_by_id(id));
}
async function Item__read_title(id, __operation = captureOperation(), __persistence = persistence) {
  let persistence2 = __persistence.withPolicy(__operation.principal, "Item.read_title");
  return (await Item__read(id, __operation, persistence2)).title;
}
async function Item__rename(id, title, __operation = captureOperation(), __persistence = persistence) {
  return __persistence.withOperationTime(__operation.now).withPolicy(__operation.principal, "Item.rename").transaction(async (persistence2) => await (async () => {
    try {
      let value = await (async (predicateValue) => persistence2.update_required_Item_by_id_set_title(predicateValue, title))(id);
      if (value === null) throw new DomainFailure("ItemMissing", {}, {});
      return validate_Item(value, "database.Item");
    } catch (error) {
      throw error instanceof PersistenceFault && error.kind === "constraint" ? new DomainFailure("ItemConflict", {}, {}) : error;
    }
  })());
}
async function probe(input, __operation = captureOperation(), __persistence = persistence) {
  let persistence2 = __persistence.withPolicy(__operation.principal, "probe");
  return await (async () => {
    try {
      return await Item__read_title(input.id, __operation, persistence2);
    } catch (error) {
      if (!(error instanceof DomainFailure)) throw error;
      if (error.failureName === "ItemMissing")
        return input.title;
      throw error;
    }
  })();
}
async function update_pair(first_id, first_title, second_id, second_title, __operation = captureOperation(), __persistence = persistence) {
  return __persistence.withOperationTime(__operation.now).withPolicy(__operation.principal, "update_pair").transaction(async (persistence2) => {
    let first = await Item__rename(first_id, first_title, __operation, persistence2);
    return await Item__rename(second_id, second_title, __operation, persistence2);
  });
}
var experimentCallables = {
  "Item.change": Item__change,
  "Item.read": Item__read,
  "Item.read_title": Item__read_title,
  "Item.rename": Item__rename,
  probe,
  update_pair
}, experimentValidators = {
  Item: validate_Item,
  ItemPatch: validate_ItemPatch,
  ItemRole: validate_ItemRole,
  ItemTitle: validate_ItemTitle,
  ProbeInput: validate_ProbeInput,
  User: validate_User
};

// experiments/wasm-exp1/workerd-boundary/worker.ts
var allowedTargets = ["js", "candidate", "typed", "views", "fused", "noop"], declarations = new Map(program_default.declarations.map((d) => [d.name, d]));
configureRows3(previous, row_codec_default2, 2);
configureRows2(candidate, row_codec_default, 14);
configureRows2(typed, row_codec_default, 15);
configureRows(views, row_codec_default, 14);
configureRows(fused, row_codec_default, 15);
if (candidate === typed) throw Error("Separate mode module identities required");
function freeze(v) {
  return v && typeof v == "object" && (Object.values(v).forEach(freeze), Object.freeze(v)), v;
}
var plans = new Map(row_codec_default.readPlans.map((p) => [p.args.operation, freeze(structuredClone(p.args))])), ReadAuthority = class extends DurableObject {
  storage;
  count = 0;
  note = "";
  constructor(ctx, env) {
    super(ctx, env), this.storage = createStorage(program_default, cloudflareSqlite(ctx.storage)), this.storage.setup();
  }
  reset(note) {
    if (note !== null && (typeof note != "string" || new TextEncoder().encode(JSON.stringify(note)).length > 64e3)) throw Error("fixture bound");
    let rows = structuredClone(acceptance_default.seeds.Item);
    return rows[0].note = note, this.storage.resetFixture({ Item: rows }), this.note = note, this.count = 0, { snapshot: this.storage.snapshot(), runtime: { hasBun: "Bun" in globalThis, hasNodeProcess: "process" in globalThis }, sqlite: "Platform-managed SQLite; sqlite_version() is not exposed by this host" };
  }
  begin() {
    return this.count = 0, { ok: !0 };
  }
  stats() {
    return { count: this.count, snapshot: this.storage.snapshot(), poolStats: { ...poolStats2 }, newPoolStats: { ...poolStats } };
  }
  changeOwner() {
    return this.ctx.storage.sql.exec("UPDATE entity_Item SET owner_id=? WHERE id=?", acceptance_default.seeds.principals.other.id, acceptance_default.seeds.Item[0].id), { ok: !0 };
  }
  async batch(call, iterations) {
    if (!Number.isInteger(iterations) || iterations < 1 || iterations > 2e3) throw Error("batch bound");
    let last, row = { ...acceptance_default.seeds.Item[0], note: this.note }, start = performance.now();
    for (let i = 0; i < iterations; i++)
      if (last = await this.call(call), last.kind !== "success" || (call.operation === "Item.read" ? Object.keys(last.value).length !== Object.keys(row).length || Object.entries(row).some(([k, v]) => last.value[k] !== v) : last.value !== row.title)) throw Error("batch response");
    return { last, iterations, elapsedMs: performance.now() - start };
  }
  profile(options) {
    return profileStages(this.storage, candidate, options);
  }
  async call(call) {
    let { target, operation, input, principal: principalName = "owner" } = call;
    if (!allowedTargets.includes(target) || !["Item.read", "Item.read_title", "probe"].includes(operation) || !["owner", "other"].includes(principalName)) throw Error("fixture operation");
    this.count++;
    let principal = acceptance_default.seeds.principals[principalName], trusted = { entity: principal.entity, values: { id: principal.id } };
    if (target === "noop") return { kind: "success", value: operation === "Item.read" ? { ...acceptance_default.seeds.Item[0], note: this.note } : acceptance_default.seeds.Item[0].title };
    if (target === "js") {
      let argument;
      try {
        argument = operation === "probe" ? experimentValidators.ProbeInput(input, "input") : experimentValidators.User({ id: input }, "input").id;
      } catch (error) {
        if (error instanceof ValidationError) return { kind: "invalid" };
        throw error;
      }
      let storage = this.storage, port = (name) => ({
        withPolicy: (_principal, next) => port(next),
        query_required_Item_by_id: (id) => {
          let plan = plans.get(name);
          if (!plan) throw Error("checked read plan");
          return storage.read({ ...plan, predicate: { ...plan.predicate, value: id } }, trusted).value;
        }
      });
      try {
        return { kind: "success", value: await experimentCallables[operation](argument, captureOperation(null, { kind: "user", subject: principal.id, values: { user_id: principal.id } }), port(operation)) };
      } catch (error) {
        return error instanceof DomainFailure ? { kind: "domain", failure: error.failureName } : { kind: "internal" };
      }
    }
    return (["views", "fused"].includes(target) ? invokeSync : invokeSync2)(target === "views" ? views : target === "fused" ? fused : target === "typed" ? typed : candidate, declarations.get(operation).semanticId, input, (cap, args) => {
      if (cap !== "storage.read") throw Error("read-only experiment");
      return this.storage.read(args, trusted);
    });
  }
}, worker_default = {
  async fetch(request, env) {
    if (request.method !== "POST" || request.headers.get("x-experiment-token") !== env.EXPERIMENT_TOKEN) return new Response("Not found", { status: 404 });
    let reader = request.body?.getReader();
    if (!reader) return new Response("Missing body", { status: 400 });
    let chunks = [], size = 0;
    for (; ; ) {
      let { done, value } = await reader.read();
      if (done) break;
      if (size += value.byteLength, size > 65536)
        return await reader.cancel(), new Response("Too large", { status: 413 });
      chunks.push(value);
    }
    let bytes = new Uint8Array(size), offset = 0;
    for (let chunk of chunks)
      bytes.set(chunk, offset), offset += chunk.length;
    let input = JSON.parse(new TextDecoder("utf-8", { fatal: !0 }).decode(bytes)), { action, key } = input;
    if (typeof key != "string" || !/^run-[a-z0-9-]{1,80}$/.test(key)) return new Response("Invalid fixture", { status: 400 });
    let authority = env.READ_AUTHORITY.getByName(key), output;
    if (action === "reset") output = await authority.reset(input.note);
    else if (action === "begin") output = await authority.begin();
    else if (action === "stats") output = await authority.stats();
    else if (action === "changeOwner") output = await authority.changeOwner();
    else if (action === "batch") output = await authority.batch(input.call, input.iterations);
    else if (action === "profile") output = await authority.profile(input.options);
    else if (action === "call") output = await authority.call(input.call);
    else return new Response("Not found", { status: 404 });
    return Response.json(output);
  }
};
export {
  ReadAuthority,
  worker_default as default
};
