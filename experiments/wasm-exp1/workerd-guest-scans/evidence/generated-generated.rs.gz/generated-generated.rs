// Compiler-owned probe runtime. Application logic is appended by generate.py.
use serde_json::{json, Value};
use std::future::Future;
use std::pin::Pin;
use std::task::{Context, Poll, RawWaker, RawWakerVTable, Waker};

#[derive(Debug)]
enum Fault { Domain(&'static str), Internal(u32), Invalid }
type Outcome = Result<AppValue, Fault>;
struct HostValue { value: Value, json_bound: Option<usize>, typed: Option<CheckedRow>, origin: Option<RowOrigin> }
static mut HOST_TYPED_ROW: Option<CheckedRow> = None;
static mut HOST_ROW_ORIGIN: Option<RowOrigin> = None;
type HostOutcome = Result<HostValue, Fault>;
static mut HOST_JSON_BOUND: Option<usize> = None;
static mut FRAME: Option<Pin<Box<dyn Future<Output = Outcome>>>> = None;
static mut OUTPUT: Vec<u8> = Vec::new();
static mut ALLOCATIONS: Vec<Vec<u8>> = Vec::new();
static mut STARTED: bool = false;
static mut REQUEST_ID: u32 = 1;
static mut PENDING: Option<(u32, u32)> = None;
static mut HOST_RESULT: Option<Value> = None;
static mut NEXT_OPERATION: u32 = 0;
static mut CURRENT_SEMANTIC_OPERATION: u32 = 0;
const LIMIT: usize = 65_536;

fn emit(value: Value, status: i32) -> i32 {
    unsafe { OUTPUT_FORMAT=0; }
    if status==0 && unsafe {ROW_FLAGS&2!=0 && RETURN_SCHEMA!=0} {
        if let (Some(schema),Some(row))=(row_schema(unsafe{RETURN_SCHEMA}),value.get("value")) {
            if row.as_object().map_or(false,|o|o.values().any(|v|v.as_str().map_or(false,|s|s.len()>=1024))) {
                if json_len(&value)>LIMIT {return fault(Fault::Internal(unsafe{CURRENT_SEMANTIC_OPERATION}));}
                if let Some(bytes)=encode_row(schema,row) {
                    unsafe {OUTPUT=bytes;OUTPUT_FORMAT=1;} return status;
                }
                // A very short schema can have a larger binary than JSON frame.
                // Keep a valid JSON-sized result working through the legacy path.
            }
        }
    }
    let bytes = serde_json::to_vec(&value).unwrap_or_default();
    let oversized = bytes.len() > LIMIT;
    unsafe {
        OUTPUT = if !oversized { bytes } else {
            br#"{"kind":"internal","operation":0}"#.to_vec()
        };
    }
    if oversized { 3 } else { status }
}
fn fault(error: Fault) -> i32 {
    match error {
        Fault::Domain(name) => emit(json!({"kind":"domain","failure":name}), 1),
        Fault::Internal(operation) => emit(json!({"kind":"internal","operation":operation}), 3),
        Fault::Invalid => emit(json!({"kind":"invalid"}), 4),
    }
}
fn allocated_bytes(pointer: i32, length: i32) -> Result<&'static [u8], Fault> {
    if pointer <= 0 || length < 0 || length as usize > LIMIT { return Err(Fault::Invalid); }
    let pointer = pointer as usize;
    let length = length as usize;
    let valid = unsafe { ALLOCATIONS.iter().any(|v| {
        let start = v.as_ptr() as usize;
        pointer >= start && pointer.checked_add(length).map_or(false, |end| end <= start + v.len())
    }) };
    if !valid { return Err(Fault::Invalid); }
    Ok(unsafe { std::slice::from_raw_parts(pointer as *const u8, length) })
}
fn decode(pointer: i32, length: i32) -> Result<Value, Fault> {
    serde_json::from_slice(allocated_bytes(pointer,length)?).map_err(|_| Fault::Invalid)
}
#[no_mangle]
pub extern "C" fn alloc(length: i32) -> i32 {
    if length <= 0 || length as usize > LIMIT { return 0; }
    unsafe {
        if ALLOCATIONS.len() >= 64 { return 0; }
        let mut bytes = Vec::new();
        if bytes.try_reserve_exact(length as usize).is_err() { return 0; }
        bytes.resize(length as usize, 0);
        let pointer = bytes.as_mut_ptr() as i32;
        ALLOCATIONS.push(bytes);
        pointer
    }
}
#[no_mangle]
pub extern "C" fn result_ptr() -> i32 { unsafe { OUTPUT.as_ptr() as i32 } }
#[no_mangle]
pub extern "C" fn result_len() -> i32 { unsafe { OUTPUT.len() as i32 } }

fn raw_waker() -> RawWaker {
    unsafe fn clone(_: *const ()) -> RawWaker { raw_waker() }
    unsafe fn noop(_: *const ()) {}
    RawWaker::new(std::ptr::null(), &RawWakerVTable::new(clone, noop, noop, noop))
}
fn drive() -> i32 {
    let Some(mut frame) = (unsafe { FRAME.take() }) else { return fault(Fault::Internal(0)); };
    let waker = unsafe { Waker::from_raw(raw_waker()) };
    match frame.as_mut().poll(&mut Context::from_waker(&waker)) {
        Poll::Ready(Ok(value)) => { unsafe { PENDING = None; } {
            emit_app(value)
        } },
        Poll::Ready(Err(error)) => { unsafe { PENDING = None; } fault(error) },
        Poll::Pending => { unsafe { FRAME = Some(frame); } 2 },
    }
}
// ABI extension: reset only a completed request; pending frames cannot be reused.
// Bump request identity so handles from an earlier lease cannot resume this one.
#[no_mangle]
pub extern "C" fn reset() -> i32 {
    unsafe {
        if FRAME.is_some() || PENDING.is_some() || REQUEST_ID >= i32::MAX as u32 { return 0; }
        HOST_RESULT = None;
        HOST_JSON_BOUND = None;
        HOST_TYPED_ROW=None; HOST_ROW_ORIGIN=None;
        FRAME = None;
        OUTPUT.clear();
        ALLOCATIONS.clear();
        STARTED = false;
        NEXT_OPERATION = 0;
        CURRENT_SEMANTIC_OPERATION = 0;
        ROW_BUDGET_EXCEEDED=false;ROW_FLAGS=0;OUTPUT_FORMAT=0;RETURN_SCHEMA=0;PENDING_ROW_SCHEMA=0;
        REQUEST_ID += 1;
    }
    1
}
#[no_mangle]
pub extern "C" fn start(operation: i32, pointer: i32, length: i32) -> i32 {
    unsafe {
        if STARTED { FRAME = None; PENDING = None; return fault(Fault::Internal(operation as u32)); }
        STARTED = true;
        CURRENT_SEMANTIC_OPERATION = operation as u32;
        RETURN_SCHEMA=row_schema_for_entry(operation);
    }
    let input = match decode(pointer, length) { Ok(v) => v, Err(e) => return fault(e) };
    match make_entry(operation, input) {
        Ok(frame) => { unsafe { FRAME = Some(frame); } drive() },
        Err(error) => fault(error),
    }
}
#[no_mangle]
pub extern "C" fn resume(request: i32, operation: i32, pointer: i32, length: i32) -> i32 {
    resume_impl(request,operation,pointer,length,None)
}
#[no_mangle]
pub extern "C" fn resume_ref(request:i32,operation:i32,pointer:i32,length:i32)->i32 {
    if unsafe{ROW_FLAGS&4==0 || PENDING_ROW_SCHEMA==0} {return fault(Fault::Internal(unsafe{CURRENT_SEMANTIC_OPERATION}));}
    resume_impl(request,operation,pointer,length,Some(RowOrigin{request:request as u32,operation:operation as u32}))
}
fn resume_impl(request:i32,operation:i32,pointer:i32,length:i32,origin:Option<RowOrigin>)->i32 {
    unsafe {
        if PENDING != Some((request as u32, operation as u32)) || FRAME.is_none() {
            FRAME = None; PENDING = None; HOST_RESULT = None;
            return fault(Fault::Internal(CURRENT_SEMANTIC_OPERATION));
        }
    }
    let value = match decode(pointer, length) {
        Ok(v) => v,
        Err(_) => { unsafe { FRAME = None; PENDING = None; return fault(Fault::Internal(CURRENT_SEMANTIC_OPERATION)); } }
    };
    unsafe { HOST_RESULT = Some(value); HOST_JSON_BOUND = Some(length as usize); HOST_ROW_ORIGIN=origin;HOST_TYPED_ROW=None; }
    drive()
}

struct HostRead { args: Value, semantic: u32, issued: bool, capability: &'static str, compact: bool }
impl Future for HostRead {
    type Output = HostOutcome;
    fn poll(mut self: Pin<&mut Self>, _: &mut Context<'_>) -> Poll<HostOutcome> {
        if !self.issued {
            self.issued = true;
            unsafe {
                NEXT_OPERATION += 1;
                CURRENT_SEMANTIC_OPERATION = self.semantic;
                PENDING = Some((REQUEST_ID, NEXT_OPERATION));
                PENDING_ROW_SCHEMA=if self.compact {compact_plan(self.semantic).map_or(0,|p|p.0)} else if self.capability=="storage.read" {
                    self.args.get("entity").and_then(Value::as_str).map(row_schema_for_name).unwrap_or(0)
                } else {0};
                if self.compact {
                    if emit_compact_read(&self.args,self.semantic,REQUEST_ID,NEXT_OPERATION).is_err() {
                        PENDING=None;return Poll::Ready(Err(Fault::Internal(self.semantic)));
                    }
                    return Poll::Pending;
                }
                let mut envelope = json!({"kind":"pending","requestId":REQUEST_ID,"operationId":NEXT_OPERATION,
                    "capability":self.capability});
                envelope["args"] = std::mem::take(&mut self.args);
                let status = emit(envelope, 2);
                if status != 2 {
                    PENDING = None;
                    return Poll::Ready(Err(Fault::Internal(self.semantic)));
                }
            }
            return Poll::Pending;
        }
        if let Some(mut row)=unsafe{HOST_TYPED_ROW.take()} {
            unsafe{PENDING=None;row.origin=HOST_ROW_ORIGIN.take();}
            return Poll::Ready(Ok(HostValue{value:Value::Null,json_bound:row.json_bound,typed:Some(row),origin:None}));
        }
        let Some(mut result) = (unsafe { HOST_RESULT.take() }) else { return Poll::Pending; };
        unsafe { PENDING = None; }
        let Some(object) = result.as_object_mut() else { return Poll::Ready(Err(Fault::Internal(self.semantic))); };
        // Raw host domain failures are not accepted: query absence is a null value,
        // and generated code selects the authored missing failure inside Wasm.
        if object.len() == 2 && object.get("kind").and_then(Value::as_str) == Some("success") && object.contains_key("value") {
            Poll::Ready(Ok(HostValue {value: object.remove("value").unwrap(), json_bound: if self.capability=="storage.read" {unsafe{HOST_JSON_BOUND.take()}} else {None}, typed:None, origin:unsafe{HOST_ROW_ORIGIN.take()}}))
        } else { Poll::Ready(Err(Fault::Internal(self.semantic))) }
    }
}
fn host_read(args: Value, semantic: u32) -> HostRead { HostRead { args, semantic, issued: false, capability: "storage.read", compact:false } }
fn host_read_compact(predicate:Value,semantic:u32)->HostRead {HostRead{args:predicate,semantic,issued:false,capability:"storage.read",compact:true}}
fn emit_compact_read(predicate:&Value,semantic:u32,request:u32,operation:u32)->Result<(),()> {
    let (_,base)=compact_plan(semantic).ok_or(())?;
    let bytes=serde_json::to_vec(predicate).map_err(|_|())?;
    // Preserve the exact legacy envelope limit, including escaped UTF-8 and IDs.
    if base-4+bytes.len()+request.to_string().len()-1+operation.to_string().len()-1>LIMIT || bytes.len()+48>LIMIT {return Err(());}
    let mut output=Vec::with_capacity(48+bytes.len());
    output.extend_from_slice(b"JRP1");output.extend_from_slice(&ROW_DIGEST);
    output.extend_from_slice(&request.to_le_bytes());output.extend_from_slice(&operation.to_le_bytes());
    output.extend_from_slice(&semantic.to_le_bytes());output.extend_from_slice(&bytes);
    unsafe{OUTPUT=output;OUTPUT_FORMAT=3;}Ok(())
}
fn host_update(args: Value, semantic: u32) -> HostRead { HostRead { args, semantic, issued: false, capability: "storage.update", compact:false } }
fn member(value: &AppValue, path: &[&str], operation: u32) -> Outcome {
    if path.is_empty() {return Ok(value.clone());}
    match value {
        AppValue::Json(value) => {
            let mut result=value;
            for key in path {result=result.get(*key).ok_or(Fault::Internal(operation))?;}
            Ok(AppValue::Json(result.clone()))
        },
        AppValue::Row(row) => {
            if path.len()!=1 {return Err(Fault::Internal(operation));}
            let i=row.schema.fields.iter().position(|key|*key==path[0]).ok_or(Fault::Internal(operation))?;
            Ok(AppValue::Json(row.fields[i].to_json().ok_or(Fault::Internal(operation))?))
        },
    }
}
fn uuid(value: &Value) -> bool {
    let Some(text) = value.as_str() else { return false; };
    let bytes = text.as_bytes();
    bytes.len() == 36 && bytes.iter().enumerate().all(|(i,b)| {
        if [8,13,18,23].contains(&i) { *b == b'-' } else { b.is_ascii_hexdigit() }
    }) && matches!(bytes[14], b'1'..=b'5') && matches!(bytes[19], b'8'|b'9'|b'a'|b'b'|b'A'|b'B')
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn oversized_completion_reports_internal_status() {
        assert_eq!(emit(json!({"kind":"success","value":"x".repeat(LIMIT)}), 0), 3);
        let output: Value = unsafe { serde_json::from_slice(&OUTPUT).unwrap() };
        assert_eq!(output["kind"], "internal");
    }
    #[test]
    fn oversized_pending_completes_with_internal_fault() {
        let mut host = Box::pin(host_read(json!({"huge":"x".repeat(LIMIT)}), 26));
        let waker = unsafe { Waker::from_raw(raw_waker()) };
        assert!(matches!(host.as_mut().poll(&mut Context::from_waker(&waker)), Poll::Ready(Err(Fault::Internal(26)))));
        assert!(unsafe { PENDING.is_none() });
    }
}

#[cfg(test)]
mod compact_tests {
    use super::*;
    #[test]
    fn compact_budget_matches_exact_legacy_envelope_limit() {
        let id=(0..65536u32).find(|id|compact_plan(*id).is_some()).unwrap();
        let (_,base)=compact_plan(id).unwrap();
        for (request,operation) in [(1u32,1u32),(999,63)] {
            let digits=request.to_string().len()-1+operation.to_string().len()-1;
            let length=LIMIT-base+2-digits;
            let predicate=Value::String("x".repeat(length));
            assert!(emit_compact_read(&predicate,id,request,operation).is_ok());
            assert!(emit_compact_read(&Value::String("x".repeat(length+1)),id,request,operation).is_err());
            assert!(emit_compact_read(&Value::String("\n".repeat(length)),id,request,operation).is_err());
        }
        assert!(emit_compact_read(&Value::Null,0,1,1).is_err());
        unsafe{OUTPUT_FORMAT=0;OUTPUT.clear();}
    }
}


// Experimental schema-bound row frames. Control/input/error frames remain JSON.
// Typed field order is generated from the checked projection, not fixture names.
struct RowSchema { id: u32, name: &'static str, fields: &'static [&'static str] }
static mut ROW_FLAGS: u32 = 0;
static mut OUTPUT_FORMAT: u32 = 0;
static mut RETURN_SCHEMA: u32 = 0;
static mut PENDING_ROW_SCHEMA: u32 = 0;

#[no_mangle]
pub extern "C" fn set_row_transport(flags: u32) -> i32 {
    unsafe {
        if STARTED || flags > 15 { return 0; }
        ROW_FLAGS = flags; OUTPUT_FORMAT = 0; 1
    }
}
#[no_mangle]
pub extern "C" fn result_format() -> u32 { unsafe { OUTPUT_FORMAT } }

// Match the existing JSON byte bound without constructing an intermediate JSON
// buffer. Number serialization uses serde's spelling; strings retain JSON escapes.
fn scalar_json_text_len(s: &str) -> usize {
        fn extra(bytes:&[u8])->usize {bytes.iter().map(|b|match b {b'"'|b'\\'|8|9|10|12|13=>1,0..=31=>5,_=>0}).sum()}
        fn has_zero(n:u64)->bool {n.wrapping_sub(0x0101010101010101)&!n&0x8080808080808080!=0}
        let mut total=2+s.len();let mut chunks=s.as_bytes().chunks_exact(8);
        for chunk in &mut chunks {
            let n=u64::from_le_bytes(chunk.try_into().unwrap());
            // A zero byte after masking the top three bits means a control byte.
            // Borrow propagation can give false positives, never false negatives.
            if has_zero(n&0xe0e0e0e0e0e0e0e0)||has_zero(n^0x2222222222222222)||has_zero(n^0x5c5c5c5c5c5c5c5c){total+=extra(chunk);}
        }
        total+extra(chunks.remainder())
    }

fn json_text_len(s:&str)->usize {
    #[cfg(all(feature="vector",target_arch="wasm32"))]
    {unsafe {vector_json_text_len(s)}}
    #[cfg(not(all(feature="vector",target_arch="wasm32")))]
    {scalar_json_text_len(s)}
}
#[cfg(all(feature="vector",target_arch="wasm32"))]
#[target_feature(enable="simd128")]
unsafe fn vector_json_text_len(s:&str)->usize {
    use std::arch::wasm32::*;
    let mut total=s.len()+2;
    let mut chunks=s.as_bytes().chunks_exact(16);
    for chunk in &mut chunks {
        // chunks_exact guarantees that all 16 loaded bytes are in this string.
        let v=v128_load(chunk.as_ptr() as *const v128);
        let control=u8x16_lt(v,u8x16_splat(32));
        let quote=v128_or(i8x16_eq(v,i8x16_splat(34)),i8x16_eq(v,i8x16_splat(92)));
        let short=v128_or(v128_or(i8x16_eq(v,i8x16_splat(8)),i8x16_eq(v,i8x16_splat(9))),
            v128_or(i8x16_eq(v,i8x16_splat(10)),v128_or(i8x16_eq(v,i8x16_splat(12)),i8x16_eq(v,i8x16_splat(13)))));
        total+=i8x16_bitmask(v128_or(control,quote)).count_ones() as usize;
        total+=4*i8x16_bitmask(v128_andnot(control,short)).count_ones() as usize;
    }
    total+chunks.remainder().iter().map(|b|match b {b'"'|b'\\'|8|9|10|12|13=>1,0..=31=>5,_=>0}).sum::<usize>()
}

fn json_len(value: &Value) -> usize {
    match value {
        Value::Null => 4, Value::Bool(true) => 4, Value::Bool(false) => 5,
        Value::Number(n) => n.to_string().len(), Value::String(s) => json_text_len(s),
        Value::Array(a) => 2 + a.len().saturating_sub(1) + a.iter().map(json_len).sum::<usize>(),
        Value::Object(o) => 2 + o.len().saturating_sub(1) + o.iter().map(|(k,v)| json_text_len(k)+1+json_len(v)).sum::<usize>(),
    }
}
fn row_schema(id: u32) -> Option<&'static RowSchema> { ROW_SCHEMAS.iter().find(|s| s.id == id) }
fn encode_row(schema: &RowSchema, row: &Value) -> Option<Vec<u8>> {
    let object = row.as_object()?;
    if object.keys().any(|k| !schema.fields.contains(&k.as_str())) { return None; }
    let capacity=40+schema.fields.len()*9+object.values().filter_map(Value::as_str).map(str::len).sum::<usize>();
    let mut bytes=Vec::with_capacity(capacity);
    bytes.extend_from_slice(b"JRW1");bytes.extend_from_slice(&ROW_DIGEST);
    bytes.extend_from_slice(&schema.id.to_le_bytes());
    for key in schema.fields {
        match object.get(*key) {
            None => bytes.push(0), Some(Value::Null) => bytes.push(1),
            Some(Value::String(s)) => { bytes.push(2);bytes.extend_from_slice(&(s.len() as u32).to_le_bytes());bytes.extend_from_slice(s.as_bytes()); },
            Some(Value::Bool(false)) => bytes.push(3), Some(Value::Bool(true)) => bytes.push(4),
            Some(Value::Number(n)) => {bytes.push(5);bytes.extend_from_slice(&n.as_i64()?.to_le_bytes());},
            _ => return None,
        }
    }
    if bytes.len()>LIMIT {None} else {Some(bytes)}
}
fn decode_row(bytes: &[u8], expected: u32) -> Option<Value> {
    if bytes.len()<40 || bytes.len()>LIMIT || &bytes[..4]!=b"JRW1" || bytes[4..36]!=ROW_DIGEST { return None; }
    let id=u32::from_le_bytes(bytes[36..40].try_into().ok()?);
    if id!=expected {return None;}
    let schema=row_schema(id)?; let mut pos=40;
    let mut object=serde_json::Map::new();
    for key in schema.fields {
        let tag=*bytes.get(pos)?;pos+=1;
        let value=match tag {
            0 => continue, 1 => Value::Null, 3 => Value::Bool(false), 4 => Value::Bool(true),
            2 => {
                let end=pos.checked_add(4)?;let len=u32::from_le_bytes(bytes.get(pos..end)?.try_into().ok()?) as usize;pos=end;
                let end=pos.checked_add(len)?;let s=std::str::from_utf8(bytes.get(pos..end)?).ok()?;pos=end;Value::String(s.to_owned())
            },
            5 => {let end=pos.checked_add(8)?;let n=i64::from_le_bytes(bytes.get(pos..end)?.try_into().ok()?);pos=end;Value::Number(n.into())},
            _ => return None,
        };
        object.insert((*key).to_owned(),value);
    }
    if pos!=bytes.len() {return None;}
    let row=Value::Object(object);
    // Generated application validates the returned row after this decoding step.
    // Enforce the original host success-envelope JSON size as well as binary size.
    if json_len(&row)+27>LIMIT {None} else {Some(row)}
}
#[no_mangle]
pub extern "C" fn resume_row(request:i32,operation:i32,pointer:i32,length:i32)->i32 {
    resume_row_impl(request,operation,pointer,length,None)
}
#[no_mangle]
pub extern "C" fn resume_row_ref(request:i32,operation:i32,pointer:i32,length:i32)->i32 {
    if unsafe{ROW_FLAGS&4==0} {return fault(Fault::Internal(unsafe{CURRENT_SEMANTIC_OPERATION}));}
    resume_row_impl(request,operation,pointer,length,Some(RowOrigin{request:request as u32,operation:operation as u32}))
}
fn resume_row_impl(request:i32,operation:i32,pointer:i32,length:i32,origin:Option<RowOrigin>)->i32 {
    unsafe{ROW_BUDGET_EXCEEDED=false;}
    let invalid=||unsafe {FRAME=None;PENDING=None;HOST_RESULT=None;fault(Fault::Internal(CURRENT_SEMANTIC_OPERATION))};
    unsafe {
        if ROW_FLAGS&1==0 || PENDING_ROW_SCHEMA==0 || PENDING!=Some((request as u32,operation as u32)) || FRAME.is_none() {return invalid();}
    }
    let bytes=match allocated_bytes(pointer,length) {Ok(b)=>b,Err(_)=>return invalid()};
    let row=match decode_typed_row(bytes,unsafe{PENDING_ROW_SCHEMA}) {Some(v)=>v,None=>return invalid()};
    unsafe {HOST_TYPED_ROW=Some(row);HOST_RESULT=None;HOST_JSON_BOUND=None;
        HOST_ROW_ORIGIN=origin;
    }
    drive()
}

#[cfg(test)]
mod row_tests {
    use super::*;
    #[test]
    fn larger_binary_frame_falls_back_to_valid_json() {
        let schema=ROW_SCHEMAS.iter().find(|s|s.fields.len()==1).unwrap();
        let mut object=serde_json::Map::new();object.insert(schema.fields[0].to_owned(),Value::String(String::new()));
        let mut value=json!({"kind":"success","value":object});
        let length=LIMIT-json_len(&value);
        value["value"][schema.fields[0]]=Value::String("x".repeat(length));
        assert_eq!(json_len(&value),LIMIT);
        assert!(encode_row(schema,&value["value"]).is_none());
        unsafe{ROW_FLAGS=2;RETURN_SCHEMA=schema.id;}
        assert_eq!(emit(value,0),0);assert_eq!(result_format(),0);
        unsafe{ROW_FLAGS=0;RETURN_SCHEMA=0;}
    }
    #[test]
    fn json_budget_matches_serializer() {
        for s in ["", "ascii", "é中😀", "\"\\\n\r\t\0\u{0008}\u{000c}", "\u{0001}\u{001f}"] {
            let v=json!({"kind":"success","value":{"a":s,"b":[null,true,false,-42]}});
            assert_eq!(json_len(&v),serde_json::to_vec(&v).unwrap().len());
        }
        assert_eq!(serde_json::to_vec(&json!({"kind":"success","value":null})).unwrap().len(),27+4);
        // Exhaustive byte values at every chunk position, plus Unicode and tails.
        for byte in 0..=127u8 {for pos in 0..24 {
            let mut bytes=vec![b'x';31];bytes[pos]=byte;
            let value=Value::String(String::from_utf8(bytes).unwrap());
            assert_eq!(json_len(&value),serde_json::to_vec(&value).unwrap().len());
        }}
    }
}


// Immutable compiler-internal rows. No references into exported Wasm memory.
// Scalars and presence are stored in checked-schema order; sharing a row never
// duplicates its text. Generic inputs, updates and control messages remain JSON.
use std::rc::Rc;

#[derive(Clone)]
enum AppValue { Json(Value), Row(Rc<CheckedRow>) }
#[derive(Debug)]
enum Field { Missing, Null, Text(String), Bool(bool), Int(i64) }
#[derive(Clone,Copy)]
struct RowOrigin { request:u32, operation:u32 }
struct CheckedRow {
    origin: Option<RowOrigin>,
    schema: &'static RowSchema,
    fields: Vec<Field>,
    // A canonical flat-row success envelope cannot exceed the original, accepted
    // JSON success envelope. Ownership and immutability preserve this proof.
    // The bound is obtained locally at resume, never accepted as host metadata.
    json_bound: Option<usize>,
}
impl Field {
    fn to_json(&self) -> Option<Value> { Some(match self {
        Self::Missing => return None, Self::Null => Value::Null,
        Self::Text(s) => Value::String(s.clone()), Self::Bool(b) => Value::Bool(*b),
        Self::Int(n) => Value::Number((*n).into()),
    }) }
    fn into_json(self) -> Option<Value> { Some(match self {
        Self::Missing => return None, Self::Null => Value::Null,
        Self::Text(s) => Value::String(s), Self::Bool(b) => Value::Bool(b),
        Self::Int(n) => Value::Number(n.into()),
    }) }
}
impl AppValue {
    // Called only after the generated entity validator succeeds. Unsupported
    // record shapes retain the reference representation and its size checks.
    fn checked_row(name: &str, row: Value, json_bound: Option<usize>) -> Self {
        Self::checked_row_origin(name,row,json_bound,None)
    }
    fn checked_row_origin(name:&str,row:Value,json_bound:Option<usize>,origin:Option<RowOrigin>)->Self {
        let schema=match row_schema(row_schema_for_name(name)) {Some(s)=>s,None=>return Self::Json(row)};
        let eligible=row.as_object().map_or(false,|o|
            o.keys().all(|k|schema.fields.contains(&k.as_str())) &&
            o.values().all(|v|v.is_null()||v.is_string()||v.is_boolean()||v.as_i64().is_some()));
        if !eligible || !row.as_object().unwrap().values().any(|v|v.as_str().map_or(false,|s|s.len()>=1024)) {return Self::Json(row);}
        let Value::Object(mut object)=row else {unreachable!()};
        let fields=schema.fields.iter().map(|key|match object.remove(*key) {
            None=>Field::Missing,Some(Value::Null)=>Field::Null,
            Some(Value::String(s))=>Field::Text(s),Some(Value::Bool(b))=>Field::Bool(b),
            Some(Value::Number(n))=>Field::Int(n.as_i64().unwrap()),_=>unreachable!(),
        }).collect();
        Self::Row(Rc::new(CheckedRow {schema,fields,json_bound,origin}))
    }
    fn into_json(self) -> Value {match self {
        Self::Json(v)=>v,
        Self::Row(row)=>{
            let object=match Rc::try_unwrap(row) {
                Ok(row)=>row.schema.fields.iter().zip(row.fields).filter_map(|(k,v)|v.into_json().map(|v|((*k).to_owned(),v))).collect(),
                Err(row)=>row.schema.fields.iter().zip(&row.fields).filter_map(|(k,v)|v.to_json().map(|v|((*k).to_owned(),v))).collect(),
            };
            Value::Object(object)
        },
    }}
}
impl CheckedRow {
    fn large(&self)->bool {self.fields.iter().any(|f|matches!(f,Field::Text(s) if s.len()>=1024))}
    fn binary(&self)->Option<Vec<u8>> {
        let capacity=40+self.fields.len()*9+self.fields.iter().map(|f|if let Field::Text(s)=f{s.len()}else{0}).sum::<usize>();
        let mut bytes=Vec::with_capacity(capacity);
        bytes.extend_from_slice(b"JRW1");bytes.extend_from_slice(&ROW_DIGEST);bytes.extend_from_slice(&self.schema.id.to_le_bytes());
        for field in &self.fields {match field {
            Field::Missing=>bytes.push(0),Field::Null=>bytes.push(1),
            Field::Text(s)=>{bytes.push(2);bytes.extend_from_slice(&(s.len() as u32).to_le_bytes());bytes.extend_from_slice(s.as_bytes());},
            Field::Bool(false)=>bytes.push(3),Field::Bool(true)=>bytes.push(4),
            Field::Int(n)=>{bytes.push(5);bytes.extend_from_slice(&n.to_le_bytes());},
        }}
        if bytes.len()>LIMIT {None} else {Some(bytes)}
    }
}
fn emit_app(value:AppValue)->i32 {
    if let AppValue::Row(row)=&value {
        if unsafe{ROW_FLAGS&4!=0 && RETURN_SCHEMA==row.schema.id} && row.large() && row.json_bound.map_or(false,|n|n<=LIMIT) {
            if let Some(origin)=row.origin {
                let mut bytes=Vec::with_capacity(48);bytes.extend_from_slice(b"JRR1");bytes.extend_from_slice(&ROW_DIGEST);
                bytes.extend_from_slice(&row.schema.id.to_le_bytes());bytes.extend_from_slice(&origin.request.to_le_bytes());bytes.extend_from_slice(&origin.operation.to_le_bytes());
                unsafe{OUTPUT=bytes;OUTPUT_FORMAT=2;}return 0;
            }
        }
        if unsafe{ROW_FLAGS&2!=0 && RETURN_SCHEMA==row.schema.id} && row.large() && row.json_bound.map_or(false,|bound|bound<=LIMIT) {
            if let Some(bytes)=row.binary() {unsafe{OUTPUT=bytes;OUTPUT_FORMAT=1;}return 0;}
        }
    }
    // Transformations, unknown provenance and oversized binary frames use the
    // reference path, which computes/enforces the exact outgoing JSON budget.
    {
        let mut envelope=serde_json::Map::new();
        envelope.insert("kind".to_owned(),Value::String("success".to_owned()));
        envelope.insert("value".to_owned(),value.into_json());
        emit(Value::Object(envelope),0)
    }
}

#[cfg(test)]
mod typed_tests {
    use super::*;
    #[test]
    fn shared_row_has_owned_storage_and_materialisation_drops_proof() {
        let schema=ROW_SCHEMAS.iter().find(|s|s.fields.len()==1).unwrap();
        let row=json!({schema.fields[0]:"x".repeat(4096)});
        let value=AppValue::checked_row(schema.name,row.clone(),Some(4200));
        let clone=value.clone();
        match (&value,&clone) {(AppValue::Row(a),AppValue::Row(b))=>assert!(Rc::ptr_eq(a,b)),_=>panic!()};
        let mut changed=clone.into_json();changed[schema.fields[0]]=Value::String("y".repeat(LIMIT));
        assert_eq!(value.into_json(),row);
        unsafe{ROW_FLAGS=2;RETURN_SCHEMA=schema.id;}
        assert_eq!(emit_app(AppValue::Json(changed)),3);
        unsafe{ROW_FLAGS=0;RETURN_SCHEMA=0;}
    }
    #[test]
    fn unproven_rows_still_enforce_json_budget() {
        let schema=ROW_SCHEMAS.iter().find(|s|s.fields.len()==1).unwrap();
        let row=json!({schema.fields[0]:"\n".repeat(34000)});
        let value=AppValue::checked_row(schema.name,row,None);
        unsafe{ROW_FLAGS=2;RETURN_SCHEMA=schema.id;}
        assert_eq!(emit_app(value),3);
        unsafe{ROW_FLAGS=0;RETURN_SCHEMA=0;}
    }
}


// Decode owned scalars directly, avoiding a generic JSON/map round trip.
impl Field {
    fn is_null(&self)->bool {matches!(self,Self::Null)}
    fn is_string(&self)->bool {matches!(self,Self::Text(_))}
    fn is_boolean(&self)->bool {matches!(self,Self::Bool(_))}
    fn as_str(&self)->Option<&str> {if let Self::Text(s)=self {Some(s)} else {None}}
    fn as_i64(&self)->Option<i64> {if let Self::Int(n)=self {Some(*n)} else {None}}
    fn json_len(&self)->usize {match self {
        Self::Missing=>0,Self::Null=>4,Self::Bool(true)=>4,Self::Bool(false)=>5,
        Self::Text(s)=>json_text_len(s),Self::Int(n)=>n.to_string().len(),
    }}
}
fn typed_uuid(value:&Field)->bool {
    let Some(text)=value.as_str() else{return false;};let b=text.as_bytes();
    b.len()==36 && b.iter().enumerate().all(|(i,c)|if [8,13,18,23].contains(&i){*c==b'-'}else{c.is_ascii_hexdigit()})
        && matches!(b[14],b'1'..=b'5') && matches!(b[19],b'8'|b'9'|b'a'|b'b'|b'A'|b'B')
}
fn checked_utf8(bytes:&[u8])->Option<&str> {
    #[cfg(feature="vector")]
    {simdutf8::basic::from_utf8(bytes).ok()}
    #[cfg(not(feature="vector"))]
    {std::str::from_utf8(bytes).ok()}
}
// Explicit host/guest agreement: typed ingress enforces the original logical
// JSON envelope bound itself, including all escapes and independently of host.
static mut ROW_BUDGET_EXCEEDED:bool=false;
#[no_mangle]
pub extern "C" fn row_budget_exceeded()->i32 {unsafe{ROW_BUDGET_EXCEEDED as i32}}
#[no_mangle]
pub extern "C" fn row_budget_version()->i32 {1}
fn decode_typed_row(bytes:&[u8],expected:u32)->Option<CheckedRow> {
    if bytes.len()<40 || bytes.len()>LIMIT || &bytes[..4]!=b"JRW1" || bytes[4..36]!=ROW_DIGEST {return None;}
    let id=u32::from_le_bytes(bytes[36..40].try_into().ok()?);if id!=expected{return None;}
    let schema=row_schema(id)?;let mut pos=40;let mut fields=Vec::with_capacity(schema.fields.len());
    // Canonical JSON envelope size, independently recomputed inside the guest.
    // The host's shorter binary encoding cannot relax the existing JSON budget.
    let mut json_bound=29;let mut present=0;
    for key in schema.fields {
        let tag=*bytes.get(pos)?;pos+=1;
        let field=match tag {
            0=>Field::Missing,1=>Field::Null,3=>Field::Bool(false),4=>Field::Bool(true),
            2=>{
                let end=pos.checked_add(4)?;let len=u32::from_le_bytes(bytes.get(pos..end)?.try_into().ok()?) as usize;pos=end;
                let end=pos.checked_add(len)?;let s=checked_utf8(bytes.get(pos..end)?)?;pos=end;Field::Text(s.to_owned())
            },
            5=>{let end=pos.checked_add(8)?;let n=i64::from_le_bytes(bytes.get(pos..end)?.try_into().ok()?);pos=end;Field::Int(n)},
            _=>return None,
        };
        if !matches!(field,Field::Missing) {
            json_bound+=json_text_len(key)+1+field.json_len()+usize::from(present>0);present+=1;
        }
        fields.push(field);
    }
    if pos!=bytes.len(){return None;}
    if json_bound>LIMIT{unsafe{ROW_BUDGET_EXCEEDED=true;}return None;}
    // The generated query validates every field/refinement before promotion to
    // AppValue::Row. Neither decoding nor host validation supplies that proof.
    Some(CheckedRow{schema,fields,json_bound:Some(json_bound),origin:None})
}

#[cfg(test)]
mod typed_decode_tests {
    use super::*;
    #[test]
    fn direct_decode_matches_reference_json_budget_and_presence() {
        let schema=ROW_SCHEMAS.iter().find(|s|s.fields.len()>=4).unwrap();
        for text in ["", "x", "é中😀", "\"\\\n\r\t\0", "\u{feff}"] {
            let mut object=serde_json::Map::new();
            object.insert(schema.fields[0].to_owned(),Value::String(text.repeat(1024)));
            object.insert(schema.fields[1].to_owned(),Value::Null);
            object.insert(schema.fields[2].to_owned(),Value::Bool(false));
            let value=Value::Object(object);
            let bytes=encode_row(schema,&value).unwrap();
            let decoded=decode_typed_row(&bytes,schema.id).unwrap();
            assert_eq!(decoded.json_bound,Some(27+json_len(&value)));
            assert_eq!(AppValue::Row(Rc::new(decoded)).into_json(),value);
        }
    }
    #[test]
    fn provenance_does_not_survive_materialisation_or_an_unvalidated_result() {
        let schema=ROW_SCHEMAS.iter().find(|s|s.fields.len()==1).unwrap();
        let row=json!({schema.fields[0]:"x".repeat(2000)});
        let typed=AppValue::checked_row_origin(schema.name,row,Some(2100),Some(RowOrigin{request:7,operation:8}));
        let plain=typed.into_json();
        unsafe{ROW_FLAGS=6;RETURN_SCHEMA=schema.id;}
        assert_eq!(emit_app(AppValue::Json(plain)),0);assert_ne!(result_format(),2);
        unsafe{ROW_FLAGS=0;RETURN_SCHEMA=0;}
    }
}


const ROW_DIGEST: [u8;32] = [166,151,37,104,84,10,194,203,114,50,108,1,20,191,130,78,244,105,155,19,159,182,70,187,28,52,195,47,192,254,190,2];
static ROW_SCHEMAS: &[RowSchema] = &[
RowSchema { id: 20, name: "Item", fields: &["id","owner_id","title","note"] },
RowSchema { id: 32, name: "ItemPatch", fields: &["title","note"] },
RowSchema { id: 57, name: "ProbeInput", fields: &["id","title","note"] },
RowSchema { id: 84, name: "User", fields: &["id"] }];
fn row_schema_for_name(name:&str)->u32 {ROW_SCHEMAS.iter().find(|s|s.name==name).map_or(0,|s|s.id)}
fn row_schema_for_entry(op:i32)->u32 {match op {
22=>20,26=>20,28=>20,550=>20,_=>0}}
fn compact_plan(id:u32)->Option<(u32,usize)> {match id {
26=>Some((20,657)),
_=>None,}}


#[allow(unused_parens)]
fn validate(name: &str, value: &Value) -> bool { match name {
"Bool" => (value.is_boolean()),
"Int" => (value.as_i64().is_some()),
"Item" => value.as_object().map_or(false, |object| object.keys().all(|key| ["id","owner_id","title","note"].contains(&key.as_str())) && object.get("id").map_or(false, |field| validate("Item.id", field)) && object.get("owner_id").map_or(false, |field| validate("Item.owner_id", field)) && object.get("title").map_or(false, |field| validate("Item.title", field)) && object.get("note").map_or(false, |field| (field.is_null() || validate("Item.note", field)))),
"Item.id" => (uuid(value)),
"Item.note" => (value.is_null() || (value.is_string())),
"Item.owner_id" => (uuid(value)),
"Item.title" => (value.is_string() && value.as_str().map_or(false, |s| s.chars().count() >= 3) && value.as_str().map_or(false, |s| s.chars().count() <= 12)),
"ItemPatch" => value.as_object().map_or(false, |object| object.keys().all(|key| ["title","note"].contains(&key.as_str())) && object.get("title").map_or(true, |field| validate("ItemPatch.title", field)) && object.get("note").map_or(true, |field| (field.is_null() || validate("ItemPatch.note", field)))),
"ItemPatch.note" => (value.is_null() || (value.is_string())),
"ItemPatch.title" => (value.is_string() && value.as_str().map_or(false, |s| s.chars().count() >= 3) && value.as_str().map_or(false, |s| s.chars().count() <= 12)),
"ItemRole" => value.as_str().map_or(false, |v| ["owner"].contains(&v)),
"ItemTitle" => (value.is_string() && value.as_str().map_or(false, |s| s.chars().count() >= 3) && value.as_str().map_or(false, |s| s.chars().count() <= 12)),
"ProbeInput" => value.as_object().map_or(false, |object| object.keys().all(|key| ["id","title","note"].contains(&key.as_str())) && object.get("id").map_or(false, |field| validate("ProbeInput.id", field)) && object.get("title").map_or(false, |field| validate("ProbeInput.title", field)) && object.get("note").map_or(true, |field| (field.is_null() || validate("ProbeInput.note", field)))),
"ProbeInput.id" => (uuid(value)),
"ProbeInput.note" => (value.is_null() || (value.is_string())),
"ProbeInput.title" => (value.is_string() && value.as_str().map_or(false, |s| s.chars().count() >= 3) && value.as_str().map_or(false, |s| s.chars().count() <= 12)),
"Text" => (value.is_string()),
"User" => value.as_object().map_or(false, |object| object.keys().all(|key| ["id"].contains(&key.as_str())) && object.get("id").map_or(false, |field| validate("User.id", field))),
"User.id" => (uuid(value)),
"Uuid" => (uuid(value)),
_ => false, } }

#[allow(unused_parens)]
fn validate_field(name:&str,value:&Field)->bool {match name {
"Bool"=>(value.is_boolean()),
"Int"=>(value.as_i64().is_some()),
"Item.id"=>(typed_uuid(value)),
"Item.note"=>(value.is_null() || (value.is_string())),
"Item.owner_id"=>(typed_uuid(value)),
"Item.title"=>(value.is_string() && value.as_str().map_or(false, |s| s.chars().count() >= 3) && value.as_str().map_or(false, |s| s.chars().count() <= 12)),
"ItemPatch.note"=>(value.is_null() || (value.is_string())),
"ItemPatch.title"=>(value.is_string() && value.as_str().map_or(false, |s| s.chars().count() >= 3) && value.as_str().map_or(false, |s| s.chars().count() <= 12)),
"ItemRole"=>value.as_str().map_or(false, |v| ["owner"].contains(&v)),
"ItemTitle"=>(value.is_string() && value.as_str().map_or(false, |s| s.chars().count() >= 3) && value.as_str().map_or(false, |s| s.chars().count() <= 12)),
"ProbeInput.id"=>(typed_uuid(value)),
"ProbeInput.note"=>(value.is_null() || (value.is_string())),
"ProbeInput.title"=>(value.is_string() && value.as_str().map_or(false, |s| s.chars().count() >= 3) && value.as_str().map_or(false, |s| s.chars().count() <= 12)),
"Text"=>(value.is_string()),
"User.id"=>(typed_uuid(value)),
"Uuid"=>(typed_uuid(value)),
_=>false,}}
fn validate_typed_row(row:&CheckedRow)->bool {match row.schema.id {
20=>row.fields.len()==4 && validate_field("Item.id", &row.fields[0]) && validate_field("Item.owner_id", &row.fields[1]) && validate_field("Item.title", &row.fields[2]) && (row.fields[3].is_null() || validate_field("Item.note", &row.fields[3])),
32=>row.fields.len()==2 && (matches!(row.fields[0],Field::Missing) || validate_field("ItemPatch.title", &row.fields[0])) && (matches!(row.fields[1],Field::Missing) || (row.fields[1].is_null() || validate_field("ItemPatch.note", &row.fields[1]))),
57=>row.fields.len()==3 && validate_field("ProbeInput.id", &row.fields[0]) && validate_field("ProbeInput.title", &row.fields[1]) && (matches!(row.fields[2],Field::Missing) || (row.fields[2].is_null() || validate_field("ProbeInput.note", &row.fields[2]))),
84=>row.fields.len()==1 && validate_field("User.id", &row.fields[0]),
_=>false,}}


async fn call_22(v_id: AppValue, v_changes: AppValue) -> Outcome {
return async { let mut args = { static CONSTANT: std::sync::OnceLock<Value> = std::sync::OnceLock::new(); CONSTANT.get_or_init(|| serde_json::from_str::<Value>(r#"{"entity":"Item","operation":"Item.change","semanticOperationId":22,"freshness":"authoritative","policy":{"operation":{"fieldReads":[],"obligations":[{"effect":"update","entity":"Item","origin":"entity","subjects":["ItemRole.owner"]}],"operation":"Item.change"},"bindings":[{"entity":"Item","field":"owner_id","principalEntity":"User","role":"ItemRole.owner","scope":"Item"}],"entities":[{"entity":"Item","fields":[],"rules":[{"effects":["read","update"],"subject":"ItemRole.owner"}],"scope":"Item","scopeField":null}]},"predicate":{"field":"id","operator":"equal"}}"#).unwrap()).clone() };
args["predicate"]["value"] = (member(&v_id, &[], 22))?.into_json();
let mut changes = (member(&v_changes, &[], 22))?.into_json().as_object().ok_or(Fault::Internal(22))?.clone();
args["changes"] = Value::Object(changes);
let mut result = host_update(args, 22).await?.value;
let object = result.as_object_mut().ok_or(Fault::Internal(22))?;
match object.get("status").and_then(Value::as_str) {
Some("found") if object.len()==2 && object.contains_key("row") => { let row = &object["row"]; if !validate("Item",row) { return Err(Fault::Internal(22)); } Ok(AppValue::Json(object.remove("row").unwrap())) },
Some("missing") if object.len()==1 => Err(Fault::Domain("ItemMissing")),
Some("empty") if object.len()==1 => Err(Fault::Domain("EmptyPatch")),
Some("conflict") if object.len()==1 => Err(Fault::Domain("ItemConflict")),
_ => Err(Fault::Internal(22)),
} }.await;
}

async fn call_26(v_id: AppValue) -> Outcome {
return async { let predicate = (member(&v_id, &[], 26))?.into_json(); let pending = if unsafe{ROW_FLAGS&8!=0} {host_read_compact(predicate, 26)} else {let mut args = { static CONSTANT: std::sync::OnceLock<Value> = std::sync::OnceLock::new(); CONSTANT.get_or_init(|| serde_json::from_str::<Value>(r#"{"entity":"Item","operation":"Item.read","semanticOperationId":26,"freshness":"authoritative","policy":{"operation":{"fieldReads":[],"obligations":[{"effect":"read","entity":"Item","origin":"entity","subjects":["ItemRole.owner"]}],"operation":"Item.read"},"bindings":[{"entity":"Item","field":"owner_id","principalEntity":"User","role":"ItemRole.owner","scope":"Item"}],"entities":[{"entity":"Item","fields":[],"rules":[{"effects":["read","update"],"subject":"ItemRole.owner"}],"scope":"Item","scopeField":null}]},"predicate":{"field":"id","operator":"equal"}}"#).unwrap()).clone() }; args["predicate"]["value"] = predicate; host_read(args, 26)}; let host = pending.await?; if let Some(row)=host.typed { if row.schema.name!="Item" || !validate_typed_row(&row) {return Err(Fault::Internal(26));} return Ok(AppValue::Row(Rc::new(row))); } let row=host.value; if row.is_null() { return Err(Fault::Domain("ItemMissing")); } if !validate("Item", &row) { return Err(Fault::Internal(26)); } Ok(AppValue::checked_row_origin("Item", row, host.json_bound, host.origin)) }.await;
}

async fn call_27(v_id: AppValue) -> Outcome {
let v_item = (call_26((member(&v_id, &[], 27))?).await)?;
return member(&v_item, &["title"], 27);
}

async fn call_28(v_id: AppValue, v_title: AppValue) -> Outcome {
return async { let mut args = { static CONSTANT: std::sync::OnceLock<Value> = std::sync::OnceLock::new(); CONSTANT.get_or_init(|| serde_json::from_str::<Value>(r#"{"entity":"Item","operation":"Item.rename","semanticOperationId":28,"freshness":"authoritative","policy":{"operation":{"fieldReads":[],"obligations":[{"effect":"update","entity":"Item","origin":"entity","subjects":["ItemRole.owner"]}],"operation":"Item.rename"},"bindings":[{"entity":"Item","field":"owner_id","principalEntity":"User","role":"ItemRole.owner","scope":"Item"}],"entities":[{"entity":"Item","fields":[],"rules":[{"effects":["read","update"],"subject":"ItemRole.owner"}],"scope":"Item","scopeField":null}]},"predicate":{"field":"id","operator":"equal"}}"#).unwrap()).clone() };
args["predicate"]["value"] = (member(&v_id, &[], 28))?.into_json();
let mut changes = serde_json::Map::new();
changes.insert("title".to_owned(), (member(&v_title, &[], 28))?.into_json());
args["changes"] = Value::Object(changes);
let mut result = host_update(args, 28).await?.value;
let object = result.as_object_mut().ok_or(Fault::Internal(28))?;
match object.get("status").and_then(Value::as_str) {
Some("found") if object.len()==2 && object.contains_key("row") => { let row = &object["row"]; if !validate("Item",row) { return Err(Fault::Internal(28)); } Ok(AppValue::Json(object.remove("row").unwrap())) },
Some("missing") if object.len()==1 => Err(Fault::Domain("ItemMissing")),
Some("conflict") if object.len()==1 => Err(Fault::Domain("ItemConflict")),
_ => Err(Fault::Internal(28)),
} }.await;
}

async fn call_517(v_input: AppValue) -> Outcome {
return match call_27((member(&v_input, &["id"], 517))?).await {
Ok(v_title) => member(&v_title, &[], 517),
Err(Fault::Domain(name)) if name == "ItemMissing" => member(&v_input, &["title"], 517),
Err(error) => Err(error), };
}

async fn call_550(v_first_id: AppValue, v_first_title: AppValue, v_second_id: AppValue, v_second_title: AppValue) -> Outcome {
let v_first = (call_28((member(&v_first_id, &[], 550))?, (member(&v_first_title, &[], 550))?).await)?;
return call_28((member(&v_second_id, &[], 550))?, (member(&v_second_title, &[], 550))?).await;
}

fn make_entry(operation: i32, input: Value) -> Result<Pin<Box<dyn Future<Output = Outcome>>>, Fault> { match operation {
22 => {
let Value::Array(arguments) = input else { return Err(Fault::Invalid); }; if arguments.len()!=2 {return Err(Fault::Invalid);}
if !validate("Item.id", &arguments[0]) {return Err(Fault::Invalid);}
if !validate("ItemPatch", &arguments[1]) {return Err(Fault::Invalid);}
let mut arguments = arguments.into_iter();
Ok(Box::pin(call_22(AppValue::Json(arguments.next().unwrap()), AppValue::Json(arguments.next().unwrap())))) },
26 => {
if !validate("Item.id", &input) { return Err(Fault::Invalid); }
Ok(Box::pin(call_26(AppValue::Json(input)))) },
27 => {
if !validate("Item.id", &input) { return Err(Fault::Invalid); }
Ok(Box::pin(call_27(AppValue::Json(input)))) },
28 => {
let Value::Array(arguments) = input else { return Err(Fault::Invalid); }; if arguments.len()!=2 {return Err(Fault::Invalid);}
if !validate("Item.id", &arguments[0]) {return Err(Fault::Invalid);}
if !validate("Item.title", &arguments[1]) {return Err(Fault::Invalid);}
let mut arguments = arguments.into_iter();
Ok(Box::pin(call_28(AppValue::Json(arguments.next().unwrap()), AppValue::Json(arguments.next().unwrap())))) },
517 => {
if !validate("ProbeInput", &input) { return Err(Fault::Invalid); }
Ok(Box::pin(call_517(AppValue::Json(input)))) },
550 => {
let Value::Array(arguments) = input else { return Err(Fault::Invalid); }; if arguments.len()!=4 {return Err(Fault::Invalid);}
if !validate("Item.id", &arguments[0]) {return Err(Fault::Invalid);}
if !validate("Item.title", &arguments[1]) {return Err(Fault::Invalid);}
if !validate("Item.id", &arguments[2]) {return Err(Fault::Invalid);}
if !validate("Item.title", &arguments[3]) {return Err(Fault::Invalid);}
let mut arguments = arguments.into_iter();
Ok(Box::pin(call_550(AppValue::Json(arguments.next().unwrap()), AppValue::Json(arguments.next().unwrap()), AppValue::Json(arguments.next().unwrap()), AppValue::Json(arguments.next().unwrap())))) },
_ => Err(Fault::Internal(operation as u32)), } }
