#[allow(unused_parens)]
pub fn validate(name: &str, value: &Value) -> bool { match name {
"Account" => value.as_object().map_or(false, |object| object.keys().all(|key| ["id"].contains(&key.as_str())) && object.get("id").map_or(false, |field| validate("Account.id", field))),
"Account.id" => (uuid(value)),
"Bool" => (value.is_boolean()),
"Int" => (value.as_i64().is_some()),
"ProbeInput" => value.as_object().map_or(false, |object| object.keys().all(|key| ["id","title","note"].contains(&key.as_str())) && object.get("id").map_or(false, |field| validate("ProbeInput.id", field)) && object.get("title").map_or(false, |field| validate("ProbeInput.title", field)) && object.get("note").map_or(true, |field| (field.is_null() || validate("ProbeInput.note", field)))),
"ProbeInput.id" => (uuid(value)),
"ProbeInput.note" => (value.is_null() || (value.is_string())),
"ProbeInput.title" => (value.is_string() && value.as_str().map_or(false, |s| s.chars().count() >= 3) && value.as_str().map_or(false, |s| s.chars().count() <= 12)),
"Record" => value.as_object().map_or(false, |object| object.keys().all(|key| ["id","account_key","title","note"].contains(&key.as_str())) && object.get("id").map_or(false, |field| validate("Record.id", field)) && object.get("account_key").map_or(false, |field| validate("Record.account_key", field)) && object.get("title").map_or(false, |field| validate("Record.title", field)) && object.get("note").map_or(false, |field| (field.is_null() || validate("Record.note", field)))),
"Record.account_key" => (uuid(value)),
"Record.id" => (uuid(value)),
"Record.note" => (value.is_null() || (value.is_string())),
"Record.title" => (value.is_string() && value.as_str().map_or(false, |s| s.chars().count() >= 3) && value.as_str().map_or(false, |s| s.chars().count() <= 12)),
"RecordPatch" => value.as_object().map_or(false, |object| object.keys().all(|key| ["title","note"].contains(&key.as_str())) && object.get("title").map_or(true, |field| validate("RecordPatch.title", field)) && object.get("note").map_or(true, |field| (field.is_null() || validate("RecordPatch.note", field)))),
"RecordPatch.note" => (value.is_null() || (value.is_string())),
"RecordPatch.title" => (value.is_string() && value.as_str().map_or(false, |s| s.chars().count() >= 3) && value.as_str().map_or(false, |s| s.chars().count() <= 12)),
"RecordRole" => value.as_str().map_or(false, |v| ["owner"].contains(&v)),
"RecordTitle" => (value.is_string() && value.as_str().map_or(false, |s| s.chars().count() >= 3) && value.as_str().map_or(false, |s| s.chars().count() <= 12)),
"Text" => (value.is_string()),
"Uuid" => (uuid(value)),
_ => false, } }

async fn call_50(ctx: InvocationContext, v_id: AppValue, v_changes: AppValue) -> Outcome {
return async { let mut args = { static CONSTANT: std::sync::OnceLock<Value> = std::sync::OnceLock::new(); CONSTANT.get_or_init(|| serde_json::from_str::<Value>(r#"{"entity":"Record","operation":"Record.change","semanticOperationId":50,"freshness":"authoritative","policy":{"operation":{"fieldReads":[],"obligations":[{"effect":"update","entity":"Record","origin":"entity","subjects":["RecordRole.owner"]}],"operation":"Record.change"},"bindings":[{"entity":"Record","field":"account_key","principalEntity":"Account","role":"RecordRole.owner","scope":"Record"}],"entities":[{"entity":"Record","fields":[],"rules":[{"effects":["read","update"],"subject":"RecordRole.owner"}],"scope":"Record","scopeField":null}]},"predicate":{"field":"id","operator":"equal"}}"#).unwrap()).clone() };
args["predicate"]["value"] = (member(&v_id, &[], 50))?.into_json();
let mut changes = (member(&v_changes, &[], 50))?.into_json().as_object().ok_or(Fault::Internal(50))?.clone();
args["changes"] = Value::Object(changes);
let mut result = host_update(ctx.clone(), args, 50).await?.value;
let object = result.as_object_mut().ok_or(Fault::Internal(50))?;
match object.get("status").and_then(Value::as_str) {
Some("found") if object.len()==2 && object.contains_key("row") => { let row = &object["row"]; if !validate("Record",row) { return Err(Fault::Internal(50)); } Ok(AppValue::Json(object.remove("row").unwrap())) },
Some("missing") if object.len()==1 => Err(Fault::Domain("RecordMissing")),
Some("empty") if object.len()==1 => Err(Fault::Domain("EmptyPatch")),
Some("conflict") if object.len()==1 => Err(Fault::Domain("RecordConflict")),
_ => Err(Fault::Internal(50)),
} }.await;
}

async fn call_53(ctx: InvocationContext, v_id: AppValue) -> Outcome {
return async { let mut args = { static CONSTANT: std::sync::OnceLock<Value> = std::sync::OnceLock::new(); CONSTANT.get_or_init(|| serde_json::from_str::<Value>(r#"{"entity":"Record","operation":"Record.read","semanticOperationId":53,"freshness":"authoritative","policy":{"operation":{"fieldReads":[],"obligations":[{"effect":"read","entity":"Record","origin":"entity","subjects":["RecordRole.owner"]}],"operation":"Record.read"},"bindings":[{"entity":"Record","field":"account_key","principalEntity":"Account","role":"RecordRole.owner","scope":"Record"}],"entities":[{"entity":"Record","fields":[],"rules":[{"effects":["read","update"],"subject":"RecordRole.owner"}],"scope":"Record","scopeField":null}]},"predicate":{"field":"id","operator":"equal"}}"#).unwrap()).clone() }; args["predicate"]["value"] = (member(&v_id, &[], 53))?.into_json(); let row = host_read(ctx.clone(), args, 53).await?.value; if row.is_null() {return Err(Fault::Domain("RecordMissing"));} if !validate("Record", &row) {return Err(Fault::Internal(53));} Ok(AppValue::checked_row(row)) }.await;
}

async fn call_54(ctx: InvocationContext, v_id: AppValue) -> Outcome {
let v_item = (call_53(ctx.clone(), (member(&v_id, &[], 54))?).await)?;
return member(&v_item, &["title"], 54);
}

async fn call_55(ctx: InvocationContext, v_id: AppValue, v_title: AppValue) -> Outcome {
return async { let mut args = { static CONSTANT: std::sync::OnceLock<Value> = std::sync::OnceLock::new(); CONSTANT.get_or_init(|| serde_json::from_str::<Value>(r#"{"entity":"Record","operation":"Record.rename","semanticOperationId":55,"freshness":"authoritative","policy":{"operation":{"fieldReads":[],"obligations":[{"effect":"update","entity":"Record","origin":"entity","subjects":["RecordRole.owner"]}],"operation":"Record.rename"},"bindings":[{"entity":"Record","field":"account_key","principalEntity":"Account","role":"RecordRole.owner","scope":"Record"}],"entities":[{"entity":"Record","fields":[],"rules":[{"effects":["read","update"],"subject":"RecordRole.owner"}],"scope":"Record","scopeField":null}]},"predicate":{"field":"id","operator":"equal"}}"#).unwrap()).clone() };
args["predicate"]["value"] = (member(&v_id, &[], 55))?.into_json();
let mut changes = serde_json::Map::new();
changes.insert("title".to_owned(), (member(&v_title, &[], 55))?.into_json());
args["changes"] = Value::Object(changes);
let mut result = host_update(ctx.clone(), args, 55).await?.value;
let object = result.as_object_mut().ok_or(Fault::Internal(55))?;
match object.get("status").and_then(Value::as_str) {
Some("found") if object.len()==2 && object.contains_key("row") => { let row = &object["row"]; if !validate("Record",row) { return Err(Fault::Internal(55)); } Ok(AppValue::Json(object.remove("row").unwrap())) },
Some("missing") if object.len()==1 => Err(Fault::Domain("RecordMissing")),
Some("conflict") if object.len()==1 => Err(Fault::Domain("RecordConflict")),
_ => Err(Fault::Internal(55)),
} }.await;
}

async fn call_517(ctx: InvocationContext, v_input: AppValue) -> Outcome {
return match call_54(ctx.clone(), (member(&v_input, &["id"], 517))?).await {
Ok(v_title) => member(&v_title, &[], 517),
Err(Fault::Domain(name)) if name == "RecordMissing" => member(&v_input, &["title"], 517),
Err(error) => Err(error), };
}

async fn call_550(ctx: InvocationContext, v_first_id: AppValue, v_first_title: AppValue, v_second_id: AppValue, v_second_title: AppValue) -> Outcome {
let v_first = (call_55(ctx.clone(), (member(&v_first_id, &[], 550))?, (member(&v_first_title, &[], 550))?).await)?;
return call_55(ctx.clone(), (member(&v_second_id, &[], 550))?, (member(&v_second_title, &[], 550))?).await;
}

pub fn checked_input(operation:i32,input:&Value)->bool { if !within_limit(input) {return false;} match operation {
50=>input.as_array().map_or(false,|arguments|arguments.len()==2 && validate("Record.id", &arguments[0]) && validate("RecordPatch", &arguments[1])),
53=>validate("Record.id", &input),
54=>validate("Record.id", &input),
55=>input.as_array().map_or(false,|arguments|arguments.len()==2 && validate("Record.id", &arguments[0]) && validate("Record.title", &arguments[1])),
517=>validate("ProbeInput", &input),
550=>input.as_array().map_or(false,|arguments|arguments.len()==4 && validate("Record.id", &arguments[0]) && validate("Record.title", &arguments[1]) && validate("Record.id", &arguments[2]) && validate("Record.title", &arguments[3])),
_=>false,}}

fn make_entry(operation:i32,input:Value,ctx:InvocationContext)->Result<Pin<Box<dyn Future<Output=Outcome> + Send>>,Fault> { if !checked_input(operation,&input) {return Err(Fault::Invalid);} match operation {
50=>{let mut arguments=input.as_array().unwrap().clone().into_iter(); Ok(Box::pin(call_50(ctx, AppValue::Json(arguments.next().unwrap()), AppValue::Json(arguments.next().unwrap())))) },
53=>{ Ok(Box::pin(call_53(ctx, AppValue::Json(input)))) },
54=>{ Ok(Box::pin(call_54(ctx, AppValue::Json(input)))) },
55=>{let mut arguments=input.as_array().unwrap().clone().into_iter(); Ok(Box::pin(call_55(ctx, AppValue::Json(arguments.next().unwrap()), AppValue::Json(arguments.next().unwrap())))) },
517=>{ Ok(Box::pin(call_517(ctx, AppValue::Json(input)))) },
550=>{let mut arguments=input.as_array().unwrap().clone().into_iter(); Ok(Box::pin(call_550(ctx, AppValue::Json(arguments.next().unwrap()), AppValue::Json(arguments.next().unwrap()), AppValue::Json(arguments.next().unwrap()), AppValue::Json(arguments.next().unwrap())))) },
_=>Err(Fault::Invalid),}}
