#[allow(unused_parens)]
pub fn validate(name: &str, value: &Value) -> bool { match name {
"Bool" => (value.is_boolean()),
"Int" => (value.as_i64().is_some()),
"Item" => value.as_object().map_or(false, |object| object.keys().all(|key| ["id","owner_id","title","note"].contains(&key.as_str())) && object.get("id").map_or(false, |field| validate("Item.id", field)) && object.get("owner_id").map_or(false, |field| validate("Item.owner_id", field)) && object.get("title").map_or(false, |field| validate("Item.title", field)) && object.get("note").map_or(false, |field| (field.is_null() || validate("Item.note", field)))),
"Item.id" => (uuid(value)),
"Item.note" => (value.is_null() || (value.is_string())),
"Item.owner_id" => (uuid(value)),
"Item.title" => (value.is_string() && value.as_str().map_or(false, |s| s.chars().count() >= 3) && value.as_str().map_or(false, |s| s.chars().count() <= 12)),
"ItemPatch" => value.as_object().map_or(false, |object| object.keys().all(|key| ["title","note"].contains(&key.as_str())) && object.get("title").map_or(true, |field| validate("ItemPatch.title", field)) && object.get("note").map_or(true, |field| (field.is_null() || validate("ItemPatch.note", field)))),
"ItemPatch.note" => (value.is_null() || (value.is_string())),
"ItemPatch.title" => (value.is_string() && value.as_str().map_or(false, |s| s.chars().count() >= 3) && value.as_str().map_or(false, |s| s.chars().count() <= 12)),
"ItemRole" => value.as_str().map_or(false, |v| ["owner"].contains(&v)),
"ItemTitle" => (value.is_string() && value.as_str().map_or(false, |s| s.chars().count() >= 3) && value.as_str().map_or(false, |s| s.chars().count() <= 12)),
"ProbeInput" => value.as_object().map_or(false, |object| object.keys().all(|key| ["id","title","note"].contains(&key.as_str())) && object.get("id").map_or(false, |field| validate("ProbeInput.id", field)) && object.get("title").map_or(false, |field| validate("ProbeInput.title", field)) && object.get("note").map_or(true, |field| (field.is_null() || validate("ProbeInput.note", field)))),
"ProbeInput.id" => (uuid(value)),
"ProbeInput.note" => (value.is_null() || (value.is_string())),
"ProbeInput.title" => (value.is_string() && value.as_str().map_or(false, |s| s.chars().count() >= 3) && value.as_str().map_or(false, |s| s.chars().count() <= 12)),
"Text" => (value.is_string()),
"User" => value.as_object().map_or(false, |object| object.keys().all(|key| ["id"].contains(&key.as_str())) && object.get("id").map_or(false, |field| validate("User.id", field))),
"User.id" => (uuid(value)),
"Uuid" => (uuid(value)),
_ => false, } }

async fn call_22(ctx: InvocationContext, v_id: AppValue, v_changes: AppValue) -> Outcome {
return async { let mut args = { static CONSTANT: std::sync::OnceLock<Value> = std::sync::OnceLock::new(); CONSTANT.get_or_init(|| serde_json::from_str::<Value>(r#"{"entity":"Item","operation":"Item.change","semanticOperationId":22,"freshness":"authoritative","policy":{"operation":{"fieldReads":[],"obligations":[{"effect":"update","entity":"Item","origin":"entity","subjects":["ItemRole.owner"]}],"operation":"Item.change"},"bindings":[{"entity":"Item","field":"owner_id","principalEntity":"User","role":"ItemRole.owner","scope":"Item"}],"entities":[{"entity":"Item","fields":[],"rules":[{"effects":["read","update"],"subject":"ItemRole.owner"}],"scope":"Item","scopeField":null}]},"predicate":{"field":"id","operator":"equal"}}"#).unwrap()).clone() };
args["predicate"]["value"] = (member(&v_id, &[], 22))?.into_json();
let mut changes = (member(&v_changes, &[], 22))?.into_json().as_object().ok_or(Fault::Internal(22))?.clone();
args["changes"] = Value::Object(changes);
let mut result = host_update(ctx.clone(), args, 22).await?.value;
let object = result.as_object_mut().ok_or(Fault::Internal(22))?;
match object.get("status").and_then(Value::as_str) {
Some("found") if object.len()==2 && object.contains_key("row") => { let row = &object["row"]; if !validate("Item",row) { return Err(Fault::Internal(22)); } Ok(AppValue::Json(object.remove("row").unwrap())) },
Some("missing") if object.len()==1 => Err(Fault::Domain("ItemMissing")),
Some("empty") if object.len()==1 => Err(Fault::Domain("EmptyPatch")),
Some("conflict") if object.len()==1 => Err(Fault::Domain("ItemConflict")),
_ => Err(Fault::Internal(22)),
} }.await;
}

async fn call_26(ctx: InvocationContext, v_id: AppValue) -> Outcome {
return async { let mut args = { static CONSTANT: std::sync::OnceLock<Value> = std::sync::OnceLock::new(); CONSTANT.get_or_init(|| serde_json::from_str::<Value>(r#"{"entity":"Item","operation":"Item.read","semanticOperationId":26,"freshness":"authoritative","policy":{"operation":{"fieldReads":[],"obligations":[{"effect":"read","entity":"Item","origin":"entity","subjects":["ItemRole.owner"]}],"operation":"Item.read"},"bindings":[{"entity":"Item","field":"owner_id","principalEntity":"User","role":"ItemRole.owner","scope":"Item"}],"entities":[{"entity":"Item","fields":[],"rules":[{"effects":["read","update"],"subject":"ItemRole.owner"}],"scope":"Item","scopeField":null}]},"predicate":{"field":"id","operator":"equal"}}"#).unwrap()).clone() }; args["predicate"]["value"] = (member(&v_id, &[], 26))?.into_json(); let row = host_read(ctx.clone(), args, 26).await?.value; if row.is_null() {return Err(Fault::Domain("ItemMissing"));} if !validate("Item", &row) {return Err(Fault::Internal(26));} Ok(AppValue::checked_row(row)) }.await;
}

async fn call_27(ctx: InvocationContext, v_id: AppValue) -> Outcome {
let v_item = (call_26(ctx.clone(), (member(&v_id, &[], 27))?).await)?;
return member(&v_item, &["title"], 27);
}

async fn call_28(ctx: InvocationContext, v_id: AppValue, v_title: AppValue) -> Outcome {
return async { let mut args = { static CONSTANT: std::sync::OnceLock<Value> = std::sync::OnceLock::new(); CONSTANT.get_or_init(|| serde_json::from_str::<Value>(r#"{"entity":"Item","operation":"Item.rename","semanticOperationId":28,"freshness":"authoritative","policy":{"operation":{"fieldReads":[],"obligations":[{"effect":"update","entity":"Item","origin":"entity","subjects":["ItemRole.owner"]}],"operation":"Item.rename"},"bindings":[{"entity":"Item","field":"owner_id","principalEntity":"User","role":"ItemRole.owner","scope":"Item"}],"entities":[{"entity":"Item","fields":[],"rules":[{"effects":["read","update"],"subject":"ItemRole.owner"}],"scope":"Item","scopeField":null}]},"predicate":{"field":"id","operator":"equal"}}"#).unwrap()).clone() };
args["predicate"]["value"] = (member(&v_id, &[], 28))?.into_json();
let mut changes = serde_json::Map::new();
changes.insert("title".to_owned(), (member(&v_title, &[], 28))?.into_json());
args["changes"] = Value::Object(changes);
let mut result = host_update(ctx.clone(), args, 28).await?.value;
let object = result.as_object_mut().ok_or(Fault::Internal(28))?;
match object.get("status").and_then(Value::as_str) {
Some("found") if object.len()==2 && object.contains_key("row") => { let row = &object["row"]; if !validate("Item",row) { return Err(Fault::Internal(28)); } Ok(AppValue::Json(object.remove("row").unwrap())) },
Some("missing") if object.len()==1 => Err(Fault::Domain("ItemMissing")),
Some("conflict") if object.len()==1 => Err(Fault::Domain("ItemConflict")),
_ => Err(Fault::Internal(28)),
} }.await;
}

async fn call_517(ctx: InvocationContext, v_input: AppValue) -> Outcome {
return match call_27(ctx.clone(), (member(&v_input, &["id"], 517))?).await {
Ok(v_title) => member(&v_title, &[], 517),
Err(Fault::Domain(name)) if name == "ItemMissing" => member(&v_input, &["title"], 517),
Err(error) => Err(error), };
}

async fn call_550(ctx: InvocationContext, v_first_id: AppValue, v_first_title: AppValue, v_second_id: AppValue, v_second_title: AppValue) -> Outcome {
let v_first = (call_28(ctx.clone(), (member(&v_first_id, &[], 550))?, (member(&v_first_title, &[], 550))?).await)?;
return call_28(ctx.clone(), (member(&v_second_id, &[], 550))?, (member(&v_second_title, &[], 550))?).await;
}

pub fn checked_input(operation:i32,input:&Value)->bool { if !within_limit(input) {return false;} match operation {
22=>input.as_array().map_or(false,|arguments|arguments.len()==2 && validate("Item.id", &arguments[0]) && validate("ItemPatch", &arguments[1])),
26=>validate("Item.id", &input),
27=>validate("Item.id", &input),
28=>input.as_array().map_or(false,|arguments|arguments.len()==2 && validate("Item.id", &arguments[0]) && validate("Item.title", &arguments[1])),
517=>validate("ProbeInput", &input),
550=>input.as_array().map_or(false,|arguments|arguments.len()==4 && validate("Item.id", &arguments[0]) && validate("Item.title", &arguments[1]) && validate("Item.id", &arguments[2]) && validate("Item.title", &arguments[3])),
_=>false,}}

fn make_entry(operation:i32,input:Value,ctx:InvocationContext)->Result<Pin<Box<dyn Future<Output=Outcome> + Send>>,Fault> { if !checked_input(operation,&input) {return Err(Fault::Invalid);} match operation {
22=>{let mut arguments=input.as_array().unwrap().clone().into_iter(); Ok(Box::pin(call_22(ctx, AppValue::Json(arguments.next().unwrap()), AppValue::Json(arguments.next().unwrap())))) },
26=>{ Ok(Box::pin(call_26(ctx, AppValue::Json(input)))) },
27=>{ Ok(Box::pin(call_27(ctx, AppValue::Json(input)))) },
28=>{let mut arguments=input.as_array().unwrap().clone().into_iter(); Ok(Box::pin(call_28(ctx, AppValue::Json(arguments.next().unwrap()), AppValue::Json(arguments.next().unwrap())))) },
517=>{ Ok(Box::pin(call_517(ctx, AppValue::Json(input)))) },
550=>{let mut arguments=input.as_array().unwrap().clone().into_iter(); Ok(Box::pin(call_550(ctx, AppValue::Json(arguments.next().unwrap()), AppValue::Json(arguments.next().unwrap()), AppValue::Json(arguments.next().unwrap()), AppValue::Json(arguments.next().unwrap())))) },
_=>Err(Fault::Invalid),}}
