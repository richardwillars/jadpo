#[allow(unused_parens)]
pub fn validate(name: &str, value: &Value) -> bool { match name {
"Bool" => (value.is_boolean()),
"Int" => (value.as_i64().is_some()),
"Lookup" => value.as_object().map_or(false, |object| object.keys().all(|key| ["id"].contains(&key.as_str())) && object.get("id").map_or(false, |field| validate("Lookup.id", field))),
"Lookup.id" => (uuid(value)),
"Note" => value.as_object().map_or(false, |object| object.keys().all(|key| ["id","owner_id","editor_id","title","private_note"].contains(&key.as_str())) && object.get("id").map_or(false, |field| validate("Note.id", field)) && object.get("owner_id").map_or(false, |field| validate("Note.owner_id", field)) && object.get("editor_id").map_or(false, |field| validate("Note.editor_id", field)) && object.get("title").map_or(false, |field| validate("Note.title", field)) && object.get("private_note").map_or(false, |field| (field.is_null() || validate("Note.private_note", field)))),
"Note.editor_id" => (uuid(value)),
"Note.id" => (uuid(value)),
"Note.owner_id" => (uuid(value)),
"Note.private_note" => (value.is_null() || (value.is_string())),
"Note.title" => (value.is_string() && value.as_str().map_or(false, |s| s.chars().count() >= 5) && value.as_str().map_or(false, |s| s.chars().count() <= 32)),
"NoteRole" => value.as_str().map_or(false, |v| ["owner","editor"].contains(&v)),
"PairChange" => value.as_object().map_or(false, |object| object.keys().all(|key| ["first","second","title","second_title"].contains(&key.as_str())) && object.get("first").map_or(false, |field| validate("PairChange.first", field)) && object.get("second").map_or(false, |field| validate("PairChange.second", field)) && object.get("title").map_or(false, |field| validate("PairChange.title", field)) && object.get("second_title").map_or(false, |field| validate("PairChange.second_title", field))),
"PairChange.first" => (uuid(value)),
"PairChange.second" => (uuid(value)),
"PairChange.second_title" => (value.is_string() && value.as_str().map_or(false, |s| s.chars().count() >= 5) && value.as_str().map_or(false, |s| s.chars().count() <= 32)),
"PairChange.title" => (value.is_string() && value.as_str().map_or(false, |s| s.chars().count() >= 5) && value.as_str().map_or(false, |s| s.chars().count() <= 32)),
"PrivateSummary" => value.as_object().map_or(false, |object| object.keys().all(|key| ["id","private_note"].contains(&key.as_str())) && object.get("id").map_or(false, |field| validate("PrivateSummary.id", field)) && object.get("private_note").map_or(false, |field| (field.is_null() || validate("PrivateSummary.private_note", field)))),
"PrivateSummary.id" => (uuid(value)),
"PrivateSummary.private_note" => (value.is_null() || (value.is_string())),
"Rename" => value.as_object().map_or(false, |object| object.keys().all(|key| ["id","title"].contains(&key.as_str())) && object.get("id").map_or(false, |field| validate("Rename.id", field)) && object.get("title").map_or(false, |field| validate("Rename.title", field))),
"Rename.id" => (uuid(value)),
"Rename.title" => (value.is_string() && value.as_str().map_or(false, |s| s.chars().count() >= 5) && value.as_str().map_or(false, |s| s.chars().count() <= 32)),
"SecretChange" => value.as_object().map_or(false, |object| object.keys().all(|key| ["id","private_note"].contains(&key.as_str())) && object.get("id").map_or(false, |field| validate("SecretChange.id", field)) && object.get("private_note").map_or(false, |field| (field.is_null() || validate("SecretChange.private_note", field)))),
"SecretChange.id" => (uuid(value)),
"SecretChange.private_note" => (value.is_null() || (value.is_string())),
"Summary" => value.as_object().map_or(false, |object| object.keys().all(|key| ["id","title"].contains(&key.as_str())) && object.get("id").map_or(false, |field| validate("Summary.id", field)) && object.get("title").map_or(false, |field| validate("Summary.title", field))),
"Summary.id" => (uuid(value)),
"Summary.title" => (value.is_string() && value.as_str().map_or(false, |s| s.chars().count() >= 5) && value.as_str().map_or(false, |s| s.chars().count() <= 32)),
"Text" => (value.is_string()),
"Title" => (value.is_string() && value.as_str().map_or(false, |s| s.chars().count() >= 5) && value.as_str().map_or(false, |s| s.chars().count() <= 32)),
"User" => value.as_object().map_or(false, |object| object.keys().all(|key| ["id","authentication_subject","enabled"].contains(&key.as_str())) && object.get("id").map_or(false, |field| validate("User.id", field)) && object.get("authentication_subject").map_or(false, |field| validate("User.authentication_subject", field)) && object.get("enabled").map_or(false, |field| validate("User.enabled", field))),
"User.authentication_subject" => (value.is_string()),
"User.enabled" => (value.is_boolean()),
"User.id" => (uuid(value)),
"Uuid" => (uuid(value)),
_ => false, } }

async fn call_39(ctx: InvocationContext, v_input: AppValue) -> Outcome {
let v_note = (async { let mut args = { static CONSTANT: std::sync::OnceLock<Value> = std::sync::OnceLock::new(); CONSTANT.get_or_init(|| serde_json::from_str::<Value>(r#"{"entity":"Note","operation":"Note.change_secret","semanticOperationId":39,"freshness":"authoritative","policy":{"operation":{"fieldReads":[],"obligations":[{"effect":"update","entity":"Note","origin":"entity","subjects":["NoteRole.owner","NoteRole.editor"]}],"operation":"Note.change_secret"},"bindings":[{"entity":"Note","field":"editor_id","principalEntity":"User","role":"NoteRole.editor","scope":"Note"},{"entity":"Note","field":"owner_id","principalEntity":"User","role":"NoteRole.owner","scope":"Note"}],"entities":[{"entity":"Note","fields":[{"field":"private_note","rules":[{"effects":["read","update"],"subject":"NoteRole.owner"},{"effects":["update"],"subject":"NoteRole.editor"}]}],"rules":[{"effects":["read","update"],"subject":"NoteRole.owner"},{"effects":["read","update"],"subject":"NoteRole.editor"}],"scope":"Note","scopeField":null}]},"predicate":{"field":"id","operator":"equal"}}"#).unwrap()).clone() };
args["predicate"]["value"] = (member(&v_input, &["id"], 39))?.into_json();
let mut changes = serde_json::Map::new();
changes.insert("private_note".to_owned(), (member(&v_input, &["private_note"], 39))?.into_json());
args["changes"] = Value::Object(changes);
let mut result = host_update(ctx.clone(), args, 39).await?.value;
let object = result.as_object_mut().ok_or(Fault::Internal(39))?;
match object.get("status").and_then(Value::as_str) {
Some("found") if object.len()==2 && object.contains_key("row") => { let row = &object["row"]; if !validate("Note",row) { return Err(Fault::Internal(39)); } Ok(AppValue::Json(object.remove("row").unwrap())) },
Some("missing") if object.len()==1 => Err(Fault::Domain("NoteMissing")),
Some("conflict") if object.len()==1 => Err(Fault::Domain("NoteConflict")),
_ => Err(Fault::Internal(39)),
} }.await)?;
return { let value = json!({"id":(member(&v_note, &["id"], 39))?.into_json(),"title":(member(&v_note, &["title"], 39))?.into_json()}); if !validate("Summary",&value) { Err(Fault::Internal(39)) } else { Ok(AppValue::Json(value)) } };
}

async fn call_43(ctx: InvocationContext, v_input: AppValue) -> Outcome {
let v_note = (async { let mut args = { static CONSTANT: std::sync::OnceLock<Value> = std::sync::OnceLock::new(); CONSTANT.get_or_init(|| serde_json::from_str::<Value>(r#"{"entity":"Note","operation":"Note.private_details","semanticOperationId":43,"freshness":"authoritative","policy":{"operation":{"fieldReads":[{"entity":"Note","field":"private_note","origin":"typed_expression","subjects":["NoteRole.owner"]}],"obligations":[{"effect":"read","entity":"Note","origin":"operation_exception","subjects":["NoteRole.owner"]}],"operation":"Note.private_details"},"bindings":[{"entity":"Note","field":"editor_id","principalEntity":"User","role":"NoteRole.editor","scope":"Note"},{"entity":"Note","field":"owner_id","principalEntity":"User","role":"NoteRole.owner","scope":"Note"}],"entities":[{"entity":"Note","fields":[{"field":"private_note","rules":[{"effects":["read","update"],"subject":"NoteRole.owner"},{"effects":["update"],"subject":"NoteRole.editor"}]}],"rules":[{"effects":["read","update"],"subject":"NoteRole.owner"},{"effects":["read","update"],"subject":"NoteRole.editor"}],"scope":"Note","scopeField":null}]},"predicate":{"field":"id","operator":"equal"}}"#).unwrap()).clone() }; args["predicate"]["value"] = (member(&v_input, &["id"], 43))?.into_json(); let row = host_read(ctx.clone(), args, 43).await?.value; if row.is_null() {return Err(Fault::Domain("NoteMissing"));} if !validate("Note", &row) {return Err(Fault::Internal(43));} Ok(AppValue::checked_row(row)) }.await)?;
return { let value = json!({"id":(member(&v_note, &["id"], 43))?.into_json(),"private_note":(member(&v_note, &["private_note"], 43))?.into_json()}); if !validate("PrivateSummary",&value) { Err(Fault::Internal(43)) } else { Ok(AppValue::Json(value)) } };
}

async fn call_45(ctx: InvocationContext, v_input: AppValue) -> Outcome {
let v_note = (async { let mut args = { static CONSTANT: std::sync::OnceLock<Value> = std::sync::OnceLock::new(); CONSTANT.get_or_init(|| serde_json::from_str::<Value>(r#"{"entity":"Note","operation":"Note.rename","semanticOperationId":45,"freshness":"authoritative","policy":{"operation":{"fieldReads":[],"obligations":[{"effect":"update","entity":"Note","origin":"entity","subjects":["NoteRole.owner","NoteRole.editor"]}],"operation":"Note.rename"},"bindings":[{"entity":"Note","field":"editor_id","principalEntity":"User","role":"NoteRole.editor","scope":"Note"},{"entity":"Note","field":"owner_id","principalEntity":"User","role":"NoteRole.owner","scope":"Note"}],"entities":[{"entity":"Note","fields":[{"field":"private_note","rules":[{"effects":["read","update"],"subject":"NoteRole.owner"},{"effects":["update"],"subject":"NoteRole.editor"}]}],"rules":[{"effects":["read","update"],"subject":"NoteRole.owner"},{"effects":["read","update"],"subject":"NoteRole.editor"}],"scope":"Note","scopeField":null}]},"predicate":{"field":"id","operator":"equal"}}"#).unwrap()).clone() };
args["predicate"]["value"] = (member(&v_input, &["id"], 45))?.into_json();
let mut changes = serde_json::Map::new();
changes.insert("title".to_owned(), (member(&v_input, &["title"], 45))?.into_json());
args["changes"] = Value::Object(changes);
let mut result = host_update(ctx.clone(), args, 45).await?.value;
let object = result.as_object_mut().ok_or(Fault::Internal(45))?;
match object.get("status").and_then(Value::as_str) {
Some("found") if object.len()==2 && object.contains_key("row") => { let row = &object["row"]; if !validate("Note",row) { return Err(Fault::Internal(45)); } Ok(AppValue::Json(object.remove("row").unwrap())) },
Some("missing") if object.len()==1 => Err(Fault::Domain("NoteMissing")),
Some("conflict") if object.len()==1 => Err(Fault::Domain("NoteConflict")),
_ => Err(Fault::Internal(45)),
} }.await)?;
return { let value = json!({"id":(member(&v_note, &["id"], 45))?.into_json(),"title":(member(&v_note, &["title"], 45))?.into_json()}); if !validate("Summary",&value) { Err(Fault::Internal(45)) } else { Ok(AppValue::Json(value)) } };
}

async fn call_46(ctx: InvocationContext, v_input: AppValue) -> Outcome {
let v_note = (async { let mut args = { static CONSTANT: std::sync::OnceLock<Value> = std::sync::OnceLock::new(); CONSTANT.get_or_init(|| serde_json::from_str::<Value>(r#"{"entity":"Note","operation":"Note.summary","semanticOperationId":46,"freshness":"authoritative","policy":{"operation":{"fieldReads":[],"obligations":[{"effect":"read","entity":"Note","origin":"entity","subjects":["NoteRole.owner","NoteRole.editor"]}],"operation":"Note.summary"},"bindings":[{"entity":"Note","field":"editor_id","principalEntity":"User","role":"NoteRole.editor","scope":"Note"},{"entity":"Note","field":"owner_id","principalEntity":"User","role":"NoteRole.owner","scope":"Note"}],"entities":[{"entity":"Note","fields":[{"field":"private_note","rules":[{"effects":["read","update"],"subject":"NoteRole.owner"},{"effects":["update"],"subject":"NoteRole.editor"}]}],"rules":[{"effects":["read","update"],"subject":"NoteRole.owner"},{"effects":["read","update"],"subject":"NoteRole.editor"}],"scope":"Note","scopeField":null}]},"predicate":{"field":"id","operator":"equal"}}"#).unwrap()).clone() }; args["predicate"]["value"] = (member(&v_input, &["id"], 46))?.into_json(); let row = host_read(ctx.clone(), args, 46).await?.value; if row.is_null() {return Err(Fault::Domain("NoteMissing"));} if !validate("Note", &row) {return Err(Fault::Internal(46));} Ok(AppValue::checked_row(row)) }.await)?;
return { let value = json!({"id":(member(&v_note, &["id"], 46))?.into_json(),"title":(member(&v_note, &["title"], 46))?.into_json()}); if !validate("Summary",&value) { Err(Fault::Internal(46)) } else { Ok(AppValue::Json(value)) } };
}

async fn call_557(ctx: InvocationContext, v_input: AppValue) -> Outcome {
let v_first = (call_45(ctx.clone(), ({ let value = json!({"id":(member(&v_input, &["first"], 557))?.into_json(),"title":(member(&v_input, &["title"], 557))?.into_json()}); if !validate("Rename",&value) { Err(Fault::Internal(557)) } else { Ok(AppValue::Json(value)) } })?).await)?;
return call_45(ctx.clone(), ({ let value = json!({"id":(member(&v_input, &["second"], 557))?.into_json(),"title":(member(&v_input, &["second_title"], 557))?.into_json()}); if !validate("Rename",&value) { Err(Fault::Internal(557)) } else { Ok(AppValue::Json(value)) } })?).await;
}

async fn call_558(ctx: InvocationContext, v_input: AppValue) -> Outcome {
let v_changed = (call_45(ctx.clone(), (member(&v_input, &[], 558))?).await)?;
return Err(Fault::Domain("ChangeRejected"));
}

pub fn checked_input(operation:i32,input:&Value)->bool { if !within_limit(input) {return false;} match operation {
39=>validate("SecretChange", &input),
43=>validate("Lookup", &input),
45=>validate("Rename", &input),
46=>validate("Lookup", &input),
557=>validate("PairChange", &input),
558=>validate("Rename", &input),
_=>false,}}

fn make_entry(operation:i32,input:Value,ctx:InvocationContext)->Result<Pin<Box<dyn Future<Output=Outcome> + Send>>,Fault> { if !checked_input(operation,&input) {return Err(Fault::Invalid);} match operation {
39=>{ Ok(Box::pin(call_39(ctx, AppValue::Json(input)))) },
43=>{ Ok(Box::pin(call_43(ctx, AppValue::Json(input)))) },
45=>{ Ok(Box::pin(call_45(ctx, AppValue::Json(input)))) },
46=>{ Ok(Box::pin(call_46(ctx, AppValue::Json(input)))) },
557=>{ Ok(Box::pin(call_557(ctx, AppValue::Json(input)))) },
558=>{ Ok(Box::pin(call_558(ctx, AppValue::Json(input)))) },
_=>Err(Fault::Invalid),}}
